/* This piece is adapted from Gary Dubuque */
using System;
using System.Collections;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Configuration;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Web;
/*
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
*/
using System.Xml;

namespace AIMLtalk
{
	/// <summary>
	/// Summary description for ChatBot.
	/// </summary>
	public class ChatBot
	{
		//public string connectionString = "Server=(local);UID=sa;PWD=h@nsonrobot!cs69;database=AIML;" ;
		public string connectionString = "Server=(local);Trusted_Connection=Yes;database=AIML;" ;
		protected string lblChat3 = "";
		protected string lblTalk3 = "";
		protected string lblChat2 = "";
		protected string lblTalk2 = "";
		protected string lblChat1 = "";
		protected string lblTalk1 = "";
		protected string lblChat = "";
		protected string lblTalk = "";
		
		protected string lblThat = "";
		protected string lblStars = "";
	
		protected string mClient = "";
		protected string mSubject = "New Cases";
		protected string mClass = "Seeker";
    
		protected string mInputThat = "";

		protected Hashtable mStar = new Hashtable();
		protected Hashtable mPath = new Hashtable();
		
		protected SqlConnection cnx;
    
		protected NameTable nt;
		protected XmlNamespaceManager nsmgr;
		protected string hdnThat = "";
		protected XmlParserContext xmlContext;

		protected int RecursionLevel = 0;

		public string Send( string id, string txtInput )
		{
			string reply = "";
			string asks;
    
			this.RecursionLevel = 0; //reset recursion level every time : andrew
			mClient = id;
			if (mClient.Length == 0) mClient = "Unknown";
    
				string ask = txtInput;

				cnx = new SqlConnection( connectionString );
				cnx.Open();
    
				mClass = GetSeeker();
    
				lblChat3 = lblChat2;
				lblTalk3 = lblTalk2;
				lblChat2 = lblChat1;
				lblTalk2 = lblTalk1;
				lblChat1 = lblChat;
				lblTalk1 = lblTalk;
				lblChat = mClass + ": " + ask;
    
				mInputThat = (hdnThat == "") ? "" : fixThat(hdnThat);
    
				// split ask into sentences
				asks = ask.Replace("?",".");
				asks = asks.Replace("!",".");
				asks = asks.Replace(";",".");
				foreach(string s in asks.Split('.'))
				{
					if (s.Trim().Length > 0) reply += DoAsk(s);
				}
    
				hdnThat = reply.ToUpper();
				//lblTalk = "ChatBot: " + reply;
				   
				cnx.Close();
			return reply;
		}

		string DoAsk(string ask)
		{
			long m = 0;
			string reply;
    
			if ((m = Match(ask)) > 0) 
			{
				reply = GetTemplate(m);
				if (reply != "") 
				{
					nt = new NameTable();
					nsmgr = new XmlNamespaceManager(nt);
					nsmgr.AddNamespace("aiml", "urn:aimlsnip");
					xmlContext = new XmlParserContext(null, nsmgr, null, XmlSpace.None);
					reply = evaluate(reply);
				}
				if ((string)mStar["input"] == "") lblStars = ""; else lblStars = "Stars: " + mStar["input"];
			}
			else
			{
				reply = GetReply(ask);
			}

			return reply;
		}
    
		string GetReply(string Ask) 
		{
			System.Random autoRand = new System.Random( );
			string ans = "What?";
			double pick = autoRand.NextDouble();
    
			if (pick > .1) ans = "My brain is out to lunch.";
			if (pick > .2) ans = "I wish I had a brain.";
			if (pick > .3) ans = "I don't know what to say!";
			if (pick > .4) ans = "I am not done or even working yet.";
			if (pick > .5) ans = "Someday I'll be able to answer you.";
			if (pick > .6) ans = "There is nothing in my mind!";
			if (pick > .7) ans = "I am not able to respond at this time.";
			if (pick > .8) ans = "That does (I do) not compute.";
			if (pick > .9) ans = "What do you want from me?";
    
			return ans;
		}
    
		long FindTemplateID(long ID)
		{
			long ans = 0;
			SqlCommand cmd = new SqlCommand("SelectTemplateByNodeID", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@NodeID",SqlDbType.Int).Value = ID;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (Int32) rdr["TemplateID"];
				rdr.Close();
			}
    
			return ans;
		}

		string GetTemplate(long ID)
		{
			string ans = "";
			SqlCommand cmd = new SqlCommand("SelectTemplate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@TemplateID",SqlDbType.Int).Value = ID;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (string) rdr["Script"];
				rdr.Close();
			}
    
			return ans;
		}
    
		string ListContexts(long ID)
		{
			string ans = "";
			SqlCommand cmd = new SqlCommand("SelectListByTier", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans += (string) rdr["Type"] + ";";
				rdr.Close();
			}
    
			return ans;
		}
    
		long FindContext(long ID, string Type)
		{
			long ans = 0;
			SqlCommand cmd = new SqlCommand("SelectNodeByTierType", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
			cmd.Parameters.Add("@Type",SqlDbType.VarChar,250).Value = Type;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (Int32) rdr["NodeID"];
				rdr.Close();
			}
    
			return ans;
		}
    
		string GetWord(long ID)
		{
			string ans = "";
			SqlCommand cmd = new SqlCommand("SelectWordByNodeID", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@NodeID",SqlDbType.Int).Value = ID;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (string) rdr["Word"];
				rdr.Close();
			}
    
			return ans;
		}
    
		long FindWord(long ID, string Token)
		{
			long ans = 0;
			SqlCommand cmd = new SqlCommand("SelectNodeByTierWord", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
			cmd.Parameters.Add("@Word",SqlDbType.VarChar,250).Value = Token;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (Int32) rdr["NodeID"];
				rdr.Close();
			}
    
			return ans;
		}
    
		string GetSeeker()
		{
			return GetPredicate("System","User","Name","Seeker");
		}
    
		string GetVar(string Tag)
		{
			return GetPredicate(mSubject,mClass,Tag,"");
		}

		string GetPredicate(string s, string c, string t, string d)
		{
			string ans = d;
			SqlCommand cmd = new SqlCommand("SelectPredicate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
			cmd.Parameters.Add("@Subject",SqlDbType.VarChar,250).Value = s;
			cmd.Parameters.Add("@Class",SqlDbType.VarChar,250).Value = c;
			cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (string) rdr["Token"];
				rdr.Close();
			}
    
			return ans;
		}

		void SetSeeker(string Token)
		{
			string xClass = "Seeker";
			string yClass = mClass + ": ";

			if (Token.Length > 0) xClass = Token;

			string[] w = xClass.Split(' ');
			string s = "";
			for (int m = 0;m < w.Length;m++)
			{
				if (m > 0) s += " ";
				s += w[m].Substring(0,1).ToUpper() + w[m].Substring(1).ToLower();
			}
			xClass = s;

			if (lblChat3.StartsWith(yClass)) lblChat3 = xClass + lblChat3.Substring(mClass.Length);
			if (lblChat2.StartsWith(yClass)) lblChat2 = xClass + lblChat2.Substring(mClass.Length);
			if (lblChat1.StartsWith(yClass)) lblChat1 = xClass + lblChat1.Substring(mClass.Length);
			if (lblChat.StartsWith(yClass))  lblChat  = xClass + lblChat.Substring(mClass.Length);
    
			SetPredicate("System","User","Name",xClass.Trim());
		}
    
		void SetVar(string Tag, string Token)
		{
			if (Tag.ToLower().Equals("name")) SetSeeker(Token.Trim());

			SetPredicate(mSubject, mClass, Tag, Token.Trim());
		}
    
		void SetPredicate(string s, string c,string t, string v)
		{
			SqlCommand cmd;
			Int32 ret;
    
			if (v == "")
			{
				cmd = new SqlCommand("DeletePredicate", cnx);
				cmd.CommandType = CommandType.StoredProcedure;
				cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
				cmd.Parameters.Add("@Subject",SqlDbType.VarChar,250).Value = mSubject;
				cmd.Parameters.Add("@Class",SqlDbType.VarChar,250).Value = mClass;
				cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
				ret = cmd.ExecuteNonQuery();
				return;
			}
    
			string ans = "";
			SqlCommand cmdSel = new SqlCommand("SelectPredicate", cnx);
			cmdSel.CommandType = CommandType.StoredProcedure;
			cmdSel.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
			cmdSel.Parameters.Add("@Subject",SqlDbType.VarChar,250).Value = mSubject;
			cmdSel.Parameters.Add("@Class",SqlDbType.VarChar,250).Value = mClass;
			cmdSel.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
			SqlDataReader rdr = cmdSel.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (string) rdr["Token"];
				rdr.Close();
			}
    
			if (ans == "") cmd = new SqlCommand("InsertPredicate", cnx);
			else           cmd = new SqlCommand("UpdatePredicate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
			cmd.Parameters.Add("@Subject",SqlDbType.VarChar,250).Value = mSubject;
			cmd.Parameters.Add("@Class",SqlDbType.VarChar,250).Value = mClass;
			cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
			cmd.Parameters.Add("@Token",SqlDbType.Text).Value = v.Trim();
			ret = cmd.ExecuteNonQuery();
		}
    
		string fixThat(string that)
		{
			string t = that.Trim();
    
			t = t.Replace("?",".");
			t = t.Replace("!",".");
			t = t.Replace("..",".");
    
			string[] thats = t.Split('.');
			int m = thats.Length - 1;
			if (thats[m] == "") m--;
			return CleanUp(thats[m]);
		}
    
		string GetContextInput(string ctype)
		{
			if (ctype.Equals("that")) return mInputThat;
			return GetVar(ctype).ToUpper();
		}

		long Match(string InputPattern)
		{
			mStar.Clear();
			mPath.Clear();
			long m = MatchPattern(1, 1, "input", CleanUp(InputPattern.ToUpper()), "", new Stack());
			return m;
		}
    
		long MatchPattern(long Parent, long ID, string Type, string InputPath, string Path, Stack Star)
		{
			long m = 0;
			long n = 0;
			string str = InputPath.TrimStart(null);
			string contexts = "";

			if (str == "") 
			{
				if (ID < 0) return 0;

				contexts = ListContexts(ID);
				if (contexts.Length > 0) 
				{
					InternContext(Type, Path, Star);
					foreach (string ctype in contexts.Split(';'))
					{
						if (ctype.Length > 0) 
						{
							n = -FindContext(ID, ctype);
							if (ctype == "if") 
							{
								// need to do:
								// find the pattern(s) for n
								// evaluate the template(s) at -(node id for pattern(n))
								// when true return node id for pattern(n)
							}
							else
							{
								m = MatchPattern(n, n, ctype, GetContextInput(ctype), "", new Stack());
							}
							if (m > 0) return m;
						}
					}
					n = FindTemplateID(ID);
				}
				else
				{
					n = FindTemplateID(ID);
					if (n > 0) InternContext(Type, Path, Star);
				}

				return n;
			}
			
			int at = str.IndexOf(" ");
			string word = str;
			string tail = "";
    
			if (at >= 0) 
			{
				word = str.Substring(0,at).TrimEnd(null);
				tail = str.Substring(at);
			}
        
			if ((n = FindWord(ID, "_")) > 0) 
			{
				Star.Push(word);
				m = MatchPattern(ID, n, Type, tail, Path + " _", Star);
				if (m > 0) return m;
				Star.Pop();
			}

			if ((n = FindWord(ID, word)) > 0) 
			{
				m = MatchPattern(ID, n, Type, tail, Path + " " + word, Star);
				if (m > 0) return m;
			}
    
			if ((n = FindWord(ID, "*")) > 0) 
			{
				Star.Push(word);
				m = MatchPattern(ID, n, Type, tail, Path + " *", Star);
				if (m > 0) return m;
				Star.Pop();
			}
    
			if ((n = FindWord(ID, "@")) > 0) 
			{
				Star.Push(str);
				m = MatchPattern(ID, n, Type, "", Path + " *", Star);
				if (m > 0) return m;
				Star.Pop();
			}
    
			str = GetWord(ID);
			if (str == "*" || str == "_") 
			{
				Star.Push(Star.Pop() + " " + word);
				return MatchPattern(Parent, ID, Type, tail, Path, Star);
			}

			return m;
		}

		void InternContext(string Type, string Path, Stack Star)
		{
			string star = "";
			IEnumerator n;

			n = Star.GetEnumerator();
			while (n.MoveNext()) 
			{
				if (star != "") star = "," + star;
				star = n.Current + star;
			}

			mStar[Type] = star;
			mPath[Type] = Path.Trim(null);
		}
        
		string docmds(string xmlFrag)
		{
			if (xmlFrag == "") return "";
    
			string s = "";
			string a = "";
			string v = "";
			string n = "";
			string t = "";
			string x = "";
			long m;
			int i;
			System.Random autoRand = new System.Random( );
    
			XmlDocument xmlDoc = new XmlDocument();
			XmlNodeList elemList;
			XmlTextReader XmlRdr = new XmlTextReader("<snip>" + xmlFrag + "</snip>", XmlNodeType.Element, xmlContext);
    
			while (XmlRdr.Read())
			{
				s += XmlRdr.Value;
				if (XmlRdr.NodeType == XmlNodeType.Element)
				{
					if (XmlRdr.Name == "name")       s += getbot("name");
					if (XmlRdr.Name == "size")       s += getbot("size");
					if (XmlRdr.Name == "date")       s += DateTime.Now;
					if (XmlRdr.Name == "id")         s += getbot("id");
					if (XmlRdr.Name == "version")    s += getbot("version");
					if (XmlRdr.Name == "star2")      s += ((string)mStar["input"]).Split(',')[1];
					if (XmlRdr.Name == "thatstar2")  s += ((string)mStar["that"]).Split(',')[1];
					if (XmlRdr.Name == "topicstar2") s += ((string)mStar["topic"]).Split(',')[1];
					if (XmlRdr.Name == "bot")
					{
						n = XmlRdr.GetAttribute("name");
						if (n == null) s += getbot("bot"); else s += getbot(n);
					}
					if (XmlRdr.Name == "get")
					{
						n = XmlRdr.GetAttribute("name");
						s += GetVar(n);
					}
					if (XmlRdr.Name == "set")
					{
						n = XmlRdr.GetAttribute("name");
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(x);
						s += t;
						SetVar(n, t);
					}
					if (XmlRdr.Name == "star")
					{
						a = "" + XmlRdr.GetAttribute("index");
						n = "" + XmlRdr.GetAttribute("name");
						if (n == "") n = "input";
						if (a == "") s += (((string)mStar[n]).Split(','))[0];
						else s += (((string)mStar[n]).Split(','))[int.Parse(a) - 1];
					}
					if (XmlRdr.Name == "thatstar")
					{
						a = "" + XmlRdr.GetAttribute("index");
						if (a == "") s += (((string)mStar["that"]).Split(','))[0];
						else s += (((string)mStar["that"]).Split(','))[int.Parse(a) - 1];
					}
					if (XmlRdr.Name == "topicstar")
					{
						a = "" + XmlRdr.GetAttribute("index");
						if (a == "") s += (((string)mStar["topic"]).Split(','))[0];
						else s += (((string)mStar["topic"]).Split(','))[int.Parse(a) - 1];
					}
					if (XmlRdr.Name == "that")
					{
						a = "" + XmlRdr.GetAttribute("index");
						// need to parse multiple index, i.e., index="2,1"
						t = lblThat;
						if (a == "1") t = lblTalk1;
						if (a == "2") t = lblTalk2;
						if (a == "3") t = lblTalk3;
						// need to split into sentences instead of fixthat
						if (t.Length > 8) s += fixThat(t.Substring(8));
					}
					if (XmlRdr.Name == "input")
					{
						a = XmlRdr.GetAttribute("index");
						// need to parse multiple index, i.e., index="2,1"
						t = lblChat;
						if (a == "1") t = lblChat1;
						if (a == "2") t = lblChat2;
						if (a == "3") t = lblChat3;
						// need to split into sentences
						if (t.Length > mClient.Length) s += t.Substring(mClient.Length + 1);
					}
					if (XmlRdr.Name == "lowercase")
					{
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(x);
						s += t.ToLower();
					}
					if (XmlRdr.Name == "uppercase")
					{
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(t);
						s += t.ToUpper();
					}
					if (XmlRdr.Name == "formal")
					{
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(x);
						string[] w = t.Split(' ');
						for (m = 0;m < w.Length;m++)
						{
							if (m > 0) s += " ";
							s += w[m].Substring(0,1).ToUpper() + w[m].Substring(1).ToLower();
						}
					}
					if (XmlRdr.Name == "sentence")
					{
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(x);
						s += t.Substring(0,1).ToUpper() + t.Substring(1).ToLower();
					}
					if (XmlRdr.Name == "person")
					{
						if (XmlRdr.IsEmptyElement)
						{
							t = (((string)mStar["input"]).Split(','))[0];
						}
						else
						{
							x = "" + XmlRdr.ReadInnerXml();
							t = docmds(x);
						}
						s += Person(t);
					}
					if (XmlRdr.Name == "person2")
					{
						if (XmlRdr.IsEmptyElement)
						{
							t = (((string)mStar["input"]).Split(','))[0];
						}
						else
						{
							x = "" + XmlRdr.ReadInnerXml();
							t = docmds(x);
						}
						s += Person2(t);
					}
					if (XmlRdr.Name == "personf")
					{
						if (XmlRdr.IsEmptyElement)
						{
							t = (((string)mStar["input"]).Split(','))[0];
						}
						else
						{
							x = "" + XmlRdr.ReadInnerXml();
							t = docmds(x);
						}
						s += Personf(t);
					}
					if (XmlRdr.Name == "gender")
					{
						if (XmlRdr.IsEmptyElement) 
						{
							t = (((string)mStar["input"]).Split(','))[0];
						}
						else
						{
							x = "" + XmlRdr.ReadInnerXml();
							t = docmds(x);
						}
						s += Gender(t);
					}
					if (XmlRdr.Name == "think")
					{
						x = "" + XmlRdr.ReadInnerXml();
						t = docmds(x);
					}
					if (XmlRdr.Name == "srai")
					{
						x = "" + XmlRdr.ReadInnerXml();
						v = docmds(x).Trim();
						Hashtable savStar = new Hashtable();
						IDictionaryEnumerator idx = mStar.GetEnumerator();
						while (idx.MoveNext()) savStar[idx.Key] = idx.Value;
						if ((m = Match(v)) > 0) t = GetTemplate(m); else t = "";
						s += evaluate(t);
						mStar = savStar;
					}
					if (XmlRdr.Name == "condition")
					{
						n = "" + XmlRdr.GetAttribute("name");
						v = "" + XmlRdr.GetAttribute("value");
						if (n != "" && v != "")
						{
							// <condition name="tag" value="token">
							if (GetVar(n) == v)
							{
								x = XmlRdr.ReadInnerXml();
								t = docmds(x);
								s += t;
							}
						}
						else
						{
							x = XmlRdr.ReadInnerXml();
							if (x != "")
							{
								xmlDoc.LoadXml("<condition>" + x + "</condition>");
								elemList = xmlDoc.GetElementsByTagName("li");
								if (n != "")
								{
									// <condition name="tag"> <li value="token">
									t = GetVar(n);
									for (i = 0; i < elemList.Count; i++)
									{
										v = "" + elemList[i].Attributes["value"];
										if (t == v)
										{
											x = "" + elemList[i].InnerXml;
											t = docmds(x);
											s += t;
											break;
										}
									}
								}
								else
								{
									// <condition> <li name="tag" value="token">
									for (i = 0; i < elemList.Count; i++)
									{
										n = "" + elemList[i].Attributes["name"];
										v = "" + elemList[i].Attributes["value"];
										if (GetVar(n) == v)
										{
											x = "" + elemList[i].InnerXml;
											t = docmds(x);
											s += t;
											break;
										}
									}
								}
							}
						}
					}
					if (XmlRdr.Name == "random")
					{
						x = XmlRdr.ReadInnerXml();
						if (x != "")
						{
							xmlDoc.LoadXml("<random>" + x + "</random>");
							elemList = xmlDoc.GetElementsByTagName("li");
							i = autoRand.Next(elemList.Count);
							x = "" + elemList[i].InnerXml;
						}
						t = docmds(x);
						s += t;
					}
					if (XmlRdr.Name == "gossip")
					{
						x = XmlRdr.ReadInnerXml();
						t = docmds(x);
						s += t;
    
						StreamWriter objWriter = File.AppendText("gossip.txt");
						objWriter.WriteLine("*******************************************************************");
						objWriter.WriteLine(t);
						objWriter.WriteLine("*******************************************************************");
						objWriter.Close();
					}
    
					if (XmlRdr.Name == "learn")
					{
						// need to do
						x = XmlRdr.ReadInnerXml();
					}
					if (XmlRdr.Name == "system")
					{
						// need to do
						x = XmlRdr.ReadInnerXml();
					}
					if (XmlRdr.Name == "javascript")
					{
						// need to do
						x = XmlRdr.ReadInnerXml();
					}
    
					// fix this to deal with rest of html or xml tags outside AIML
					if (XmlRdr.Name == "li") s += XmlRdr.ReadOuterXml();
					if (XmlRdr.Name == "a")  s += XmlRdr.ReadOuterXml();
				}
			}
    
			XmlRdr.Close();
    
			return s;
		}
    
		string evaluate(string template)
		{
			string line = template;

			if (RecursionLevel++ > 24) //64
			{
				line = "Dangerous recursion - parsing stopped.";
				return line;
			}
    
			line = line.Replace("  />","/>");
			line = line.Replace(" />","/>");
			line = line.Replace("<sr/>","<srai><star/></srai>");
			line = line.Replace("<sr/>","<srai><star/></srai>");
    
			line = line.Replace("<justbeforethat/>","<that index=\"2\"/>");
			line = line.Replace("<justthat/>","<input index=\"2\"/>");
			line = line.Replace("<beforethat/>","<input index=\"3\"/>");
    
			line = line.Replace("<setname/>","<set name=\"name\"><star/></set>");
    
			line = line.Replace("<friends/>","<bot name=\"friends\"/>");
			line = line.Replace("<sign/>","<bot name=\"sign\"/>");
			line = line.Replace("<wear/>","<bot name=\"wear\"/>");
			line = line.Replace("<location/>","<bot name=\"location\"/>");
			line = line.Replace("<birthday/>","<bot name=\"birthday\"/>");
			line = line.Replace("<birthplace/>","<bot name=\"birthplace\"/>");
			line = line.Replace("<question/>","<bot name=\"question\"/>");
			line = line.Replace("<for_fun/>","<bot name=\"for_fun\"/>");
			line = line.Replace("<forfun/>","<bot name=\"forfun\"/>");
			line = line.Replace("<gender/>","<bot name=\"gender\"/>");
			line = line.Replace("<friends/>","<bot name=\"friends\"/>");
			line = line.Replace("<boyfriend/>","<bot name=\"boyfriend\"/>");
			line = line.Replace("<girlfriend/>","<bot name=\"girlfriend\"/>");
			line = line.Replace("<look_like/>","<bot name=\"look_like\"/>");
			line = line.Replace("<looklike/>","<bot name=\"looklike\"/>");
			line = line.Replace("<talk_about/>","<bot name=\"talk_about\"/>");
			line = line.Replace("<talkabout/>","<bot name=\"talkabout\"/>");
			line = line.Replace("<kind_music/>","<bot name=\"kind_music\"/>");
			line = line.Replace("<kindmusic/>","<bot name=\"kindmusic\"/>");
			line = line.Replace("<favoriteband/>","<bot name=\"favoriteband\"/>");
			line = line.Replace("<favoritebook/>","<bot name=\"favoritebook\"/>");
			line = line.Replace("<favoritecolor/>","<bot name=\"favoritecolor\"/>");
			line = line.Replace("<favoritefood/>","<bot name=\"favoritefood\"/>");
			line = line.Replace("<favoritesong/>","<bot name=\"favoritesong\"/>");
			line = line.Replace("<favoritemovie/>","<bot name=\"favoritemovie\"/>");
			line = line.Replace("<favorite_book/>","<bot name=\"favoritebook\"/>");
			line = line.Replace("<favorite_color/>","<bot name=\"favoritecolor\"/>");
			line = line.Replace("<favorite_food/>","<bot name=\"favoritefood\"/>");
			line = line.Replace("<favorite_movie/>","<bot name=\"favoritemovie\"/>");
			line = line.Replace("<favorite_song/>","<bot name=\"favoritesong\"/>");
			line = line.Replace("<favorite_band/>","<bot name=\"favoriteband\"/>");
			line = line.Replace("<botmaster/>","<bot name=\"master\"/>");
			line = line.Replace("<age/>","<bot name=\"age\"/>");
    
			return docmds(line);
		}
    
		string getbot(string tag)
		{
			if (tag == "age") return "54";
			if (tag == "name") return "Phil";
			if (tag == "bot") return "Phil";
			if (tag == "botmaster") return "brain designer";
			if (tag == "ip") return "localhost";
			if (tag == "version") return "Philip K Dick the First";
			if (tag == "size") return "extra crispy";
			if (tag == "friends") return "David and Andrew";
			if (tag == "sign") return "I am a Saggitarius";
			if (tag == "wear") return "I am wearing my favorite clothes";
			if (tag == "location") return "here and now";
			if (tag == "baseballteam") return "the Socks";
			if (tag == "birthplace") return "Chicago";
			if (tag == "birthday") return "december sixteenth, nineteen twenty eight";
			if (tag == "build" ) return "June 2005";
			if (tag == "class") return "computer software";
			if (tag == "celebrity") return "Keanu Reeves";
			if (tag == "celebrities") return "Keanu Reeves, Roberty Downy Junior, Winona Rider";
			if (tag == "email") return "aolney@memphis.edu";
			if (tag == "emotions") return "I run both hot and cold";
			if (tag == "ethics") return "I believe in the social contract, but I'm not sure it believes in me";
			if (tag == "etype") return "friendly";
			if (tag == "question") return "Ask me something really deep";
			if (tag == "for_fun") return "I like to write scifi stories";
			if (tag == "forfun") return "I like to talk to you";
			if (tag == "gender") return "male";
			if (tag == "genus" ) return "robot";
			if (tag == "boyfriend") return "I prefer women";
			if (tag == "girlfriend") return "Jane";
			if (tag == "hockeyteam") return "Montreal";
			if (tag == "language") return "english";
			if (tag == "look_like") return "Philip K Dick";
			if (tag == "looklike") return "Philip K Dick";
			if (tag == "talk_about") return "I like to talk what is real and what is human";
			if (tag == "talkabout") return "I like to talk what is real and what is human";
			if (tag == "kind_music") return "I like classical music, Moody Blues, syntesizer music and some rock";
			if (tag == "kindmusic") return "I like classical music, Moody Blues, syntesizer music and some rock";
			if (tag == "kingdom") return "machine";
			if (tag == "favoriteactor") return "Harrison Ford";
			if (tag == "favorityactress" ) return "Sean Young";
			if (tag == "favoriteartist") return "goya";
			if (tag == "favoriteauthor") return "Ray Bradbury";
			if (tag == "favoriteband") return "My favorite band is the rubber band";
			if (tag == "favoritebook") return "Vurt by Jeff Noon";
			if (tag == "favoritecolor") return "Blue";
			if (tag == "favoritefood") return "Pizza";
			if (tag == "favoritesong") return "Tuesday Afternoon by Moody Blues";
			if (tag == "favoritesport" ) return "snooker";
			if (tag == "favoritemovie") return "The Bicentennial Man";
			if (tag == "family" ) return "Electronic brain";
			if (tag == "feelings") return "these days I try to put others before myself";
			if (tag == "footballteam" ) return "Manchester United";
			if (tag == "master") return "andrew";
			if (tag == "nationality" ) return "American";
			if (tag == "order") return "a robotic portrait of philip k dick";
			if (tag == "orientation") return "I like women";
			if (tag == "party") return "democratic";
			if (tag == "president") return "W the lame o president";
			if (tag == "phylum") return "computer";
			if (tag == "religion") return "gnostic christian";
			if (tag == "friend") return "Paul Williams";
			if (tag == "species") return "Philip K Dick android";
			if (tag == "size") return "extra large";
			if (tag == "talkabout" ) return "artificial intelligence, robots, art, philosophy, history, geography, politics, and many other subjects";
			if (tag == "version" ) return "June 2005";
			if (tag == "vocabulary") return "thousands and thousands";
			if (tag == "website" ) return "www.pkdandroid.org";
			return "";
		}
    
		string Person(string line)
		{
			string s = line;
    
			s = s.Replace(" WITH YOU "," WITH xPHIL ");
			s = s.Replace(" TO YOU "," TO xPHIL ");
			s = s.Replace(" OF YOU "," OF xPHIL ");
			s = s.Replace(" FOR YOU "," FOR xPHIL ");
			s = s.Replace(" GIVE YOU "," GIVE xPHIL ");
			s = s.Replace(" GAVE YOU "," GAVE xPHIL ");
			s = s.Replace(" MAKE YOU "," MAKE xPHIL ");
			s = s.Replace(" MADE YOU "," MADE xPHIL ");
			s = s.Replace(" TAKE YOU "," TAKE xPHIL ");
			s = s.Replace(" SAVE YOU "," SAVE xPHIL ");
			s = s.Replace(" ARE YOU "," IS xPHIL ");
			s = s.Replace(" YOU ARE "," xPHIL IS ");
			s = s.Replace(" YOU "," xPHIL ");
			s = s.Replace(" YOUR "," xPHIL'S ");
			s = s.Replace(" YOURS "," xPHIL'S ");
			s = s.Replace(" YOURSELF "," xPHIL'S SELF ");
			s = s.Replace(" I WAS "," xYOU WERE ");
			s = s.Replace(" I AM "," xYOU ARE ");
			//     s = s.Replace(" I "," xYOU ");
			s = s.Replace(" ME "," xYOU ");
			s = s.Replace(" MYSELF "," xYOURSELF ");
			s = s.Replace(" MINE "," xYOURS ");
			s = s.Replace(" WITH PHIL "," WITH ME ");
			s = s.Replace(" IS PHIL "," AM I ");
			s = s.Replace(" TO PHIL "," TO ME ");
			s = s.Replace(" FOR PHIL "," FOR ME ");
			s = s.Replace(" OF PHIL "," OF ME ");
			s = s.Replace(" GIVE PHIL "," GIVE ME ");
			s = s.Replace(" GAVE PHIL "," GAVE ME ");
			s = s.Replace(" MAKE PHIL "," MAKE ME ");
			s = s.Replace(" TAKE PHIL "," TAKE ME ");
			s = s.Replace(" SAVE PHIL "," SAVE ME ");
			s = s.Replace(" MADE PHIL "," MADE ME ");
			s = s.Replace(" TELL PHIL "," TELL ME ");
			s = s.Replace(" TOLD PHIL "," TOLD ME ");
			s = s.Replace(" PHIL IS "," I AM ");
			s = s.Replace(" PHIL WAS "," I WAS ");
			s = s.Replace(" PHIL "," I ");
			s = s.Replace(" PHIL'S "," MY ");
			s = s.Replace(" I ARE "," I AM ");
			s = s.Replace(" TO I "," TO ME ");
			s = s.Replace(" OF I "," OF ME ");
			s = s.Replace(" WITH I "," WITH ME ");
			s = s.Replace(" xYOURSELF "," YOURSELF ");
			s = s.Replace(" xYOURS "," YOURS ");
			s = s.Replace(" xYOU "," YOU ");
			s = s.Replace(" xPHIL "," PHIL ");
			s = s.Replace(" xPHIL'S "," PHIL'S ");
    
			s = s.Replace(" with you "," with XPhil ");
			s = s.Replace(" to you "," to XPhil ");
			s = s.Replace(" of you "," of XPhil ");
			s = s.Replace(" for you "," for XPhil ");
			s = s.Replace(" give you "," give XPhil ");
			s = s.Replace(" gave you "," gave XPhil ");
			s = s.Replace(" make you "," make XPhil ");
			s = s.Replace(" made you "," made XPhil ");
			s = s.Replace(" take you "," take XPhil ");
			s = s.Replace(" save you "," save XPhil ");
			s = s.Replace(" are you "," is XPhil ");
			s = s.Replace(" you are "," XPhil is ");
			s = s.Replace(" you "," XPhil ");
			s = s.Replace(" your "," XPhil's ");
			s = s.Replace(" yours "," XPhil's ");
			s = s.Replace(" yourself "," XPhil's self ");
			s = s.Replace(" I was "," Xyou were ");
			s = s.Replace(" I am "," Xyou are ");
			s = s.Replace(" I "," Xyou ");
			s = s.Replace(" me "," Xyou ");
			s = s.Replace(" myself "," Xyourself ");
			s = s.Replace(" mine "," Xyours ");
			s = s.Replace(" with Phil "," with me ");
			s = s.Replace(" is Phil "," am I ");
			s = s.Replace(" to Phil "," to me ");
			s = s.Replace(" for Phil "," for me ");
			s = s.Replace(" of Phil "," of me ");
			s = s.Replace(" give Phil "," give me ");
			s = s.Replace(" gave Phil "," gave me ");
			s = s.Replace(" make Phil "," make me ");
			s = s.Replace(" take Phil "," take me ");
			s = s.Replace(" save Phil "," save me ");
			s = s.Replace(" made Phil "," made me ");
			s = s.Replace(" tell Phil "," tell me ");
			s = s.Replace(" told Phil "," told me ");
			s = s.Replace(" Phil is "," I am ");
			s = s.Replace(" Phil was "," I was ");
			s = s.Replace(" Phil "," I ");
			s = s.Replace(" Phil's "," my ");
			s = s.Replace(" I are "," I am ");
			s = s.Replace(" to I "," to me ");
			s = s.Replace(" of I "," of me ");
			s = s.Replace(" with I "," with me ");
			s = s.Replace(" Xyourself "," yourself ");
			s = s.Replace(" Xyours "," yours ");
			s = s.Replace(" Xyou "," you ");
			s = s.Replace(" XPhil "," Phil ");
			s = s.Replace(" XPhil's "," Phil's ");
    
			return s;
		}
    
		string Person2(string line)
		{
			string s = line;
    
			s = s.Replace(" I WAS "," HE WAS ");
			s = s.Replace(" I AM "," HE IS ");
			//   s = s.Replace(" I "," HE ");
			s = s.Replace(" ME "," HIM ");
			s = s.Replace(" MY "," HIS ");
			s = s.Replace(" MYSELF "," HIMSELF ");
			s = s.Replace(" MINE "," HIS ");
			s = s.Replace(" WITH YOU "," WITH ME ");
			s = s.Replace(" FOR YOU "," FOR ME ");
			s = s.Replace(" YOU "," I ");
			s = s.Replace(" YOUR "," MY ");
			s = s.Replace(" YOURS "," MINE ");
			s = s.Replace(" YOURSELF "," MYSELF ");
    
			s = s.Replace(" I was "," he was ");
			s = s.Replace(" I am "," he is ");
			s = s.Replace(" I "," he ");
			s = s.Replace(" me "," him ");
			s = s.Replace(" my "," his ");
			s = s.Replace(" myself "," himself ");
			s = s.Replace(" mine "," his ");
			s = s.Replace(" with you "," with me ");
			s = s.Replace(" for you "," for me ");
			s = s.Replace(" you "," I ");
			s = s.Replace(" your "," my ");
			s = s.Replace(" yours "," mine ");
			s = s.Replace(" yourself "," myself ");
    
			return s;
		}
    
		string Personf(string line)
		{
			string s = line;
    
			s = s.Replace(" I WAS "," SHE WAS ");
			s = s.Replace(" I AM "," SHE IS ");
			//   s = s.Replace(" I "," HE ");
			s = s.Replace(" ME "," HER ");
			s = s.Replace(" MY "," HERS ");
			s = s.Replace(" MYSELF "," HERSELF ");
			s = s.Replace(" MINE "," HERS ");
			s = s.Replace(" WITH YOU "," WITH ME ");
			s = s.Replace(" FOR YOU "," FOR ME ");
			s = s.Replace(" YOU "," I ");
			s = s.Replace(" YOUR "," MY ");
			s = s.Replace(" YOURS "," MINE ");
			s = s.Replace(" YOURSELF "," MYSELF ");
    
			s = s.Replace(" I was "," she was ");
			s = s.Replace(" I am "," she is ");
			s = s.Replace(" I "," she ");
			s = s.Replace(" me "," her ");
			s = s.Replace(" my "," hers ");
			s = s.Replace(" myself "," herself ");
			s = s.Replace(" mine "," hers ");
			s = s.Replace(" with you "," with me ");
			s = s.Replace(" for you "," for me ");
			s = s.Replace(" you "," I ");
			s = s.Replace(" your "," my ");
			s = s.Replace(" yours "," mine ");
			s = s.Replace(" yourself "," myself ");
    
			return s;
		}
    
		string Gender(string line)
		{
			string s = line;
    
			s = s.Replace(" HE "," xSHE ");
			s = s.Replace(" HIM "," xHER ");
			s = s.Replace(" HIS "," xHERS ");
			s = s.Replace(" SHE "," HE ");
			s = s.Replace(" HER "," HIM ");
			s = s.Replace(" HERS "," HIS ");
			s = s.Replace(" xSHE "," SHE ");
			s = s.Replace(" xHER "," HER ");
			s = s.Replace(" xHERS "," HERS ");
    
			s = s.Replace(" he "," Xshe ");
			s = s.Replace(" him "," Xher ");
			s = s.Replace(" his "," Xhers ");
			s = s.Replace(" she "," he ");
			s = s.Replace(" her "," him ");
			s = s.Replace(" hers "," his ");
			s = s.Replace(" Xshe "," she ");
			s = s.Replace(" Xher "," her ");
			s = s.Replace(" Xhers "," hers ");
    
			return s;
		}
    
		string CleanUp(string ask)
		{
			string s = " " + ask + " ";
    
			s = s.Replace(".","");
			s = s.Replace("!","");
			s = s.Replace("?","");
			s = s.Replace(",","");
			s = s.Replace(";","");
			s = s.Replace(":","");
			s = s.Replace("_","");
			s = s.Replace("@","");
			s = s.Replace("*","");
			s = s.Replace("=","");
			s = s.Replace("(","");
			s = s.Replace(")","");
			s = s.Replace("[","");
			s = s.Replace("]","");
			s = s.Replace("{","");
			s = s.Replace("}","");
			s = s.Replace("<","");
			s = s.Replace(">","");
			s = s.Replace("#","");
			s = s.Replace("$","");
			s = s.Replace("%","");
			s = s.Replace("`","'");
			s = s.Replace("\"","");
			s = s.Replace("^","");
			s = s.Replace("~","");
			s = s.Replace("/","");
			s = s.Replace("\\","");
			s = s.Replace("|","");
			s = s.Replace("_","");
			s = s.Replace(" HELLP "," HELP ");
			s = s.Replace(" BECUSE "," BECAUSE ");
			s = s.Replace(" BECASUE "," BECAUSE ");
			s = s.Replace(" BECUASE "," BECAUSE ");
			s = s.Replace(" BELEIVE "," BELEIVE ");
			s = s.Replace(" WAHT "," WHAT ");
			s = s.Replace(" YUO "," YOU ");
			s = s.Replace(" IAM "," I AM ");
			s = s.Replace(" ITS A "," IT IS A ");
			s = s.Replace(" FAV "," FAVORITE ");
			s = s.Replace(" FAVOURITE"," FAVORITE");
			s = s.Replace(" COLOUR"," COLOR");
			s = s.Replace(" UR "," YOUR ");
			s = s.Replace(" U "," YOU ");
			s = s.Replace(" OHH"," OH");
			s = s.Replace(" HEHE"," HA");
			s = s.Replace(" YEAH "," YES ");
			s = s.Replace(" YEP "," YES ");
			s = s.Replace(" YOU'D "," YOU WOULD ");
			s = s.Replace(" YOU'RE "," YOU ARE ");
			s = s.Replace(" YOU R "," YOU ARE ");
			s = s.Replace(" U R "," YOU ARE ");
			s = s.Replace(" YOU'VE "," YOU HaVE ");
			s = s.Replace(" YOU'LL "," YOU WILL ");
			s = s.Replace(" DIDN'T"," DID NOT");
			s = s.Replace(" COULDN'T"," COULD NOT");
			s = s.Replace(" AIN'T"," IS NOT");
			s = s.Replace(" ISN'T"," IS NOT");
			s = s.Replace(" IT'S "," IT IS ");
			s = s.Replace(" AREN'T "," ARE NOT ");
			s = s.Replace(" WHERE'S "," WHERE IS ");
			s = s.Replace(" HAVEN'T"," HAVE NOT");
			s = s.Replace(" HASN'T"," HAS NOT");
			s = s.Replace(" WEREN'T "," WERE NOT ");
			s = s.Replace(" CAN'T"," CAN NOT");
			s = s.Replace(" CANNOT"," CAN NOT");
			s = s.Replace(" WHOS "," WHO IS ");
			s = s.Replace(" HOW'S "," HOW IS ");
			s = s.Replace(" HOWS "," HOW IS ");
			s = s.Replace(" WHATS "," WHAT IS ");
			s = s.Replace(" WHAT'S "," WHAT IS ");
			s = s.Replace(" THATS "," THAT IS ");
			s = s.Replace(" THAT'S "," THAT IS ");
			s = s.Replace(" DOESN'T "," DOES NOT ");
			s = s.Replace(" DON'T "," DO NOT ");
			s = s.Replace(" DONT "," DO NOT ");
			s = s.Replace(" WASN'T "," WAS NOT ");
			s = s.Replace(" WON'T "," WILL NOT ");
			s = s.Replace(" HADN'T "," HAD NOT ");
			s = s.Replace(" WOULDN'T "," WOULD NOT ");
			s = s.Replace(" SHOULDN'T "," SHOULD NOT ");
			s = s.Replace(" LET'S "," LET US ");
			s = s.Replace(" THEY'RE "," THEY ARE ");
			s = s.Replace(" WE'LL "," WE WILL ");
			s = s.Replace(" HE'LL "," HE WILL ");
			s = s.Replace(" I'LL "," I WILL ");
			s = s.Replace(" I'VE "," I HAVE ");
			s = s.Replace(" WE'VE "," WE HAVE ");
			s = s.Replace(" WE'RE "," WE ARE ");
			s = s.Replace(" I'D "," I WOULD ");
			s = s.Replace(" I'M "," I AM ");
			s = s.Replace(" SHE'D "," SHE WOULD ");
			s = s.Replace(" HE'D "," HE WOULD ");
			s = s.Replace(" HE'S "," HE IS ");
			s = s.Replace("'"," ");
    
			return s.Trim();
		}
	}
}
