using System;
using SharperCV;
using SharperCV.Haar;
using System.IO;

namespace PKDPlugin
{
	public class FaceTrackerProxyServer
	{
		[STAThread]
		static void Main(string[] args)
		{
			FaceTrackerProxyServer faceTrackerProxyServer = new FaceTrackerProxyServer();
			faceTrackerProxyServer.Run();
		}

		#region Fields / Constructor
		
		public System.Collections.ArrayList trackedFacesList = null;
		public System.Collections.ArrayList waitingToBeATrackedFaceList = null;
		public int numberOfTrackedFaces = 0;
		public FaceTrackerProxyHelper faceTrackerProxyHelper = null;
		public int[] tempHeadSize;
		public int[] tempHeadX;
		public int[] tempHeadY;
		public int[] tempHeadId;

		#region Motion related
		// various tracking parameters (in seconds)
		public double MHI_DURATION = 1;
		public double MAX_TIME_DELTA = 0.5;
		public double MIN_TIME_DELTA = 0.05;
		// number of cyclic frame buffer used for motion detection
		// (should, probably, depend on FPS)
		public int N = 4;

		// ring image buffer
		public SharperCVExtensions.MyCvImage[] buf = null;
		public int last = 0;

		// temporary images
		public SharperCVExtensions.MyCvImage mhi = null; // MHI
		public SharperCVExtensions.MyCvImage mask = null; // valid orientation mask
		#endregion
		public FaceTrackerProxyServer()
		{ 
			//There are no events that we want to register for: we only export data
			//string [] helptxt = {"Detects faces and motion",	" ", "Q quits the program"};
			//CvWindow helpWin = new CvWindow("Help", helptxt);
			this.trackedFacesList = new System.Collections.ArrayList();
			this.waitingToBeATrackedFaceList = new System.Collections.ArrayList();
			this.tempHeadId = new int[ 10 ];
			this.tempHeadSize = new int[ 10 ];
			this.tempHeadX = new int [ 10 ];
			this.tempHeadY = new int [ 10 ];

			//Start a server to host remoted objects
			int port = 1978;
			string name = "PKDPlugin.FaceTrackerProxyHelper";
			Type type = Type.GetType( name );
			System.Runtime.Remoting.Channels.Tcp.TcpChannel tcpServerChannel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel( port );
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel( tcpServerChannel );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( type, name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );
	
			//The trick -- get an instance of the singleton back from the server to initialize the class member
			//Now we can modify the object and changes will be mirrored on the client
			string uri = "tcp://localhost:" + port + "/" + name;
			this.faceTrackerProxyHelper = ( PKDPlugin.FaceTrackerProxyHelper ) Activator.GetObject( type, uri );
		}

		#endregion
		#region Methods
		/// <summary>
		/// Updates the trackedFaceList, given a list of faces
		/// </summary>
		/// <param name="facesList"></param>
		/// <param name="trackedFacesList"></param>
		/// <returns></returns>
		public void Match( System.Collections.ArrayList facesList )
		{
			System.Collections.ArrayList matchedTrackedFacesList = new System.Collections.ArrayList();
			System.Collections.ArrayList unMatchedTrackedFacesList = new System.Collections.ArrayList();

			System.Collections.ArrayList unMatchedFacesList = ( System.Collections.ArrayList )facesList.Clone();

			//for each previously matched tracked face, match to new face that is in bounding box and has comparable size
			foreach( TrackedFace trackedFace in this.trackedFacesList )
			{
				trackedFace.isMatched = false;
				foreach( SharperCV.CvRect face in facesList )
				{
					//match
					if( Calculator.DoesBound( trackedFace.boundingBox, face ) && Calculator.SimilarSize( trackedFace.boundingBox.height, face.height ) )
					{
						trackedFace.Match( face );
						unMatchedFacesList.Remove( face );
						matchedTrackedFacesList.Add( trackedFace );
						facesList.Remove( face );
						break;
					}
				}
				//no match
				if( !trackedFace.isMatched ) 
					unMatchedTrackedFacesList.Add( trackedFace );
			}
			#region defunct
			//for each unmatched previously matched tracked face, calc distance to all new faces that are still unmatched and have comparable size. Min is match
			/*
			foreach( TrackedFace trackedFace in unMatchedTrackedFacesList )
			{
				int minIndex = 0;
				int index = 0;
				double minDistance = 9999;
				double distance = 0;
				
				foreach( SharperCV.CvRect face in unMatchedFacesList )
				{
					if( Calculator.SimilarSize( trackedFace.boundingBox.height, face.height ) )
					{
						distance = Calculator.Distance( trackedFace.boundingBox, face );
						if( distance < minDistance )
						{
							minDistance = distance;
							minIndex = index;
						}
					}
					index++;
				}
				if( unMatchedFacesList.Count == 0 )
					break;
				//Min distance is match
				SharperCV.CvRect face2 = ( SharperCV.CvRect ) unMatchedFacesList[ minIndex ];
				trackedFace.Match( face2 );
				unMatchedFacesList.RemoveAt( minIndex );
				matchedTrackedFacesList.Add( trackedFace );
			}
			*/
			#endregion
			//for each unmatched previously matched tracked face, decrease weight (100 frames to disappear)
			foreach( TrackedFace trackedFace in unMatchedTrackedFacesList )
			{
				trackedFace.matchCount--;
			}
			
			//Update the tracked list
			this.trackedFacesList.Clear();
			this.trackedFacesList.AddRange( matchedTrackedFacesList );
			this.trackedFacesList.AddRange( unMatchedTrackedFacesList );

			//Remove old faces from the tracked list
			System.Collections.ArrayList temp = ( System.Collections.ArrayList) this.trackedFacesList.Clone();
			foreach( TrackedFace trackedFace in this.trackedFacesList )
				if( trackedFace.matchCount < 0 )
					temp.Remove( trackedFace );
			this.trackedFacesList = temp;
			
			//Add new faces the the tracked list
			foreach( CvRect face in unMatchedFacesList )
			{
				this.trackedFacesList.Add( new TrackedFace( this.numberOfTrackedFaces++, face ) );
			}
		}

		public void Run()
		{
			CvWindow mainWin = new CvWindow("Face & Motion Detection");    // create a window
			CvCapture theSrc = new CvCapture(-1, false);       // a camera source
			CvImage theFrame = theSrc.QueryFrame();            // an image for the frame
			
			SharperCVExtensions.MyCvImage motion = null;
			TrackedFace aTrack;
			SharperCV.CvPoint target;
			SharperCV.CvPoint center = new CvPoint( theFrame.Size.width / 2, theFrame.Size.height / 2 );

			// create the Haar Classifier
			ClassifierCascade c = new ClassifierCascade("<default_face_cascade>", new CvSize(24, 24));
			HiddenClassifierCascade hc = new HiddenClassifierCascade(c, null, null, null, 1);
 
			for (;;)     // now run the frame grab and detect loop
			{
				theFrame = theSrc.QueryFrame();
			
				#region Do MHI
				if( theFrame != null )
				{
					if( motion == null )
					{
						motion = new SharperCVExtensions.MyCvImage( theFrame.Size, SharperCV.BitDepths.IPL_DEPTH_8U, 3 );
					}
				}
				update_mhi( theFrame, motion, 30 );
				#endregion

				theFrame = theFrame.And( motion, null );

				#region Do Haar
				// find the face(s) within the image
				CvRect[] faces = hc.DetectObjects(theFrame, 1.2, 2, PruningFlags.CannyPruning);
				System.Collections.ArrayList facesList = new System.Collections.ArrayList( faces );

				//Match new faces to tracked faces, creating new tracks for unmatched faces
				Match( facesList );
				
				foreach( TrackedFace trackedFace in this.trackedFacesList )
				{
					theFrame.PutText( trackedFace.id.ToString() +":"+ trackedFace.matchCount.ToString(), trackedFace.center, SharperCV.CvColor.Red );
					theFrame.Rectangle( trackedFace.boundingBox, new CvColor(255,255,0), 3);
				}
		
				#endregion

				#region Update Shadow Fact
				//I think originally this way messy b/c of the multislot issue. Now I can't remember, 
				//so it seems like a good thing to try to clean up. For instance, are all these temp 
				//values really necessary?
				
				//Convert tracked faces list into a format jess can understand
				double minDistanceToCenter = 999;
				double distance = 0;
				for( int i = 0; i < 10; i++ )
				{
					if( i < this.trackedFacesList.Count )
					{
						aTrack = ( TrackedFace )this.trackedFacesList[ i ];
						target = Calculator.BetweenTheEyes( aTrack.boundingBox );

						this.tempHeadId[ i ]	= aTrack.id;
						this.tempHeadX[ i ]		= target.x;
						this.tempHeadY[ i ]		= target.y;
						this.tempHeadSize[ i ]	= aTrack.boundingBox.height;
						distance = Calculator.Distance( target, center );
						if( distance < minDistanceToCenter )
						{
							minDistanceToCenter = distance;
							this.faceTrackerProxyHelper.centerFace = i;
						}
					}
					else
					{
						this.tempHeadId[ i ]	= 0;
						this.tempHeadX[ i ]		= 0;
						this.tempHeadY[ i ]		= 0;
						this.tempHeadSize[ i ]	= 0;
					}
				}

				//Get it all in the proxy
				this.faceTrackerProxyHelper.headId0 = this.tempHeadId[ 0 ];
				this.faceTrackerProxyHelper.headId1 = this.tempHeadId[ 1 ];
				this.faceTrackerProxyHelper.headId2 = this.tempHeadId[ 2 ];
				this.faceTrackerProxyHelper.headId3 = this.tempHeadId[ 3 ];
				this.faceTrackerProxyHelper.headId4 = this.tempHeadId[ 4 ];
				this.faceTrackerProxyHelper.headId5 = this.tempHeadId[ 5 ];
				this.faceTrackerProxyHelper.headId6 = this.tempHeadId[ 6 ];
				this.faceTrackerProxyHelper.headId7 = this.tempHeadId[ 7 ];
				this.faceTrackerProxyHelper.headId8 = this.tempHeadId[ 8 ];
				this.faceTrackerProxyHelper.headId9 = this.tempHeadId[ 9 ];

				this.faceTrackerProxyHelper.headX0 = this.tempHeadX[ 0 ];
				this.faceTrackerProxyHelper.headX1 = this.tempHeadX[ 1 ];
				this.faceTrackerProxyHelper.headX2 = this.tempHeadX[ 2 ];
				this.faceTrackerProxyHelper.headX3 = this.tempHeadX[ 3 ];
				this.faceTrackerProxyHelper.headX4 = this.tempHeadX[ 4 ];
				this.faceTrackerProxyHelper.headX5 = this.tempHeadX[ 5 ];
				this.faceTrackerProxyHelper.headX6 = this.tempHeadX[ 6 ];
				this.faceTrackerProxyHelper.headX7 = this.tempHeadX[ 7 ];
				this.faceTrackerProxyHelper.headX8 = this.tempHeadX[ 8 ];
				this.faceTrackerProxyHelper.headX9 = this.tempHeadX[ 9 ];

				this.faceTrackerProxyHelper.headY0 = this.tempHeadY[ 0 ];
				this.faceTrackerProxyHelper.headY1 = this.tempHeadY[ 1 ];
				this.faceTrackerProxyHelper.headY2 = this.tempHeadY[ 2 ];
				this.faceTrackerProxyHelper.headY3 = this.tempHeadY[ 3 ];
				this.faceTrackerProxyHelper.headY4 = this.tempHeadY[ 4 ];
				this.faceTrackerProxyHelper.headY5 = this.tempHeadY[ 5 ];
				this.faceTrackerProxyHelper.headY6 = this.tempHeadY[ 6 ];
				this.faceTrackerProxyHelper.headY7 = this.tempHeadY[ 7 ];
				this.faceTrackerProxyHelper.headY8 = this.tempHeadY[ 8 ];
				this.faceTrackerProxyHelper.headY9 = this.tempHeadY[ 9 ];

				this.faceTrackerProxyHelper.headSize0 = this.tempHeadSize[ 0 ];
				this.faceTrackerProxyHelper.headSize1 = this.tempHeadSize[ 1 ];
				this.faceTrackerProxyHelper.headSize2 = this.tempHeadSize[ 2 ];
				this.faceTrackerProxyHelper.headSize3 = this.tempHeadSize[ 3 ];
				this.faceTrackerProxyHelper.headSize4 = this.tempHeadSize[ 4 ];
				this.faceTrackerProxyHelper.headSize5 = this.tempHeadSize[ 5 ];
				this.faceTrackerProxyHelper.headSize6 = this.tempHeadSize[ 6 ];
				this.faceTrackerProxyHelper.headSize7 = this.tempHeadSize[ 7 ];
				this.faceTrackerProxyHelper.headSize8 = this.tempHeadSize[ 8 ];
				this.faceTrackerProxyHelper.headSize9 = this.tempHeadSize[ 9 ];


				this.faceTrackerProxyHelper.centerFaceHeadSize = this.tempHeadSize[ this.faceTrackerProxyHelper.centerFace ];
				this.faceTrackerProxyHelper.centerFaceX = this.tempHeadX[ this.faceTrackerProxyHelper.centerFace ];
				this.faceTrackerProxyHelper.centerFaceY = this.tempHeadY[ this.faceTrackerProxyHelper.centerFace ];
				this.faceTrackerProxyHelper.numberHeadsTracked = this.trackedFacesList.Count < 10 ? this.trackedFacesList.Count : 10;
			
				#endregion
				// display the image
				mainWin.Image = theFrame; 

				int key = CvWindow.WaitKey(1);
				if (key == 'q' || key == 'Q' || key == 27) break;
				if (key == 'r') theSrc.positionFrameNum = 500;
			}
		}

		void  update_mhi( CvImage img, SharperCVExtensions.MyCvImage dst, int diff_threshold )
		{
			double timestamp = System.Diagnostics.Process.GetCurrentProcess().UserProcessorTime.TotalMilliseconds/1000.0; // get current time in seconds
			CvSize size = img.Size; // get current frame size
			int i, idx1 = last, idx2;
			SharperCVExtensions.MyCvImage silh;
			
			// allocate images at the beginning or
			// reallocate them if the frame size is changed
			if( mhi == null || mhi.Size.width != size.width || mhi.Size.height != size.height ) 
			{
				if( buf == null ) 
				{
					buf = new SharperCVExtensions.MyCvImage[ this.N ]; 
				}
		        
				for( i = 0; i < N; i++ ) 
				{
					buf[i] = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_8U, 1 );
					buf[ i ].Zero();
				}
				
				mhi = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_32F, 1 );
				mhi.Zero();
				mask = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_8U, 1 );
			}

			img.CvtColor( buf[last], SharperCV.ColorConversion.BGR2GRAY ); // convert frame to grayscale

			idx2 = (last + 1) % N; // index of (last - (N-1))th frame
			last = idx2;

			silh = buf[idx2];
			buf[ idx1 ].AbsDiff( buf[idx2], silh ); // get difference between frames
		    
			silh.Threshold( silh, diff_threshold, 1, SharperCV.ThresholdType.THRESH_BINARY ); // and threshold it
			SharperCVExtensions.Extensions.cvUpdateMotionHistory( silh.myArrHandle, mhi.myArrHandle, timestamp, MHI_DURATION ); // update MHI

			SharperCVExtensions.Extensions.cvConvertScale( mhi.myArrHandle, mask.myArrHandle, 255.0/MHI_DURATION,
				(MHI_DURATION - timestamp)*255.0/MHI_DURATION );
			dst.Zero();
			dst.CvtPlaneToPix( mask, mask, mask );
		}		
		#region Defunct
		/*
		/// <summary>
		/// The data we want to export is the location and size of the head, as well as motion components
		/// </summary>
		/// <returns></returns>
		public override void DeclareExports( jess.Rete engine )
		{
			jess.Deftemplate deftemplate = new jess.Deftemplate( "faceDetect", "face detection data", engine );
			deftemplate.addSlot( "headSize", jess.Funcall.NIL, "INTEGER" );
			deftemplate.addSlot( "headX", jess.Funcall.NIL, "INTEGER" );
			deftemplate.addSlot( "headY", jess.Funcall.NIL, "INTEGER" );
			engine.addDeftemplate( deftemplate );
		}

		public override void Export( jess.Rete engine )
		{
			//For each head being tracked, do
			jess.Fact fact = new jess.Fact( "faceDetect", engine );
			fact.setSlotValue( "headSize", new jess.Value( this.headSize, jess.RU.INTEGER ) );
			fact.setSlotValue( "headX", new jess.Value( this.headX, jess.RU.INTEGER ) );
			fact.setSlotValue( "headY", new jess.Value( this.headY, jess.RU.INTEGER ) );
			engine.assertFact( fact );
		}
		*/
		#endregion
		#endregion	
	}
}
