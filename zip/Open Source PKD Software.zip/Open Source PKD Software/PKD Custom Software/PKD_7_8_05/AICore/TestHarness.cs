/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace AICore
{
	class TestHarness
	{
		#region Fields / Constructor
		public AICore aiCore;

		public TestHarness()
		{
			this.aiCore = new AICore();
			
			this.aiCore.pluginManager.LoadAllPlugins( this.aiCore.pluginManager.pluginPath, this.aiCore.ruleEngine );

			#region Debug individual plugin loading
			/*
			PKDPlugin.MModalPlugin plugin = new PKDPlugin.MModalPlugin();
			Type t = plugin.GetType();
			string name = "cli." + t.FullName;
			this.aiCore.ruleEngine.defclass( t.Name, name, null );
			this.aiCore.ruleEngine.definstance( t.Name, plugin, true );
			*/
			#endregion

			this.aiCore.CreateUserFunctions();
			this.aiCore.CreateRules();
			
			//Just temporary
			//this.aiCore.ruleEngine.executeCommand( "(OpenComPort 2)" );
			//this.aiCore.ruleEngine.executeCommand( "(UseStories FALSE)" );
			//this.aiCore.ruleEngine.watch( 1 ); //watch rules

			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( RunUntilHalt ));
			thread.Start();
		}
		#endregion
		#region Threads
		[STAThread]
		static void Main(string[] args)
		{
			TestHarness th = new TestHarness();
			th.Interactive();
		}
		/// <summary>
		/// We run until halt on it's own thread. This makes jess fire a rule as soon as it is activated. 
		/// This thread blocks when no rules are activated, and so must be in a thread by itself.
		/// We can also simultaneously run an interactive session.
		/// </summary>
		public void RunUntilHalt()
		{
			while( true )
			{
				try
				{

					this.aiCore.ruleEngine.runUntilHalt();
				}
				catch( System.Exception e )
				{
					Console.WriteLine( e.Message );
				}
			}
		}

		public void Interactive()
		{				
			while( true )
			{
				try
				{
					Console.Write( ">" );
					string input = Console.ReadLine();
					
					jess.Value v = this.aiCore.ruleEngine.executeCommand( input );
					Console.WriteLine( v.toString() );
				}
				catch( System.Exception e )
				{
					if( e.Message != "" )
						Console.WriteLine( e.Message );
					else
					{
						Console.WriteLine( "hidden jess.JessException " );
					}
				}
			}
		}
		#endregion
	}
}
