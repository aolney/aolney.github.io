/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDDialogue
{
	public enum ConversationPriority { Stranger = 0, Acquaintance, Friend };
	/// <summary>
	/// A conversation profile hold information about the last conversational interaction with a person
	/// </summary>
	[Serializable]
	public class ConversationProfile
	{
		public string name;
		public System.DateTime dateTime;
		public string subject;
		public ConversationPriority priority;
		public string[] initiators;

		public ConversationProfile( string name, string subject, ConversationPriority priority, string[] initiators )
		{
			this.name = name;
			this.subject = subject;
			this.priority = priority;
			this.dateTime = System.DateTime.Now;
			this.initiators = initiators;
		}

		public ConversationProfile( string name )
		{
			this.name = name;
			this.subject = "what is your name";
			this.priority = ConversationPriority.Stranger;
			this.dateTime = System.DateTime.Now;
			this.initiators = new string[] { "tell me a joke", "where are you from", "who are your friends" };
		}
	}
}
