using System;

namespace FaceVacsPlugin
{
	/// <summary>
	/// We require a remoting server to make this object available on other machines
	/// </summary>
	class Server
	{
		[STAThread]
		static void Main(string[] args)
		{
			/*
			int port = 1976;
			string name = "FaceVacsPlugin";

			System.Runtime.Remoting.Channels.Tcp.TcpServerChannel tcpServerChannel = new System.Runtime.Remoting.Channels.Tcp.TcpServerChannel( port );
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel( tcpServerChannel );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( Type.GetType( name ), name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );

			Console.WriteLine( "Remoting {0} on port {1}", name, port );
			*/
			Form1 form = new Form1();

			Console.WriteLine("Press any key to quit");
			Console.ReadLine();
		}
	}
}
