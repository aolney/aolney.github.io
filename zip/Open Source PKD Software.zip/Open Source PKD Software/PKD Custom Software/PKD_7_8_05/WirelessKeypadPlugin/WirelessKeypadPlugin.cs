/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	[Serializable]
	public class WirelessKeypadPlugin : AbstractJessPlugin
	{
		#region Fields / Constructor
		public WirelessKeypadProxyHelper wirelessKeypadProxyHelper = null;
		public string command = "";

		public WirelessKeypadPlugin() : base()
		{
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
			this.coreEventHandlerPairList = new System.Collections.ArrayList();		

			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			System.IO.StreamReader reader = new System.IO.StreamReader( "WirelessKeypadProxyServerConnectionString.txt" );
			string uri = reader.ReadLine();
			reader.Close();
			this.wirelessKeypadProxyHelper = ( PKDPlugin.WirelessKeypadProxyHelper )Activator.GetObject( typeof( PKDPlugin.WirelessKeypadProxyHelper ), uri );	

			//We lauch a thread to poll the proxy object for changes. We can't use delegates and events b/c 
			//of the lack of serialization attributes in the ikvm classpath (property change listeners)
			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}

		#endregion
		#region Methods
		/// <summary>
		/// We use a remoted proxy as the data source for the shadow fact. However, the actual plugin
		/// is local, and the local plugin (the actual shadow fact) polls the proxy for changes, only 
		/// updating the shadow fact when a change has occurred.
		/// </summary>
		public void Run()
		{
			string newCommand = "";
			
			while( true )
			{
				//Q is a flag that lets us check if we have already viewed the message
				if( this.wirelessKeypadProxyHelper.key != 'q' )
				{
					newCommand = DecodeMessage( this.wirelessKeypadProxyHelper.key );
					this.propertyChangeSupport.firePropertyChange( "command", this.command, newCommand );
					this.command = newCommand;
					this.wirelessKeypadProxyHelper.key = 'q';
				}
			
				//This can be slow
				System.Threading.Thread.Sleep( 100 );
			}
		}
		public string DecodeMessage( char key )
		{
			string message = "";
			byte[] charArray = new byte[ 1 ];
			charArray[ 0 ] = ( byte )key;
			string theString =  System.Text.Encoding.ASCII.GetString( charArray );
			int number;
			try
			{
				number = int.Parse( theString );
			}
			catch( Exception e )
			{
				Console.WriteLine( e.Message );
				return "";
			}
				switch( number )
				{      
					case 0:
						break;
					case 1:
						message = "lookdoor";
						break;                  
					case 2:   
						message = "lookstool";
						break; 
					case 3:   
						message = "lookcouch";
						break; 
					case 4:  
						message = "playpontification";
						break; 
					case 5:  
						message = "playstory";
						break; 
					case 6:  
						message = "stopspeech";
						break; 
					case 7:   
						message = "unmute";
						break; 
					case 8:   
						break; 
					case 9:   
						message = "happyanimation";
						break; 
				}
				return message;
			}
		#endregion
		#region ShadowFact Accessors
		public string getCommand()
		{
			return this.command;
		}
		#endregion
	}
}
