#region Copyright
/*
Copyright (c) 2009, Andrew M Olney
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the University of Memphis nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
#endregion
using System;
using System.Runtime.Serialization;

namespace VectorSpace
{
	/// <summary>
	/// Utility holds some static methods that don't belong in any particular class
	/// </summary>
	public class Utility
	{
		#region Serialization
		/// <summary>
		/// Write this object to disk
		/// </summary>
		/// <param name="fileName"></param>
		/// <param name="o"></param>
		public static void Serialize( string fileName, object o )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Create );
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = 
					new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			formatter.Serialize( fs, o );
			fs.Close();
		}

		/// <summary>
		/// Read this binary object from disk. Caller has responsibility of casting object to correct type
		/// </summary>
		/// <param name="fileName"></param>
		/// <returns></returns>
		public static object Deserialize( string fileName )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Open );
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = 
					new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			object o = formatter.Deserialize( fs );
			fs.Close();
			return o;
		}
		#endregion
		#region Directory
		/// <summary>
		/// Given a directory name, returns a string of all the files in that directory, 
		/// with file extensions and spaces between file names. Convenient when calling 
		/// CreateLSASpace with lots of source files
		/// </summary>
		/// <param name="directoryName"></param>
		/// <returns></returns>
		public string GetSourceFiles( string directoryName )
		{
			//What files are in the space?
			System.IO.DirectoryInfo di = new System.IO.DirectoryInfo( directoryName );
			System.IO.FileInfo[] fi = di.GetFiles();
			string sourceFiles = "";
			foreach( System.IO.FileInfo info in fi )
				sourceFiles += " " + info.Name;
			return sourceFiles;
		}

		#endregion
		
	}
}
