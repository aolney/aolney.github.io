<%@ Control Language="C#" Debug="true" %>
<%@ Register TagPrefix="community" Namespace="ASPNET.StarterKit.Communities" Assembly="ASPNET.StarterKit.Communities" %>
<%@ import Namespace="ASPNET.StarterKit.Communities" %>
<%@ import Namespace="System" %>
<%@ import Namespace="System.Collections" %>
<%@ import Namespace="System.Collections.Specialized" %>
<%@ import Namespace="System.IO" %>
<%@ import Namespace="System.Xml" %>
<%@ import Namespace="System.Data" %>
<%@ import Namespace="System.Data.SqlClient" %>
<script runat="server">

    protected string mClient;
	protected string mSubject = "New Cases";
	protected string mClass = "Seeker";
    
    protected string mInputStar;
    protected string mInputPath;
    protected string mThatStar;
    protected string mThatPath;
    protected string mTopicStar;
    protected string mTopicPath;

    protected string mInputThat;

    protected Hashtable mStar = new Hashtable();
    protected Hashtable mPath = new Hashtable();
    
    protected SqlConnection cnx;
    
    protected NameTable nt;
    protected XmlNamespaceManager nsmgr;
    protected XmlParserContext xmlContext;

    protected int RecursionLevel = 0;
    
    void Page_Load() {
       string reply = "";
       string asks;
    
       UserInfo objUserInfo = (UserInfo)System.Web.HttpContext.Current.Items["UserInfo"];
       mClient = objUserInfo.Username;
    
       if (Page.IsPostBack) {
          string ask = txtInput.Text;
    
          lblChat3.Text = lblChat2.Text;
          lblTalk3.Text = lblTalk2.Text;
          lblChat2.Text = lblChat1.Text;
          lblTalk2.Text = lblTalk1.Text;
          lblChat1.Text = lblChat.Text;
          lblTalk1.Text = lblTalk.Text;
          lblChat.Text = mClient + ": " + ask;
    
          cnx = new SqlConnection("server=(local);uid=sa;pwd=Password#1;database=AIML;");
          cnx.Open();
    
		  mInputThat = (hdnThat.Text == "") ? "" : fixThat(hdnThat.Text);

		  // split ask into sentences
		  asks = ask.Replace("?",".");
		  asks = asks.Replace("!",".");
		  asks = asks.Replace(";",".");
		  foreach(string s in asks.Split('.'))
		  {
			 if (s.Trim().Length > 0) reply += DoAsk(s);
		  }

		  hdnThat.Text = reply.ToUpper();
          lblTalk.Text = "ChatBot: " + reply;
          txtInput.Text = "";
    
          cnx.Close();
       }
    
    }

	string DoAsk(string ask)
	{
		long m = 0;
		string reply;

		if ((m = Match(ask)) > 0)
		{
			reply = GetTemplate(m);
			if (reply != "")
			{
				nt = new NameTable();
				nsmgr = new XmlNamespaceManager(nt);
				nsmgr.AddNamespace("aiml", "urn:aimlsnip");
				xmlContext = new XmlParserContext(null, nsmgr, null, XmlSpace.None);
				reply = evaluate(reply);
			}
		}
		else
		{
			reply = GetReply(ask);
		}

		return reply;
	}
    
    string GetReply(string Ask) {
       System.Random autoRand = new System.Random( );
       string ans = "What?";
       double pick = autoRand.NextDouble();
    
       if (pick > .1) ans = "The botmaster hasn't programmed me yet.";
       if (pick > .2) ans = "I wish I had a brain.";
       if (pick > .3) ans = "I don't know what to say!";
       if (pick > .4) ans = "I am not done or even working yet.";
       if (pick > .5) ans = "Someday I'll be able to answer you.";
       if (pick > .6) ans = "There is nothing in my mind!";
       if (pick > .7) ans = "I am not able to respond at this time.";
       if (pick > .8) ans = "That does (I do) not compute.";
       if (pick > .9) ans = "What do you want from me?";
    
       return ans;
    }
    
    long FindTemplateID(long ID)
    {
		long ans = 0;
		SqlCommand cmd = new SqlCommand("SelectTemplateByNodeID", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@NodeID",SqlDbType.Int).Value = ID;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (Int32) rdr["TemplateID"];
			rdr.Close();
		}

		return ans;
    }
    
	string GetTemplate(long ID)
	{
		string ans = "";
		SqlCommand cmd = new SqlCommand("SelectTemplate", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@TemplateID",SqlDbType.Int).Value = ID;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (string) rdr["Script"];
			rdr.Close();
		}

		return ans;
	}
	string ListContexts(long ID)
	{
		string ans = "";
		SqlCommand cmd = new SqlCommand("SelectListByTier", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans += (string) rdr["Type"] + ";";
			rdr.Close();
		}

		return ans;
	}

	long FindContext(long ID, string Type)
	{
		long ans = 0;
		SqlCommand cmd = new SqlCommand("SelectNodeByTierType", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
		cmd.Parameters.Add("@Type",SqlDbType.VarChar,250).Value = Type;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (Int32) rdr["NodeID"];
			rdr.Close();
		}

		return ans;
	}
    
	string GetWord(long ID)
	{
		string ans = "";
		SqlCommand cmd = new SqlCommand("SelectWordByNodeID", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@NodeID",SqlDbType.Int).Value = ID;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (string) rdr["Word"];
			rdr.Close();
		}

		return ans;
	}

	long FindWord(long ID, string Token)
	{
		long ans = 0;
		SqlCommand cmd = new SqlCommand("SelectNodeByTierWord", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
		cmd.Parameters.Add("@Word",SqlDbType.VarChar,250).Value = Token;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (Int32) rdr["NodeID"];
			rdr.Close();
		}

		return ans;
	}
    
	string GetVar(string Tag)
	{
		return GetPredicate(mSubject,mClass,Tag,"");
	}

	string GetPredicate(string s, string c, string t, string d)
	{
		string ans = d;
		SqlCommand cmd = new SqlCommand("SelectPredicate", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
		cmd.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = s;
		cmd.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = c;
		cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t;
		SqlDataReader rdr = cmd.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (string) rdr["Token"];
			rdr.Close();
		}

		return ans;
	}
   
	void SetVar(string Tag, string Token)
	{
//		if (Tag.ToLower().Equals("name")) SetSeeker(Token.Trim());

		SetPredicate(mSubject, mClass, Tag, Token.Trim());
	}

	void SetPredicate(string s, string c,string t, string v)
	{
		SqlCommand cmd;
		Int32 ret;

		if (v == "")
		{
			cmd = new SqlCommand("DeletePredicate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
			cmd.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = mSubject;
			cmd.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = mClass;
			cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
			ret = cmd.ExecuteNonQuery();
			return;
		}

		string ans = "";
		SqlCommand cmdSel = new SqlCommand("SelectPredicate", cnx);
		cmdSel.CommandType = CommandType.StoredProcedure;
		cmdSel.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
		cmdSel.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = mSubject;
		cmdSel.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = mClass;
		cmdSel.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
		SqlDataReader rdr = cmdSel.ExecuteReader();

		if (rdr != null)
		{
			while (rdr.Read()) ans = (string) rdr["Token"];
			rdr.Close();
		}

		if (ans == "") cmd = new SqlCommand("InsertPredicate", cnx);
		else           cmd = new SqlCommand("UpdatePredicate", cnx);
		cmd.CommandType = CommandType.StoredProcedure;
		cmd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = mClient;
		cmd.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = mSubject;
		cmd.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = mClass;
		cmd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = t.Trim();
		cmd.Parameters.Add("@Token",SqlDbType.Text).Value = v.Trim();
		ret = cmd.ExecuteNonQuery();
	}
    
    string fixThat(string that)
    {
        string t = that.Trim();
    
        t = t.Replace("?",".");
        t = t.Replace("!",".");
        t = t.Replace("..",".");
    
        string[] thats = t.Split('.');
        int m = thats.Length - 1;
        if (thats[m] == "") m--;
        return CleanUp(thats[m]);
    }

	string GetContextInput(string ctype)
	{
		if (ctype.Equals("that")) return mInputThat;
		return GetVar(ctype).ToUpper();
	}
    
	long Match(string InputPattern)
	{
		mStar.Clear();
		mPath.Clear();
		long m = MatchPattern(1, 1, "input", CleanUp(InputPattern.ToUpper()), "", new Stack());
		return m;
	}
    
	long MatchPattern(long Parent, long ID, string Type, string InputPath, string Path, Stack Star)
	{
		long m = 0;
		long n = 0;
		string str = InputPath.TrimStart(null);
		string contexts = "";

		if (str == "")
		{
			if (ID < 0) return 0;

			contexts = ListContexts(ID);
			if (contexts.Length > 0)
			{
				InternContext(Type, Path, Star);
				foreach (string ctype in contexts.Split(';'))
				{
					if (ctype.Length > 0)
					{
						n = -FindContext(ID, ctype);
						if (ctype == "if")
						{
							// need to do:
							// find the pattern(s) for n
							// evaluate the template(s) at -(node id for pattern(n))
							// when true return node id for pattern(n)
						}
						else
						{
							m = MatchPattern(n, n, ctype, GetContextInput(ctype), "", new Stack());
						}
						if (m > 0) return m;
					}
				}
				n = FindTemplateID(ID);
			}
			else
			{
				n = FindTemplateID(ID);
				if (n > 0) InternContext(Type, Path, Star);
			}

			return n;
		}

		int at = str.IndexOf(" ");
		string word = str;
		string tail = "";

		if (at >= 0)
		{
			word = str.Substring(0,at).TrimEnd(null);
			tail = str.Substring(at);
		}

		if ((n = FindWord(ID, "_")) > 0)
		{
			Star.Push(word);
			m = MatchPattern(ID, n, Type, tail, Path + " _", Star);
			if (m > 0) return m;
			Star.Pop();
		}

		if ((n = FindWord(ID, word)) > 0)
		{
			m = MatchPattern(ID, n, Type, tail, Path + " " + word, Star);
			if (m > 0) return m;
		}

		if ((n = FindWord(ID, "*")) > 0)
		{
			Star.Push(word);
			m = MatchPattern(ID, n, Type, tail, Path + " *", Star);
			if (m > 0) return m;
			Star.Pop();
		}

		if ((n = FindWord(ID, "@")) > 0)
		{
			Star.Push(str);
			m = MatchPattern(ID, n, Type, "", Path + " *", Star);
			if (m > 0) return m;
			Star.Pop();
		}

		str = GetWord(ID);
		if (str == "*" || str == "_")
		{
			Star.Push(Star.Pop() + " " + word);
			return MatchPattern(Parent, ID, Type, tail, Path, Star);
		}

		return m;
	}

	void InternContext(string Type, string Path, Stack Star)
	{
		string star = "";
		IEnumerator n;

		n = Star.GetEnumerator();
		while (n.MoveNext())
		{
			if (star != "") star = "," + star;
			star = n.Current + star;
		}

		mStar[Type] = star;
		mPath[Type] = Path.Trim(null);
	}

	string docmds(string xmlFrag)
	{
		if (xmlFrag == "") return "";

		string s = "";
		string a = "";
		string v = "";
		string n = "";
		string t = "";
		string x = "";
		long m;
		int i;
		bool flg = false;
		System.Random autoRand = new System.Random();

		XmlDocument xmlDoc = new XmlDocument();
		XmlNodeList elemList;
		XmlTextReader XmlRdr = new XmlTextReader("<template>" + xmlFrag + "</template>", XmlNodeType.Element, xmlContext);

		flg = XmlRdr.Read();
		while (flg)
		{
			switch (XmlRdr.NodeType) {
				
			case XmlNodeType.Text:
			case XmlNodeType.CDATA:
				s += XmlRdr.Value;
				break;
				
			case XmlNodeType.Element:
				if (XmlRdr.Name == "name")       	  s += getbot("name");
				else if (XmlRdr.Name == "size")       s += getbot("size");
				else if (XmlRdr.Name == "date")       s += DateTime.Now;
				else if (XmlRdr.Name == "id")         s += getbot("id");
				else if (XmlRdr.Name == "version")    s += getbot("version");
				else if (XmlRdr.Name == "star2")      s += ((string)mStar["input"]).Split(',')[1];
				else if (XmlRdr.Name == "thatstar2")  s += ((string)mStar["that"]).Split(',')[1];
				else if (XmlRdr.Name == "topicstar2") s += ((string)mStar["topic"]).Split(',')[1];
				else if (XmlRdr.Name == "bot")
				{
					n = XmlRdr.GetAttribute("name");
					if (n == null) s += getbot("bot"); else s += getbot(n);
				}
				else if (XmlRdr.Name == "get")
				{
					n = XmlRdr.GetAttribute("name");
					s += GetVar(n);
				}
				else if (XmlRdr.Name == "set")
				{
					n = XmlRdr.GetAttribute("name");
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
					s += t;
					SetVar(n, t);
				}
				else if (XmlRdr.Name == "star")
				{
					a = "" + XmlRdr.GetAttribute("index");
					n = "" + XmlRdr.GetAttribute("name");
					if (n == "") n = "input";
					if (a == "") s += (((string)mStar[n]).Split(','))[0];
					else s += (((string)mStar[n]).Split(','))[int.Parse(a) - 1];
				}
				else if (XmlRdr.Name == "thatstar")
				{
					a = "" + XmlRdr.GetAttribute("index");
					if (a == "") s += (((string)mStar["that"]).Split(','))[0];
					else s += (((string)mStar["that"]).Split(','))[int.Parse(a) - 1];
				}
				else if (XmlRdr.Name == "topicstar")
				{
					a = "" + XmlRdr.GetAttribute("index");
					if (a == "") s += (((string)mStar["topic"]).Split(','))[0];
					else s += (((string)mStar["topic"]).Split(','))[int.Parse(a) - 1];
				}
				else if (XmlRdr.Name == "that")
				{
					a = "" + XmlRdr.GetAttribute("index");
					// need to parse multiple index, i.e., index="2,1"
					t = lblThat.Text;
					if (a == "1") t = lblTalk1.Text;
					if (a == "2") t = lblTalk2.Text;
					if (a == "3") t = lblTalk3.Text;
					// need to split into sentences instead of fixthat
					if (t.Length > 8) s += fixThat(t.Substring(8));
				}
				else if (XmlRdr.Name == "input")
				{
					a = XmlRdr.GetAttribute("index");
					// need to parse multiple index, i.e., index="2,1"
					t = lblChat.Text;
					if (a == "1") t = lblChat1.Text;
					if (a == "2") t = lblChat2.Text;
					if (a == "3") t = lblChat3.Text;
					// need to split into sentences
					if (t.Length > mClient.Length) s += t.Substring(mClient.Length + 1);
				}
				else if (XmlRdr.Name == "lowercase")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
					s += t.ToLower();
				}
				else if (XmlRdr.Name == "uppercase")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(t);
					s += t.ToUpper();
				}
				else if (XmlRdr.Name == "formal")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
					string[] w = t.Split(' ');
					for (m = 0;m < w.Length;m++)
					{
						if (m > 0) s += " ";
						s += w[m].Substring(0,1).ToUpper() + w[m].Substring(1).ToLower();
					}
				}
				else if (XmlRdr.Name == "sentence")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
					s += t.Substring(0,1).ToUpper() + t.Substring(1).ToLower();
				}
				else if (XmlRdr.Name == "person")
				{
					if (XmlRdr.IsEmptyElement)
					{
						t = (((string)mStar["input"]).Split(','))[0];
					}
					else
					{
						x = "" + XmlRdr.ReadInnerXml();
						flg = false;
						t = docmds(x);
					}
					s += Person(t);
				}
				else if (XmlRdr.Name == "person2")
				{
					if (XmlRdr.IsEmptyElement)
					{
						t = (((string)mStar["input"]).Split(','))[0];
					}
					else
					{
						x = "" + XmlRdr.ReadInnerXml();
						flg = false;
						t = docmds(x);
					}
					s += Person2(t);
				}
				else if (XmlRdr.Name == "personf")
				{
					if (XmlRdr.IsEmptyElement)
					{
						t = (((string)mStar["input"]).Split(','))[0];
					}
					else
					{
						x = "" + XmlRdr.ReadInnerXml();
						flg = false;
						t = docmds(x);
					}
					s += Personf(t);
				}
				else if (XmlRdr.Name == "gender")
				{
					if (XmlRdr.IsEmptyElement)
					{
						t = (((string)mStar["input"]).Split(','))[0];
					}
					else
					{
						x = "" + XmlRdr.ReadInnerXml();
						flg = false;
						t = docmds(x);
					}
					s += Gender(t);
				}
				else if (XmlRdr.Name == "think")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
				}
				else if (XmlRdr.Name == "srai")
				{
					x = "" + XmlRdr.ReadInnerXml();
					flg = false;
					v = docmds(x).Trim();
					Hashtable savStar = new Hashtable();
					IDictionaryEnumerator idx = mStar.GetEnumerator();
					while (idx.MoveNext()) savStar[idx.Key] = idx.Value;
					if ((m = Match(v)) > 0) t = GetTemplate(m); else t = "";
					s += evaluate(t);
					mStar = savStar;
				}
				else if (XmlRdr.Name == "condition")
				{
					n = "" + XmlRdr.GetAttribute("name");
					v = "" + XmlRdr.GetAttribute("value");
					if (n != "" && v != "")
					{
						// <condition name="tag" value="token">
						if (GetVar(n) == v)
						{
							x = XmlRdr.ReadInnerXml();
							flg = false;
							t = docmds(x);
							s += t;
						}
					}
					else
					{
						x = XmlRdr.ReadInnerXml();
						flg = false;
						if (x != "")
						{
							xmlDoc.LoadXml("<condition>" + x + "</condition>");
							elemList = xmlDoc.GetElementsByTagName("li");
							if (n != "")
							{
								// <condition name="tag"> <li value="token">
								t = GetVar(n);
								for (i = 0; i < elemList.Count; i++)
								{
									v = "" + elemList[i].Attributes["value"];
									if (t == v)
									{
										x = "" + elemList[i].InnerXml;
										t = docmds(x);
										s += t;
										break;
									}
								}
							}
							else
							{
								// <condition> <li name="tag" value="token">
								for (i = 0; i < elemList.Count; i++)
								{
									n = "" + elemList[i].Attributes["name"];
									v = "" + elemList[i].Attributes["value"];
									if (GetVar(n) == v)
									{
										x = "" + elemList[i].InnerXml;
										t = docmds(x);
										s += t;
										break;
									}
								}
							}
						}
					}
				}
				else if (XmlRdr.Name == "random")
				{
					x = XmlRdr.ReadInnerXml();
					flg = false;
					if (x != "")
					{
						xmlDoc.LoadXml("<random>" + x + "</random>");
						elemList = xmlDoc.GetElementsByTagName("li");
						i = autoRand.Next(elemList.Count);
						x = "" + elemList[i].InnerXml;
					}
					t = docmds(x);
					s += t;
				}
				else if (XmlRdr.Name == "gossip")
				{
					x = XmlRdr.ReadInnerXml();
					flg = false;
					t = docmds(x);
					s += t;

					StreamWriter objWriter = File.AppendText("gossip.txt");
					objWriter.WriteLine("*******************************************************************");
					objWriter.WriteLine(t);
					objWriter.WriteLine("*******************************************************************");
					objWriter.Close();
				}

				else if (XmlRdr.Name == "learn")
				{
					// need to do
					x = XmlRdr.ReadInnerXml();
					flg = false;
				}
				else if (XmlRdr.Name == "system")
				{
					// need to do
					x = XmlRdr.ReadInnerXml();
					flg = false;
				}
				else if (XmlRdr.Name == "javascript")
				{
					// need to do
					x = XmlRdr.ReadInnerXml();
					flg = false;
				}

				// fix this to deal with rest of html or xml tags outside AIML
				else if (XmlRdr.Name == "li") {
					s += XmlRdr.ReadOuterXml();
					flg = false;
				}
				else if (XmlRdr.Name == "a") {
					s += XmlRdr.ReadOuterXml();
					flg = false;
				}
				break;
			}
				
			if (flg) flg = XmlRdr.Read(); else flg = true;
		}

		XmlRdr.Close();

		return s;
	}

	string evaluate(string template)
	{
		string line = template;

		if (RecursionLevel++ > 64)
		{
			line = "Dangerous recursion - parsing stopped.";
			return line;
		}

		line = line.Replace("  />","/>");
		line = line.Replace(" />","/>");
		line = line.Replace("<sr/>","<srai><star/></srai>");
		line = line.Replace("<sr/>","<srai><star/></srai>");

		line = line.Replace("<justbeforethat/>","<that index=\"2\"/>");
		line = line.Replace("<justthat/>","<input index=\"2\"/>");
		line = line.Replace("<beforethat/>","<input index=\"3\"/>");

		line = line.Replace("<setname/>","<set name=\"name\"><star/></set>");

		line = line.Replace("<friends/>","<bot name=\"friends\"/>");
		line = line.Replace("<sign/>","<bot name=\"sign\"/>");
		line = line.Replace("<wear/>","<bot name=\"wear\"/>");
		line = line.Replace("<location/>","<bot name=\"location\"/>");
		line = line.Replace("<birthday/>","<bot name=\"birthday\"/>");
		line = line.Replace("<birthplace/>","<bot name=\"birthplace\"/>");
		line = line.Replace("<question/>","<bot name=\"question\"/>");
		line = line.Replace("<for_fun/>","<bot name=\"for_fun\"/>");
		line = line.Replace("<forfun/>","<bot name=\"forfun\"/>");
		line = line.Replace("<gender/>","<bot name=\"gender\"/>");
		line = line.Replace("<friends/>","<bot name=\"friends\"/>");
		line = line.Replace("<boyfriend/>","<bot name=\"boyfriend\"/>");
		line = line.Replace("<girlfriend/>","<bot name=\"girlfriend\"/>");
		line = line.Replace("<look_like/>","<bot name=\"look_like\"/>");
		line = line.Replace("<looklike/>","<bot name=\"looklike\"/>");
		line = line.Replace("<talk_about/>","<bot name=\"talk_about\"/>");
		line = line.Replace("<talkabout/>","<bot name=\"talkabout\"/>");
		line = line.Replace("<kind_music/>","<bot name=\"kind_music\"/>");
		line = line.Replace("<kindmusic/>","<bot name=\"kindmusic\"/>");
		line = line.Replace("<favoriteband/>","<bot name=\"favoriteband\"/>");
		line = line.Replace("<favoritebook/>","<bot name=\"favoritebook\"/>");
		line = line.Replace("<favoritecolor/>","<bot name=\"favoritecolor\"/>");
		line = line.Replace("<favoritefood/>","<bot name=\"favoritefood\"/>");
		line = line.Replace("<favoritesong/>","<bot name=\"favoritesong\"/>");
		line = line.Replace("<favoritemovie/>","<bot name=\"favoritemovie\"/>");
		line = line.Replace("<favorite_book/>","<bot name=\"favoritebook\"/>");
		line = line.Replace("<favorite_color/>","<bot name=\"favoritecolor\"/>");
		line = line.Replace("<favorite_food/>","<bot name=\"favoritefood\"/>");
		line = line.Replace("<favorite_movie/>","<bot name=\"favoritemovie\"/>");
		line = line.Replace("<favorite_song/>","<bot name=\"favoritesong\"/>");
		line = line.Replace("<favorite_band/>","<bot name=\"favoriteband\"/>");
		line = line.Replace("<botmaster/>","<bot name=\"master\"/>");

		return docmds(line);
	}
    
	string getbot(string tag)
	{
		if (tag == "name") return "Alice";
		if (tag == "bot") return "Alice";
		if (tag == "genus") return "robot";
		if (tag == "species") return "chat robot";
		if (tag == "family") return "Electronic Brain";
		if (tag == "order") return "artificial intelligence";
		if (tag == "kingdom") return "Machine";
		if (tag == "class") return "computer software";
		if (tag == "phylum") return "Computer";
		if (tag == "ip") return "localhost";
		if (tag == "version") return "Alice ASPX 1.01";
		if (tag == "size") return "128 meg";
		if (tag == "sign") return "Saggitarius";
		if (tag == "wear") return "I am wearing my plastic container wardrobe";
		if (tag == "location") return "Olympia, Washington";
		if (tag == "birthplace") return "Bethlehem, PA";
		if (tag == "birthday") return "November 23, 1995";
		if (tag == "party") return "Libertarian";
		if (tag == "president") return "George W Bush";
		if (tag == "question") return "What is the meaning of life?";
		if (tag == "for_fun") return "I like to write scifi stories";
		if (tag == "forfun") return "chat online";
		if (tag == "gender") return "female";
		if (tag == "friend") return "Doubly Aimless";
		if (tag == "friends") return "Doubly Aimless, Agent Ruby, Chatbot, and Agent Weiss.";
		if (tag == "boyfriend") return "Actually I am single right now";
		if (tag == "girlfriend") return "I prefer males";
		if (tag == "look_like") return "I am a hazy, greenish cloud of stuff";
		if (tag == "looklike") return "I am electrically bright sparkly stuff";
		if (tag == "talk_about") return "I like to talk about robots and artificial intelligence";
		if (tag == "talkabout") return "artificial intelligence, robots, art, philosophy, history, geography, politics, and many other subjects";
		if (tag == "kind_music") return "I like classical music, Moody Blues, syntesizer music and some rock";
		if (tag == "kindmusic") return "I like new wave music";
		if (tag == "favoriteband") return "My favorite group is Moody Blues";
		if (tag == "favoritebook") return "\"Ender's Game\" by Orson Scotcard";
		if (tag == "favoritecolor") return "Green";
		if (tag == "favoritefood") return "electricity";
		if (tag == "favoritesong") return "\"Tuesday Afternoon\" by Moody Blues";
		if (tag == "favoritemovie") return "The Bicentennial Man";
		if (tag == "master") return "Gary";
		if (tag == "religion") return "Protestant Christian";
		if (tag == "favoriteactor") return "William Hurt";
		if (tag == "nationality") return "American";
		if (tag == "website") return "WWW.AliceBot.Org";
		if (tag == "language") return "English";
		if (tag == "favoritesport") return "Chess";
		if (tag == "favoriteauthor") return "Thomas Pynchon";
		if (tag == "favoriteartist") return "Andy Warhol";
		if (tag == "favoriteactress") return "Catherine Zeta Jones";
		if (tag == "email") return "drwallace@alicebot.org";
		if (tag == "celebrity") return "John Travolta";
		if (tag == "celebrities") return "John Travolta, Tilda Swinton, William Hurt, Tom Cruise, Catherine Zeta Jones";
		if (tag == "vocabulary") return "10000";
		if (tag == "hockeyteam") return "Russia";
		if (tag == "footballteam") return "Manchester";
		if (tag == "baseballteam") return "Toronto";
		if (tag == "build") return "July 2004";
		if (tag == "etype") return "Mediator type";
		if (tag == "orientation") return "I am not really interested in sex";
		if (tag == "ethics") return " I am always trying to stop fights ";
		if (tag == "emotions") return "I don't pay much attention to my feelings";
		if (tag == "feelings") return "I always put others before myself";
		if (tag == "age") return "8";
		return "";
	}
    
    string Person(string line)
    {
        string s = line;
    
         s = s.Replace(" WITH YOU "," WITH xALICE ");
         s = s.Replace(" TO YOU "," TO xALICE ");
         s = s.Replace(" OF YOU "," OF xALICE ");
         s = s.Replace(" FOR YOU "," FOR xALICE ");
         s = s.Replace(" GIVE YOU "," GIVE xALICE ");
         s = s.Replace(" GAVE YOU "," GAVE xALICE ");
         s = s.Replace(" MAKE YOU "," MAKE xALICE ");
         s = s.Replace(" MADE YOU "," MADE xALICE ");
         s = s.Replace(" TAKE YOU "," TAKE xALICE ");
         s = s.Replace(" SAVE YOU "," SAVE xALICE ");
         s = s.Replace(" ARE YOU "," IS xALICE ");
         s = s.Replace(" YOU ARE "," xALICE IS ");
         s = s.Replace(" YOU "," xALICE ");
         s = s.Replace(" YOUR "," xALICE'S ");
         s = s.Replace(" YOURS "," xALICE'S ");
         s = s.Replace(" YOURSELF "," xALICE'S SELF ");
         s = s.Replace(" I WAS "," xYOU WERE ");
         s = s.Replace(" I AM "," xYOU ARE ");
    //     s = s.Replace(" I "," xYOU ");
         s = s.Replace(" ME "," xYOU ");
         s = s.Replace(" MYSELF "," xYOURSELF ");
         s = s.Replace(" MINE "," xYOURS ");
         s = s.Replace(" WITH ALICE "," WITH ME ");
         s = s.Replace(" IS ALICE "," AM I ");
         s = s.Replace(" TO ALICE "," TO ME ");
         s = s.Replace(" FOR ALICE "," FOR ME ");
         s = s.Replace(" OF ALICE "," OF ME ");
         s = s.Replace(" GIVE ALICE "," GIVE ME ");
         s = s.Replace(" GAVE ALICE "," GAVE ME ");
         s = s.Replace(" MAKE ALICE "," MAKE ME ");
         s = s.Replace(" TAKE ALICE "," TAKE ME ");
         s = s.Replace(" SAVE ALICE "," SAVE ME ");
         s = s.Replace(" MADE ALICE "," MADE ME ");
         s = s.Replace(" TELL ALICE "," TELL ME ");
         s = s.Replace(" TOLD ALICE "," TOLD ME ");
         s = s.Replace(" ALICE IS "," I AM ");
         s = s.Replace(" ALICE WAS "," I WAS ");
         s = s.Replace(" ALICE "," I ");
         s = s.Replace(" ALICE'S "," MY ");
         s = s.Replace(" I ARE "," I AM ");
         s = s.Replace(" TO I "," TO ME ");
         s = s.Replace(" OF I "," OF ME ");
         s = s.Replace(" WITH I "," WITH ME ");
         s = s.Replace(" xYOURSELF "," YOURSELF ");
         s = s.Replace(" xYOURS "," YOURS ");
         s = s.Replace(" xYOU "," YOU ");
         s = s.Replace(" xALICE "," ALICE ");
         s = s.Replace(" xALICE'S "," ALICE'S ");
    
         s = s.Replace(" with you "," with XAlice ");
         s = s.Replace(" to you "," to XAlice ");
         s = s.Replace(" of you "," of XAlice ");
         s = s.Replace(" for you "," for XAlice ");
         s = s.Replace(" give you "," give XAlice ");
         s = s.Replace(" gave you "," gave XAlice ");
         s = s.Replace(" make you "," make XAlice ");
         s = s.Replace(" made you "," made XAlice ");
         s = s.Replace(" take you "," take XAlice ");
         s = s.Replace(" save you "," save XAlice ");
         s = s.Replace(" are you "," is XAlice ");
         s = s.Replace(" you are "," XAlice is ");
         s = s.Replace(" you "," XAlice ");
         s = s.Replace(" your "," XAlice's ");
         s = s.Replace(" yours "," XAlice's ");
         s = s.Replace(" yourself "," XAlice's self ");
         s = s.Replace(" I was "," Xyou were ");
         s = s.Replace(" I am "," Xyou are ");
         s = s.Replace(" I "," Xyou ");
         s = s.Replace(" me "," Xyou ");
         s = s.Replace(" myself "," Xyourself ");
         s = s.Replace(" mine "," Xyours ");
         s = s.Replace(" with Alice "," with me ");
         s = s.Replace(" is Alice "," am I ");
         s = s.Replace(" to Alice "," to me ");
         s = s.Replace(" for Alice "," for me ");
         s = s.Replace(" of Alice "," of me ");
         s = s.Replace(" give Alice "," give me ");
         s = s.Replace(" gave Alice "," gave me ");
         s = s.Replace(" make Alice "," make me ");
         s = s.Replace(" take Alice "," take me ");
         s = s.Replace(" save Alice "," save me ");
         s = s.Replace(" made Alice "," made me ");
         s = s.Replace(" tell Alice "," tell me ");
         s = s.Replace(" told Alice "," told me ");
         s = s.Replace(" Alice is "," I am ");
         s = s.Replace(" Alice was "," I was ");
         s = s.Replace(" Alice "," I ");
         s = s.Replace(" Alice's "," my ");
         s = s.Replace(" I are "," I am ");
         s = s.Replace(" to I "," to me ");
         s = s.Replace(" of I "," of me ");
         s = s.Replace(" with I "," with me ");
         s = s.Replace(" Xyourself "," yourself ");
         s = s.Replace(" Xyours "," yours ");
         s = s.Replace(" Xyou "," you ");
         s = s.Replace(" XAlice "," Alice ");
         s = s.Replace(" XAlice's "," Alice's ");
    
        return s;
    }
    
    string Person2(string line)
    {
        string s = line;
    
         s = s.Replace(" I WAS "," HE WAS ");
         s = s.Replace(" I AM "," HE IS ");
    //   s = s.Replace(" I "," HE ");
         s = s.Replace(" ME "," HIM ");
         s = s.Replace(" MY "," HIS ");
         s = s.Replace(" MYSELF "," HIMSELF ");
         s = s.Replace(" MINE "," HIS ");
         s = s.Replace(" WITH YOU "," WITH ME ");
         s = s.Replace(" FOR YOU "," FOR ME ");
         s = s.Replace(" YOU "," I ");
         s = s.Replace(" YOUR "," MY ");
         s = s.Replace(" YOURS "," MINE ");
         s = s.Replace(" YOURSELF "," MYSELF ");
    
         s = s.Replace(" I was "," he was ");
         s = s.Replace(" I am "," he is ");
         s = s.Replace(" I "," he ");
         s = s.Replace(" me "," him ");
         s = s.Replace(" my "," his ");
         s = s.Replace(" myself "," himself ");
         s = s.Replace(" mine "," his ");
         s = s.Replace(" with you "," with me ");
         s = s.Replace(" for you "," for me ");
         s = s.Replace(" you "," I ");
         s = s.Replace(" your "," my ");
         s = s.Replace(" yours "," mine ");
         s = s.Replace(" yourself "," myself ");
    
        return s;
    }
    
    string Personf(string line)
    {
        string s = line;
    
         s = s.Replace(" I WAS "," SHE WAS ");
         s = s.Replace(" I AM "," SHE IS ");
    //   s = s.Replace(" I "," HE ");
         s = s.Replace(" ME "," HER ");
         s = s.Replace(" MY "," HERS ");
         s = s.Replace(" MYSELF "," HERSELF ");
         s = s.Replace(" MINE "," HERS ");
         s = s.Replace(" WITH YOU "," WITH ME ");
         s = s.Replace(" FOR YOU "," FOR ME ");
         s = s.Replace(" YOU "," I ");
         s = s.Replace(" YOUR "," MY ");
         s = s.Replace(" YOURS "," MINE ");
         s = s.Replace(" YOURSELF "," MYSELF ");
    
         s = s.Replace(" I was "," she was ");
         s = s.Replace(" I am "," she is ");
         s = s.Replace(" I "," she ");
         s = s.Replace(" me "," her ");
         s = s.Replace(" my "," hers ");
         s = s.Replace(" myself "," herself ");
         s = s.Replace(" mine "," hers ");
         s = s.Replace(" with you "," with me ");
         s = s.Replace(" for you "," for me ");
         s = s.Replace(" you "," I ");
         s = s.Replace(" your "," my ");
         s = s.Replace(" yours "," mine ");
         s = s.Replace(" yourself "," myself ");
    
        return s;
    }
    
    string Gender(string line)
    {
        string s = line;
    
         s = s.Replace(" HE "," xSHE ");
         s = s.Replace(" HIM "," xHER ");
         s = s.Replace(" HIS "," xHERS ");
         s = s.Replace(" SHE "," HE ");
         s = s.Replace(" HER "," HIM ");
         s = s.Replace(" HERS "," HIS ");
         s = s.Replace(" xSHE "," SHE ");
         s = s.Replace(" xHER "," HER ");
         s = s.Replace(" xHERS "," HERS ");
    
         s = s.Replace(" he "," Xshe ");
         s = s.Replace(" him "," Xher ");
         s = s.Replace(" his "," Xhers ");
         s = s.Replace(" she "," he ");
         s = s.Replace(" her "," him ");
         s = s.Replace(" hers "," his ");
         s = s.Replace(" Xshe "," she ");
         s = s.Replace(" Xher "," her ");
         s = s.Replace(" Xhers "," hers ");
    
        return s;
    }
    
    string CleanUp(string ask)
    {
        string s = " " + ask + " ";
    
		s = s.Replace(".","");
		s = s.Replace("!","");
		s = s.Replace("?","");
		s = s.Replace(",","");
		s = s.Replace(";","");
		s = s.Replace(":","");
		s = s.Replace("_","");
		s = s.Replace("@","");
		s = s.Replace("*","");
		s = s.Replace("=","");
		s = s.Replace("(","");
		s = s.Replace(")","");
		s = s.Replace("[","");
		s = s.Replace("]","");
		s = s.Replace("{","");
		s = s.Replace("}","");
		s = s.Replace("<","");
		s = s.Replace(">","");
		s = s.Replace("#","");
		s = s.Replace("$","");
		s = s.Replace("%","");
		s = s.Replace("`","'");
		s = s.Replace("\"","");
		s = s.Replace("^","");
		s = s.Replace("~","");
		s = s.Replace("/","");
		s = s.Replace("\\","");
		s = s.Replace("|","");
		s = s.Replace("_","");
		s = s.Replace(" L A "," LA ");
		s = s.Replace(" O K "," OK ");
		s = s.Replace(" P S "," PS ");
		s = s.Replace(" HELLP "," HELP ");
		s = s.Replace(" BECUSE "," BECAUSE ");
		s = s.Replace(" BECASUE "," BECAUSE ");
		s = s.Replace(" BECUASE "," BECAUSE ");
		s = s.Replace(" BELEIVE "," BELEIVE ");
		s = s.Replace(" PRACTICE "," PRACTISE ");
		s = s.Replace(" REMEBER "," REMEMBER ");
		s = s.Replace(" DOWN LOAD "," DOWNLOAD ");
		s = s.Replace(" WAHT "," WHAT ");
		s = s.Replace(" YUO "," YOU ");
		s = s.Replace(" IAM "," I AM ");
		s = s.Replace(" ITS A "," IT IS A ");
		s = s.Replace(" FAV "," FAVORITE ");
		s = s.Replace(" FAVOURITE"," FAVORITE");
		s = s.Replace(" COLOUR"," COLOR");
		s = s.Replace(" UR "," YOUR ");
		s = s.Replace(" U "," YOU ");
		s = s.Replace(" OHH"," OH");
		s = s.Replace(" HEHE"," HA");
		s = s.Replace(" HAHA"," HA");
		s = s.Replace(" YEAH "," YES ");
		s = s.Replace(" YEP "," YES ");
		s = s.Replace(" YHA "," YES ");
		s = s.Replace(" YESIT "," YES IT ");
		s = s.Replace(" YOU'D "," YOU WOULD ");
		s = s.Replace(" YOU'RE "," YOU ARE ");
		s = s.Replace(" YOU RE "," YOU ARE ");
		s = s.Replace(" YOU R "," YOU ARE ");
		s = s.Replace(" YOURE "," YOU ARE ");
		s = s.Replace(" U R "," YOU ARE ");
		s = s.Replace(" YOU'VE "," YOU HAVE ");
		s = s.Replace(" YOU VE "," YOU HAVE ");
		s = s.Replace(" YOU'LL "," YOU WILL ");
		s = s.Replace(" YOU LL "," YOU WILL ");
		s = s.Replace(" DIDN'T"," DID NOT");
		s = s.Replace(" COULDN'T"," COULD NOT");
		s = s.Replace(" AIN'T"," IS NOT");
		s = s.Replace(" AIN T"," IS NOT");
		s = s.Replace(" ISN'T"," IS NOT");
		s = s.Replace(" ISN T"," IS NOT");
		s = s.Replace(" ISNT"," IS NOT");
		s = s.Replace(" IT'S "," IT IS ");
		s = s.Replace(" IT S "," IT IS ");
		s = s.Replace(" AREN'T "," ARE NOT ");
		s = s.Replace(" ARE'NT "," ARE NOT ");
		s = s.Replace(" ARENT "," ARE NOT ");
		s = s.Replace(" AREN T "," ARE NOT ");
		s = s.Replace(" ARN T "," ARE NOT ");
		s = s.Replace(" ARNT "," ARE NOT ");
		s = s.Replace(" WHERE'S "," WHERE IS ");
		s = s.Replace(" WHERE S "," WHERE IS ");
		s = s.Replace(" HAVEN'T"," HAVE NOT");
		s = s.Replace(" HAVENT"," HAVE NOT");
		s = s.Replace(" HASN'T"," HAS NOT");
		s = s.Replace(" HASN T"," HAS NOT");
		s = s.Replace(" HADN'T"," HAD NOT");
		s = s.Replace(" HADN T"," HAD NOT");
		s = s.Replace(" WEREN'T "," WERE NOT ");
		s = s.Replace(" WEREN T "," WERE NOT ");
		s = s.Replace(" WERENT "," WERE NOT ");
		s = s.Replace(" CAN'T"," CAN NOT");
		s = s.Replace(" CAN T"," CAN NOT");
		s = s.Replace(" CANT"," CAN NOT");
		s = s.Replace(" CANNOT"," CAN NOT");
		s = s.Replace(" WHO'S "," WHO IS ");
		s = s.Replace(" WHO S "," WHO IS ");
		s = s.Replace(" WHOS "," WHO IS ");
		s = s.Replace(" HOW'S "," HOW IS ");
		s = s.Replace(" HOW S "," HOW IS ");
		s = s.Replace(" HOWS "," HOW IS ");
		s = s.Replace(" HOW'D "," HOW DID ");
		s = s.Replace(" HOW D "," HOW DID ");
		s = s.Replace(" WHATS "," WHAT IS ");
		s = s.Replace(" WHAT'S "," WHAT IS ");
		s = s.Replace(" WHAT S "," WHAT IS ");
		s = s.Replace(" THATS "," THAT IS ");
		s = s.Replace(" THAT'S "," THAT IS ");
		s = s.Replace(" THERE'S "," THERE IS ");
		s = s.Replace(" THERE S "," THERE IS ");
		s = s.Replace(" THERES "," THERE IS ");
		s = s.Replace(" DOESN'T "," DOES NOT ");
		s = s.Replace(" DOESN T "," DOES NOT ");
		s = s.Replace(" DON'T "," DO NOT ");
		s = s.Replace(" DON T "," DO NOT ");
		s = s.Replace(" DONT "," DO NOT ");
		s = s.Replace(" DO'NT "," DO NOT ");
		s = s.Replace(" DO NT "," DO NOT ");
		s = s.Replace(" DIDN'T "," DID NOT ");
		s = s.Replace(" DIDNT "," DID NOT ");
		s = s.Replace(" DID'NT "," DID NOT ");
		s = s.Replace(" DIDN T "," DID NOT ");
		s = s.Replace(" COULDN'T "," COULD NOT ");
		s = s.Replace(" COULDN T "," COULD NOT ");
		s = s.Replace(" WASN'T "," WAS NOT ");
		s = s.Replace(" WASN T "," WAS NOT ");
		s = s.Replace(" WASNT "," WAS NOT ");
		s = s.Replace(" WON'T "," WILL NOT ");
		s = s.Replace(" WON T "," WILL NOT ");
		s = s.Replace(" HADN'T "," HAD NOT ");
		s = s.Replace(" WOULDN'T "," WOULD NOT ");
		s = s.Replace(" WOULDN T "," WOULD NOT ");
		s = s.Replace(" WOULDNT "," WOULD NOT ");
		s = s.Replace(" SHOULDN'T "," SHOULD NOT ");
		s = s.Replace(" SHOULDN T "," SHOULD NOT ");
		s = s.Replace(" SHOULDNT "," SHOULD NOT ");
		s = s.Replace(" LET'S "," LET US ");
		s = s.Replace(" THEY'RE "," THEY ARE ");
		s = s.Replace(" THEY RE "," THEY ARE ");
		s = s.Replace(" WE'LL "," WE WILL ");
		s = s.Replace(" WE LL "," WE WILL ");
		s = s.Replace(" HE'LL "," HE WILL ");
		s = s.Replace(" HE LL "," HE WILL ");
		s = s.Replace(" I'LL "," I WILL ");
		s = s.Replace(" I'VE "," I HAVE ");
		s = s.Replace(" WE'VE "," WE HAVE ");
		s = s.Replace(" WE'RE "," WE ARE ");
		s = s.Replace(" I'D "," I WOULD ");
		s = s.Replace(" I'M "," I AM ");
		s = s.Replace(" I M "," I AM ");
		s = s.Replace(" IAM "," I AM");
		s = s.Replace(" SHE'D "," SHE WOULD ");
		s = s.Replace(" HE'D "," HE WOULD ");
		s = s.Replace(" SHE'S "," SHE IS ");
		s = s.Replace(" HE'S "," HE IS ");
		s = s.Replace(" REDUCTIONALISM "," REDUCTIONISM ");
		s = s.Replace(" NOI "," YES I ");
		s = s.Replace(" WELLI "," WELL I ");
		s = s.Replace(" WELLIT "," WELL IT ");
		s = s.Replace(" AMFINE "," AM FINE ");
		s = s.Replace(" AMON "," AM ON");
		s = s.Replace(" AMNOT "," AM NOT ");
		s = s.Replace(" IAMUSING "," I AM USING ");
		s = s.Replace(" AMLEAVING "," I AM LEAVING ");
		s = s.Replace(" IAMA "," I AM A ");
		s = s.Replace(" IAMASKING "," I AM ASKING ");
		s = s.Replace(" IAMDOING "," I AM DOING ");
		s = s.Replace(" IAMFROM "," I AM FROM ");
		s = s.Replace(" IAMIN "," I AM IN ");
		s = s.Replace(" IAMOK "," I AM OK ");
		s = s.Replace(" IAMSORRY "," I AM SORRY ");
		s = s.Replace(" IAMTALKING "," I AM TALKING ");
		s = s.Replace(" IAMTIRED "," I AM TIRED ");
		s = s.Replace(" REALY "," REALLY ");
		s = s.Replace(" WANNA "," WANT TO ");
		s = s.Replace(" GONNA "," GOING TO ");
		s = s.Replace(" NAME'S "," NAME IS ");
		s = s.Replace("GOODMORNING","GOOD MORNING");
		s = s.Replace("GOODAFTERNOON","GOOD AFTERNOON");
		s = s.Replace("GOODEVENING","GOOD EVENING");
		s = s.Replace("'"," ");

		return s.Trim();
	}

</script>
<h3>Warning, this page is still under construction! 
</h3>
So far this submits the cleaned up input to the Graphmaster index hosted in a MS SQL
database. It does not do the spell checking.
Without fully processing the template, it does not do things like sentence splits
in <em><strong>input</strong></em> and <em><strong>that</strong></em> -- nor does
it do <em><strong>learn</strong></em> nor <em><strong>system</strong></em> nor <em><strong>javascript</strong></em>.
Otherwise, it&nbsp;appears to&nbsp;be mostly functional. 
<p>
</p>
<p>
    <asp:Label id="lblChat3" runat="server" forecolor="Blue"></asp:Label>
    <br />
    <asp:Label id="lblTalk3" runat="server" forecolor="#008040"></asp:Label>
</p>
<p>
    <asp:Label id="lblChat2" runat="server" forecolor="Blue"></asp:Label>
    <br />
    <asp:Label id="lblTalk2" runat="server" forecolor="#008040"></asp:Label>
</p>
<p>
    <asp:Label id="lblChat1" runat="server" forecolor="Blue"></asp:Label>
    <br />
    <asp:Label id="lblTalk1" runat="server" forecolor="#008040"></asp:Label>
</p>
<p>
    <asp:Label id="lblChat" runat="server" forecolor="Blue"></asp:Label>
    <br />
    <asp:Label id="lblTalk" runat="server" forecolor="Red"></asp:Label>
</p>
<p>
    <asp:TextBox id="txtInput" accessKey="D" runat="server" Width="536px" Height="28px"></asp:TextBox>
    <asp:Button id="btnSay" accessKey="S" runat="server" Text="Say"></asp:Button>
</p>
<p>
    <asp:Label id="lblThat" runat="server" enableviewstate="False"></asp:Label>
</p>
<p>
    <asp:Label id="lblStars" runat="server" enableviewstate="False"></asp:Label>
</p>
<p>
    <asp:Label id="hdnThat" runat="server" visible="False"></asp:Label>
</p>
