/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using SharperCV;
using SharperCV.Haar;
using System.IO;

namespace PKDPlugin
{
	public class FaceTrackerPlugin : PKDPlugin.AbstractJessPlugin
	{
		#region Fields / Constructor
		#region Shadow Fact Related
		/*when we were only tracking one head
		public int headSize;
		public int headX;
		public int headY;
		*/
		//for tracking multiple faces and representing that in jess. we max out at 10 heads
		public int[] headSize = new int[ 10 ];
		public int[] headX = new int[ 10 ];
		public int[] headY = new int[ 10 ];
		public int[] headId = new int[ 10 ];
		public int numberHeadsTracked = 0;
		public int centerFace;
		public int centerFaceX;
		public int centerFaceY;
		public int centerFaceHeadSize;

		private int[] tempHeadSize = new int[ 10 ];
		private int[] tempHeadX = new int[ 10 ];
		private int[] tempHeadY = new int[ 10 ];
		private int[] tempHeadId = new int[ 10 ];
		private int tempCenterFace;
		private int tempCenterFaceX;
		private int tempCenterFaceY;
		private int tempCenterFaceHeadSize;
		#endregion
		
		public System.Collections.ArrayList trackedFacesList = null;
		public System.Collections.ArrayList waitingToBeATrackedFaceList = null;
		public int numberOfTrackedFaces = 0;

		#region Motion related
		// various tracking parameters (in seconds)
		public double MHI_DURATION = 1;
		public double MAX_TIME_DELTA = 0.5;
		public double MIN_TIME_DELTA = 0.05;
		// number of cyclic frame buffer used for motion detection
		// (should, probably, depend on FPS)
		public int N = 4;

		// ring image buffer
		public SharperCVExtensions.MyCvImage[] buf = null;
		public int last = 0;

		// temporary images
		public SharperCVExtensions.MyCvImage mhi = null; // MHI
		public SharperCVExtensions.MyCvImage mask = null; // valid orientation mask
		#endregion
		public FaceTrackerPlugin() : base()
		{ 
			//There are no events that we want to register for: we only export data
			//string [] helptxt = {"Detects faces and motion",	" ", "Q quits the program"};
			//CvWindow helpWin = new CvWindow("Help", helptxt);
			this.trackedFacesList = new System.Collections.ArrayList();
			this.waitingToBeATrackedFaceList = new System.Collections.ArrayList();

			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}

		#endregion
		#region Methods
		/// <summary>
		/// Updates the trackedFaceList, given a list of faces
		/// </summary>
		/// <param name="facesList"></param>
		/// <param name="trackedFacesList"></param>
		/// <returns></returns>
		public void Match( System.Collections.ArrayList facesList )
		{
			System.Collections.ArrayList matchedTrackedFacesList = new System.Collections.ArrayList();
			System.Collections.ArrayList unMatchedTrackedFacesList = new System.Collections.ArrayList();

			System.Collections.ArrayList unMatchedFacesList = ( System.Collections.ArrayList )facesList.Clone();

			//for each previously matched tracked face, match to new face that is in bounding box and has comparable size
			foreach( TrackedFace trackedFace in this.trackedFacesList )
			{
				trackedFace.isMatched = false;
				foreach( SharperCV.CvRect face in facesList )
				{
					//match
					if( Calculator.DoesBound( trackedFace.boundingBox, face ) && Calculator.SimilarSize( trackedFace.boundingBox.height, face.height ) )
					{
						trackedFace.Match( face );
						unMatchedFacesList.Remove( face );
						matchedTrackedFacesList.Add( trackedFace );
						facesList.Remove( face );
						break;
					}
				}
				//no match
				if( !trackedFace.isMatched ) 
					unMatchedTrackedFacesList.Add( trackedFace );
			}
			#region defunct
			//for each unmatched previously matched tracked face, calc distance to all new faces that are still unmatched and have comparable size. Min is match
			/*
			foreach( TrackedFace trackedFace in unMatchedTrackedFacesList )
			{
				int minIndex = 0;
				int index = 0;
				double minDistance = 9999;
				double distance = 0;
				
				foreach( SharperCV.CvRect face in unMatchedFacesList )
				{
					if( Calculator.SimilarSize( trackedFace.boundingBox.height, face.height ) )
					{
						distance = Calculator.Distance( trackedFace.boundingBox, face );
						if( distance < minDistance )
						{
							minDistance = distance;
							minIndex = index;
						}
					}
					index++;
				}
				if( unMatchedFacesList.Count == 0 )
					break;
				//Min distance is match
				SharperCV.CvRect face2 = ( SharperCV.CvRect ) unMatchedFacesList[ minIndex ];
				trackedFace.Match( face2 );
				unMatchedFacesList.RemoveAt( minIndex );
				matchedTrackedFacesList.Add( trackedFace );
			}
			*/
			#endregion
			//for each unmatched previously matched tracked face, decrease weight (100 frames to disappear)
			foreach( TrackedFace trackedFace in unMatchedTrackedFacesList )
			{
				trackedFace.matchCount--;
			}
			
			//Update the tracked list
			this.trackedFacesList.Clear();
			this.trackedFacesList.AddRange( matchedTrackedFacesList );
			this.trackedFacesList.AddRange( unMatchedTrackedFacesList );

			//Remove old faces from the tracked list
			System.Collections.ArrayList temp = ( System.Collections.ArrayList) this.trackedFacesList.Clone();
			foreach( TrackedFace trackedFace in this.trackedFacesList )
				if( trackedFace.matchCount < 0 )
					temp.Remove( trackedFace );
			this.trackedFacesList = temp;
			
			//Add new faces the the tracked list
			foreach( CvRect face in unMatchedFacesList )
			{
				this.trackedFacesList.Add( new TrackedFace( this.numberOfTrackedFaces++, face ) );
			}
		}

		public void Run()
		{
			CvWindow mainWin = new CvWindow("Face & Motion Detection");    // create a window
			CvCapture theSrc = new CvCapture(-1, false);       // a camera source
			CvImage theFrame = theSrc.QueryFrame();            // an image for the frame
			
			//SharperCVExtensions.MyCvImage motion = null;
			TrackedFace aTrack;
			SharperCV.CvPoint target;
			SharperCV.CvPoint center = new CvPoint( theFrame.Size.width / 2, theFrame.Size.height / 2 );

			// create the Haar Classifier
			ClassifierCascade c = new ClassifierCascade("<default_face_cascade>", new CvSize(24, 24));
			HiddenClassifierCascade hc = new HiddenClassifierCascade(c, null, null, null, 1);
 
			for (;;)     // now run the frame grab and detect loop
			{
				theFrame = theSrc.QueryFrame();
			
				#region Do MHI
				/*
				if( theFrame != null )
				{
					if( motion == null )
					{
						motion = new SharperCVExtensions.MyCvImage( theFrame.Size, SharperCV.BitDepths.IPL_DEPTH_8U, 3 );
					}
				}
				update_mhi( theFrame, motion, 30 );
				*/
				#endregion

				#region Do Haar
				// find the face(s) within the image
				CvRect[] faces = hc.DetectObjects(theFrame, 1.2, 2, PruningFlags.CannyPruning);
				System.Collections.ArrayList facesList = new System.Collections.ArrayList( faces );

				//Match new faces to tracked faces, creating new tracks for unmatched faces
				Match( facesList );

				#region defunct
				/*
				//Match unmatched faces to the waiting to be tracked faces
				unMatchedFacesList = Match( unMatchedFacesList, this.waitingToBeATrackedFaceList );

				//Add the final unmatched faces to the waiting to be tracked list
				foreach( SharperCV.CvRect face in unMatchedFacesList )
					this.waitingToBeATrackedFaceList.Add( new TrackedFace( this.numberOfTrackedFaces++, face ) );
					*/
				#endregion
				#region defunct
				/*
				//Promote waiting to be tracked faces that have been around a while, remove those that have fallen away
				temp = ( System.Collections.ArrayList) this.waitingToBeATrackedFaceList.Clone();
				foreach( TrackedFace trackedFace in this.waitingToBeATrackedFaceList )
				{
					if( trackedFace.matchCount > 10 )
					{
						temp.Remove( trackedFace );
						this.trackedFacesList.Add( trackedFace );
					}
					else if( trackedFace.matchCount < 0 )
						temp.Remove( trackedFace );
				}
				this.waitingToBeATrackedFaceList = temp;
				*/
				#endregion
			
				/*
					propertyChangeSupport.firePropertyChange("headsize", new java.lang.Integer( this.headSize ), new java.lang.Integer( faces[ i ].height ) );
					this.headSize = faces[ i ].height;
		
					propertyChangeSupport.firePropertyChange("headx", new java.lang.Integer( this.headX ), new java.lang.Integer( faces[ i ].x ) );
					this.headX = faces[ i ].x;

					propertyChangeSupport.firePropertyChange("heady", new java.lang.Integer( this.headY ), new java.lang.Integer( faces[ i ].y ) );
					this.headY = faces[ i ].y;
					*/
				
				foreach( TrackedFace trackedFace in this.trackedFacesList )
				{
					theFrame.PutText( trackedFace.id.ToString() +":"+ trackedFace.matchCount.ToString(), trackedFace.center, SharperCV.CvColor.Red );
					theFrame.Rectangle( trackedFace.boundingBox, new CvColor(255,255,0), 3);
				}
		
				#endregion

				#region Update Shadow Fact
				//I think originally this way messy b/c of the multislot issue. Now I can't remember, 
				//so it seems like a good thing to try to clean up. For instance, are all these temp 
				//values really necessary?
				if( this.numberHeadsTracked > 0 || this.trackedFacesList.Count > 0 )
				{
					//Convert tracked faces list into a format jess can understand
					double minDistanceToCenter = 999;
					double distance = 0;
					for( int i = 0; i < 10; i++ )
					{
						if( i < this.trackedFacesList.Count )
						{
							aTrack = ( TrackedFace )this.trackedFacesList[ i ];
							target = Calculator.BetweenTheEyes( aTrack.boundingBox );

							this.tempHeadId[ i ]	= aTrack.id;
							this.tempHeadX[ i ]		= target.x;
							this.tempHeadY[ i ]		= target.y;
							this.tempHeadSize[ i ]	= aTrack.boundingBox.height;
							distance = Calculator.Distance( target, center );
							if( distance < minDistanceToCenter )
							{
								minDistanceToCenter = distance;
								this.tempCenterFace = i;
							}
						}
						else
						{
							this.tempHeadId[ i ]	= 0;
							this.tempHeadX[ i ]		= 0;
							this.tempHeadY[ i ]		= 0;
							this.tempHeadSize[ i ]	= 0;
						}
					}
					this.tempCenterFaceHeadSize = this.tempHeadSize[ this.tempCenterFace ];
					this.tempCenterFaceX = this.tempHeadX[ this.tempCenterFace ];
					this.tempCenterFaceY = this.tempHeadY[ this.tempCenterFace ];
				
					propertyChangeSupport.firePropertyChange("headsize", this.headSize, this.tempHeadSize );
					propertyChangeSupport.firePropertyChange("headx", this.headX, this.tempHeadX );
					propertyChangeSupport.firePropertyChange("heady", this.headY, this.tempHeadY );
					propertyChangeSupport.firePropertyChange("headid", this.headId, this.tempHeadId );
					propertyChangeSupport.firePropertyChange("numberheadstracked", this.numberHeadsTracked, this.trackedFacesList.Count < 10 ? this.trackedFacesList.Count : 10 );
					propertyChangeSupport.firePropertyChange("centerface", this.centerFace, this.tempCenterFace );
					this.propertyChangeSupport.firePropertyChange( "centerfacex", this.centerFaceX, this.tempCenterFaceX );
					this.propertyChangeSupport.firePropertyChange( "centerfacey", this.centerFaceY, this.tempCenterFaceY );
					this.propertyChangeSupport.firePropertyChange( "centerfaceheadsize", this.centerFaceHeadSize, this.tempCenterFaceHeadSize );
			
					//copy new values to old values
					this.numberHeadsTracked = this.trackedFacesList.Count;
					this.centerFace = this.tempCenterFace;
					this.centerFaceX = this.tempCenterFaceX;
					this.centerFaceY = this.tempCenterFaceY;
					this.centerFaceHeadSize = this.tempCenterFaceHeadSize;

					for( int i = 0; i < 10; i++ )
					{
						this.headId[ i ] = this.tempHeadId[ i ];
						this.headSize[ i ] = this.tempHeadSize[ i ];
						this.headX[ i ] = this.tempHeadX[ i ];
						this.headY[ i ] = this.tempHeadY[ i ];
					}
				}
				#endregion
				// display the image
				mainWin.Image = theFrame; 

				int key = CvWindow.WaitKey(1);
				if (key == 'q' || key == 'Q' || key == 27) break;
				if (key == 'r') theSrc.positionFrameNum = 500;
			}
		}

		void  update_mhi( CvImage img, SharperCVExtensions.MyCvImage dst, int diff_threshold )
		{
			double timestamp = System.Diagnostics.Process.GetCurrentProcess().UserProcessorTime.TotalMilliseconds/1000.0; // get current time in seconds
			CvSize size = img.Size; // get current frame size
			int i, idx1 = last, idx2;
			SharperCVExtensions.MyCvImage silh;
			
			// allocate images at the beginning or
			// reallocate them if the frame size is changed
			if( mhi == null || mhi.Size.width != size.width || mhi.Size.height != size.height ) 
			{
				if( buf == null ) 
				{
					buf = new SharperCVExtensions.MyCvImage[ this.N ]; 
				}
		        
				for( i = 0; i < N; i++ ) 
				{
					buf[i] = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_8U, 1 );
					buf[ i ].Zero();
				}
				
				mhi = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_32F, 1 );
				mhi.Zero();
				mask = new SharperCVExtensions.MyCvImage( size, SharperCV.BitDepths.IPL_DEPTH_8U, 1 );
			}

			img.CvtColor( buf[last], SharperCV.ColorConversion.BGR2GRAY ); // convert frame to grayscale

			idx2 = (last + 1) % N; // index of (last - (N-1))th frame
			last = idx2;

			silh = buf[idx2];
			buf[ idx1 ].AbsDiff( buf[idx2], silh ); // get difference between frames
		    
			silh.Threshold( silh, diff_threshold, 1, SharperCV.ThresholdType.THRESH_BINARY ); // and threshold it
			SharperCVExtensions.Extensions.cvUpdateMotionHistory( silh.myArrHandle, mhi.myArrHandle, timestamp, MHI_DURATION ); // update MHI

			SharperCVExtensions.Extensions.cvConvertScale( mhi.myArrHandle, mask.myArrHandle, 255.0/MHI_DURATION,
				(MHI_DURATION - timestamp)*255.0/MHI_DURATION );
			dst.Zero();
			dst.CvtPlaneToPix( mask, mask, mask );
		}		
		#region Defunct
		/*
		/// <summary>
		/// The data we want to export is the location and size of the head, as well as motion components
		/// </summary>
		/// <returns></returns>
		public override void DeclareExports( jess.Rete engine )
		{
			jess.Deftemplate deftemplate = new jess.Deftemplate( "faceDetect", "face detection data", engine );
			deftemplate.addSlot( "headSize", jess.Funcall.NIL, "INTEGER" );
			deftemplate.addSlot( "headX", jess.Funcall.NIL, "INTEGER" );
			deftemplate.addSlot( "headY", jess.Funcall.NIL, "INTEGER" );
			engine.addDeftemplate( deftemplate );
		}

		public override void Export( jess.Rete engine )
		{
			//For each head being tracked, do
			jess.Fact fact = new jess.Fact( "faceDetect", engine );
			fact.setSlotValue( "headSize", new jess.Value( this.headSize, jess.RU.INTEGER ) );
			fact.setSlotValue( "headX", new jess.Value( this.headX, jess.RU.INTEGER ) );
			fact.setSlotValue( "headY", new jess.Value( this.headY, jess.RU.INTEGER ) );
			engine.assertFact( fact );
		}
		*/
		#endregion
		#endregion	
		#region ShadowFact Accessors
		//The capitalization on these is critical for the java introspector
		public int[] getHeadsize()
		{
			return this.headSize;
		}
		public int[] getHeadx()
		{
			return this.headX;
		}
		public int[] getHeady()
		{
			return this.headY;
		}
		public int[] getHeadid()
		{
			return this.headId;
		}
		public int getNumberheadstracked()
		{
			return this.numberHeadsTracked;
		}
		public int getCenterface()
		{
			return this.centerFace;
		}
		public int getCenterfacex()
		{
			return this.centerFaceX;
		}
		public int getCenterfacey()
		{
			return this.centerFaceY;
		}
		public int getCenterfaceheadsize()
		{
			return this.centerFaceHeadSize;
		}
		#endregion
	}
}
