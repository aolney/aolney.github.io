using System;

namespace PKDPlugin
{
	/// <summary>
	/// We remote this plugin, so we can't derive from AbstractJessPlugin. So we reimplement it's members.
	/// </summary>
	[Serializable]
	public class FaceVacsPlugin : System.MarshalByRefObject, PKDPlugin.IJessPlugin
	{
		#region Fields / Constructor
		public System.Collections.ArrayList coreEventHandlerPairList;
		protected java.beans.PropertyChangeSupport propertyChangeSupport;

		public string recordID = "";
		public string issuer = "";
		public string personID = "";
		public string authName = "";
		public string authDate = "";
		public string authSig = "";
		public string name = "";
		public string active = "";
		public string serial = "";
		public int confidence;
		public string receiverWindowIdentifier = "FaceVacsPlugin";

		public FaceVacsPlugin()
		{
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
			this.coreEventHandlerPairList = new System.Collections.ArrayList();					

			//Start the FaceVacs process, which will run in a loop
			System.Diagnostics.Process.Start(@"FaceRec_beta.exe", @"c:\FVEntry_3_6_1\etc\facevacs.cfg " + receiverWindowIdentifier );
		}

		#endregion
		public void Update( int id, int confidence, FaceVacsDatabase.Persons p )
		{
			//Fire off events so that the jess shadowfact is updated
			propertyChangeSupport.firePropertyChange("active", string.Copy( this.active ), string.Copy( p.Acitve ) );
			propertyChangeSupport.firePropertyChange("authdate", string.Copy( this.authDate ), string.Copy( p.AuthDate ) );
			propertyChangeSupport.firePropertyChange("authname", string.Copy( this.authName ), string.Copy( p.AuthName ) );
			propertyChangeSupport.firePropertyChange("authsig", string.Copy( this.authSig ), string.Copy( p.AuthSig ) );
			propertyChangeSupport.firePropertyChange("issuer", string.Copy( this.issuer ), string.Copy( p.Issuer ) );
			propertyChangeSupport.firePropertyChange("name", string.Copy( this.name ), string.Copy( p.Name ) );
			propertyChangeSupport.firePropertyChange("personid", string.Copy( this.personID ), string.Copy( p.PersonID ) );
			propertyChangeSupport.firePropertyChange("recordid", string.Copy( this.recordID ), string.Copy( p.RecordID ) );
			propertyChangeSupport.firePropertyChange("serial", string.Copy(this.serial ), string.Copy( p.Serial ) );
			propertyChangeSupport.firePropertyChange("confidence", new java.lang.Integer( this.confidence ), new java.lang.Integer( confidence ) );
				
			//Update the fields of this object
			this.active = p.Acitve;
			this.authDate = p.AuthDate;
			this.authName = p.AuthName;
			this.authSig = p.AuthSig;
			this.issuer = p.Issuer;
			this.name = p.Name;
			this.personID = p.PersonID;
			this.recordID = p.RecordID;
			this.serial = p.Serial;
			this.confidence = confidence;
		}
		#region ShadowFact Event Methods
		public void addPropertyChangeListener( java.beans.PropertyChangeListener p ) 
		{
			propertyChangeSupport.addPropertyChangeListener( p );
		}
		
		public void removePropertyChangeListener( java.beans.PropertyChangeListener p ) 
		{
			propertyChangeSupport.removePropertyChangeListener( p );
		}	
		#endregion
		#region Event Handlers
		public void RegisterEventHandler( System.Collections.Hashtable PluginEventHandlers ) //CoreEventHandler handler, CoreEvents eventToHandle)
		{
			foreach( PKDPlugin.CoreEventHandlerPair coreEventHandlerPair in this.coreEventHandlerPairList )
			{
				if(PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] == null)
				{
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = coreEventHandlerPair.handler;
				}
				else
				{	
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = ( PKDPlugin.CoreEventHandler )( PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] ) + coreEventHandlerPair.handler;
				}
			}
		}
		public void UnregisterEventHandler( System.Collections.Hashtable PluginEventHandlers )
		{
			foreach( PKDPlugin.CoreEventHandlerPair coreEventHandlerPair in this.coreEventHandlerPairList )
			{
				if(PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] == null)
				{
					return;
				}
				else
				{
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = ( PKDPlugin.CoreEventHandler )( PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] ) - coreEventHandlerPair.handler;
				}
			}
		}
		#region ShadowFact Accessors
		//The captialization in these is significant for the java introspector and jess
		public string getActive()
		{
			return this.active;
		}
		public string getAuthdate()
		{
			return this.authDate;
		}
		public string getAuthname()
		{
			return this.authName;
		}
		public string getAuthsig()
		{
			return this.authSig;
		}
		public string getIssuer()
		{
			return this.issuer;
		}
		public string getName()
		{
			return this.name;
		}
		public string getPersonid()
		{
			return this.personID;
		}
		public string getRecordid()
		{
			return this.recordID;
		}
		public string getSerial()
		{
			return this.serial;
		}
		public int getConfidence()
		{
			return this.confidence;
		}
		
		#endregion
		#endregion
	}
}
