using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PKDPlugin
{
	//Our message across the process boundary has this shape
	public struct COPYDATASTRUCT
	{
		public System.IntPtr dwData;
		public int cbData;
		public System.IntPtr lpData;
	}

	public class Form1 : System.Windows.Forms.Form
	{
		#region Fields / Constructor
		private const int WM_COPYDATA = 0x004A;
		public string receiverWindowIdentifier = "FaceVacsPlugin";
		public PKDPlugin.FaceVacsProxyHelper faceVacsProxyHelper = null;
		public int currentId = -1;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.Text = this.receiverWindowIdentifier;
			
			//Start a server to host remoted objects
			int port = 1976;
			string name = "PKDPlugin.FaceVacsProxyHelper";
			Type type = Type.GetType( name );
			System.Runtime.Remoting.Channels.Tcp.TcpChannel tcpServerChannel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel( port );
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel( tcpServerChannel );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( type, name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );
	
			//The trick -- get an instance of the singleton back from the server to initialize the class member
			//Now we can modify the object and changes will be mirrored on the client
			string uri = "tcp://localhost:" + port + "/" + name;
			this.faceVacsProxyHelper = ( PKDPlugin.FaceVacsProxyHelper ) Activator.GetObject( type, uri );
		}

		#endregion
		[STAThread]
		static void Main()
		{
			Application.Run( new Form1() );
		}

		protected override void WndProc(ref Message m)
		{
			switch ( m.Msg )
			{
				case WM_COPYDATA:

					//Top level message shape
					COPYDATASTRUCT copyDataStruct = 
						( COPYDATASTRUCT ) m.GetLParam( typeof( COPYDATASTRUCT ) );
						
					//Copy message to safe type
					byte[] unstructuredData = new byte[ copyDataStruct.cbData ];
					System.Runtime.InteropServices.Marshal.Copy( copyDataStruct.lpData, unstructuredData, 0, copyDataStruct.cbData );
					
					//decode byte array into usable values
					int id = unstructuredData[ 1 ];
					int confidence = unstructuredData[ 0 ];

					//Match up this id to a record in the database if it is different from the current id
					//This check lets us avoid pointless database queries
					if( id != this.currentId )
					{
						FaceVacsDatabase.Persons p = new FaceVacsDatabase.Persons( @"c:\fventry_3_6_1\var\fvdb.mdb", id);
						//Copy the new information to the proxy helper
						this.faceVacsProxyHelper.active = p.Acitve;
						this.faceVacsProxyHelper.authDate = p.AuthDate;
						this.faceVacsProxyHelper.authName = p.AuthName;
						this.faceVacsProxyHelper.authSig = p.AuthSig;
						this.faceVacsProxyHelper.confidence = confidence;
						this.faceVacsProxyHelper.issuer = p.Issuer;
						this.faceVacsProxyHelper.name = p.Name;
						this.faceVacsProxyHelper.personID = id;
						this.faceVacsProxyHelper.recordID = p.RecordID;
						this.faceVacsProxyHelper.serial = p.Serial;

						//Let client know that shadow fact should be updated
						this.faceVacsProxyHelper.isNew = true;
						this.currentId = id;
					}
					break;
				default:
					base.WndProc(ref m);
					break;
			}
		}
		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(264, 0);
			this.Name = this.receiverWindowIdentifier;
		}
		#endregion
	}
}
