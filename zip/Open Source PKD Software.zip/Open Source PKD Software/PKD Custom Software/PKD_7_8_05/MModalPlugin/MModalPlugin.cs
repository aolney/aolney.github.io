/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	[Serializable]
	public class MModalPlugin : AbstractJessPlugin
	{
		#region Fields / Constructor
		public MModalProxyHelper mModalProxyHelper;
		public string text = "";
		public bool isWorking = false;
		public bool utteranceReady = false;
	
		public MModalPlugin() : base()
		{
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
			this.coreEventHandlerPairList = new System.Collections.ArrayList();		

			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			System.IO.StreamReader reader = new System.IO.StreamReader( "MModalProxyServerConnectionString.txt" );
			string uri = reader.ReadLine();
			reader.Close();
			this.mModalProxyHelper = ( PKDPlugin.MModalProxyHelper )Activator.GetObject( typeof( PKDPlugin.MModalProxyHelper ), uri );	

			//We lauch a thread to poll the proxy object for changes. We can't use delegates and events b/c 
			//of the lack of serialization attributes in the ikvm classpath (property change listeners)
			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}

		#endregion
		/// <summary>
		/// We use a remoted proxy as the data source for the shadow fact. However, the actual plugin
		/// is local, and the local plugin (the actual shadow fact) polls the proxy for changes, only 
		/// updating the shadow fact when a change has occurred.
		/// </summary>
		public void Run()
		{
			while( true )
			{
				if( this.mModalProxyHelper.isNew )
				{
					//Fire off events so that the jess shadowfact is updated
					propertyChangeSupport.firePropertyChange("text", string.Copy( this.text ), string.Copy( this.mModalProxyHelper.text ) );
					propertyChangeSupport.firePropertyChange("isworking", new java.lang.Boolean( this.isWorking ), new java.lang.Boolean( this.mModalProxyHelper.isWorking ) );
					propertyChangeSupport.firePropertyChange("utteranceready", new java.lang.Boolean( this.utteranceReady ), new java.lang.Boolean( this.mModalProxyHelper.utteranceReady ) );
					
					//Update the fields of this object
					this.text = this.mModalProxyHelper.text.TrimEnd();
					this.isWorking = this.mModalProxyHelper.isWorking;
					this.utteranceReady = this.mModalProxyHelper.utteranceReady;
					
					this.mModalProxyHelper.isNew = false;
				}

				System.Threading.Thread.Sleep( 50 );
			}
		}
		#region ShadowFact Accessors
		//The captialization in these is significant for the java introspector and jess
		public string getText()
		{
			return this.text;
		}
		public bool getIsworking()
		{
			return this.isWorking;
		}
		public void setIsworking( bool theBool )
		{
			this.propertyChangeSupport.firePropertyChange( "isworking", this.isWorking, theBool );
			this.isWorking = theBool;
		}
		public bool getUtteranceready()
		{
			return this.utteranceReady;
		}
		public void setUtteranceready( bool theBool )
		{
			this.propertyChangeSupport.firePropertyChange( "utteranceready", this.utteranceReady, theBool );
			this.utteranceReady = theBool;
		}
		#endregion
	}
}
