/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	[Serializable]
	public class FaceVacsPlugin : AbstractJessPlugin
	{
		#region Fields / Constructor
		public FaceVacsProxyHelper faceVacsProxyHelper;

		public string recordID = "";
		public string issuer = "";
		public string authName = "";
		public string authDate = "";
		public string authSig = "";
		public string name = "";
		public string active = "";
		public string serial = "";
		public int confidence;
		public int personID;
		public bool acknowledged = false;
		
		public FaceVacsPlugin() : base()
		{
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
			this.coreEventHandlerPairList = new System.Collections.ArrayList();		

			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			System.IO.StreamReader reader = new System.IO.StreamReader( "FaceVacsProxyServerConnectionString.txt" );
			string uri = reader.ReadLine();
			reader.Close();
			this.faceVacsProxyHelper = ( PKDPlugin.FaceVacsProxyHelper )Activator.GetObject( typeof( PKDPlugin.FaceVacsProxyHelper ), uri );	
			
			//Get the initial values from the proxy. This is useful if the server has been up for a while and 
			//has already found a face.
			this.active = this.faceVacsProxyHelper.active;
			this.authDate = this.faceVacsProxyHelper.authDate;
			this.authName = this.faceVacsProxyHelper.authName;
			this.authSig = this.faceVacsProxyHelper.authSig;
			this.issuer = this.faceVacsProxyHelper.issuer;
			this.name = this.faceVacsProxyHelper.name;
			this.personID = this.faceVacsProxyHelper.personID;
			this.recordID = this.faceVacsProxyHelper.recordID;
			this.serial = this.faceVacsProxyHelper.serial;
			this.confidence = this.faceVacsProxyHelper.confidence;
			this.acknowledged = false;

			//We lauch a thread to poll the proxy object for changes. We can't use delegates and events b/c 
			//of the lack of serialization attributes in the ikvm classpath (property change listeners)
			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}

		#endregion
		/// <summary>
		/// We use a remoted proxy as the data source for the shadow fact. However, the actual plugin
		/// is local, and the local plugin (the actual shadow fact) polls the proxy for changes, only 
		/// updating the shadow fact when a change has occurred.
		/// </summary>
		public void Run()
		{
			while( true )
			{
				//Check if the proxy has changes
				if( this.faceVacsProxyHelper.isNew )
				{
					//Fire off events so that the jess shadowfact is updated
					propertyChangeSupport.firePropertyChange("active", string.Copy( this.active ), string.Copy( this.faceVacsProxyHelper.active ) );
					propertyChangeSupport.firePropertyChange("authdate", string.Copy( this.authDate ), string.Copy( this.faceVacsProxyHelper.authDate ) );
					propertyChangeSupport.firePropertyChange("authname", string.Copy( this.authName ), string.Copy( this.faceVacsProxyHelper.authName ) );
					propertyChangeSupport.firePropertyChange("authsig", string.Copy( this.authSig ), string.Copy( this.faceVacsProxyHelper.authSig ) );
					propertyChangeSupport.firePropertyChange("issuer", string.Copy( this.issuer ), string.Copy( this.faceVacsProxyHelper.issuer ) );
					propertyChangeSupport.firePropertyChange("name", string.Copy( this.name ), string.Copy( this.faceVacsProxyHelper.name ) );
					propertyChangeSupport.firePropertyChange("recordid", string.Copy( this.recordID ), string.Copy( this.faceVacsProxyHelper.recordID ) );
					propertyChangeSupport.firePropertyChange("serial", string.Copy(this.serial ), string.Copy( this.faceVacsProxyHelper.serial ) );
					propertyChangeSupport.firePropertyChange("confidence", new java.lang.Integer( this.confidence ), new java.lang.Integer( this.faceVacsProxyHelper.confidence ) );
					propertyChangeSupport.firePropertyChange("personid", new java.lang.Integer( this.personID ), new java.lang.Integer( this.faceVacsProxyHelper.personID ) );
					this.propertyChangeSupport.firePropertyChange( "acknowledged", this.acknowledged, false );
 
					//Update the fields of this object
					this.active = this.faceVacsProxyHelper.active;
					this.authDate = this.faceVacsProxyHelper.authDate;
					this.authName = this.faceVacsProxyHelper.authName;
					this.authSig = this.faceVacsProxyHelper.authSig;
					this.issuer = this.faceVacsProxyHelper.issuer;
					this.name = this.faceVacsProxyHelper.name;
					this.personID = this.faceVacsProxyHelper.personID;
					this.recordID = this.faceVacsProxyHelper.recordID;
					this.serial = this.faceVacsProxyHelper.serial;
					this.confidence = this.faceVacsProxyHelper.confidence;
					this.acknowledged = false;

					this.faceVacsProxyHelper.isNew = false;
				}

				//It is acceptable for this to be a slow process
				System.Threading.Thread.Sleep( 500 );
			}
		}
		#region ShadowFact Accessors
		//The captialization in these is significant for the java introspector and jess
		public string getActive()
		{
			return this.active;
		}
		public string getAuthdate()
		{
			return this.authDate;
		}
		public string getAuthname()
		{
			return this.authName;
		}
		public string getAuthsig()
		{
			return this.authSig;
		}
		public string getIssuer()
		{
			return this.issuer;
		}
		public string getName()
		{
			return this.name;
		}
		public string getRecordid()
		{
			return this.recordID;
		}
		public string getSerial()
		{
			return this.serial;
		}
		public int getConfidence()
		{
			return this.confidence;
		}
		
		public int getPersonid()
		{
			return this.personID;
		}
		public bool getAcknowledged()
		{
			return this.acknowledged;
		}
		public void setAcknowledged( bool theBool )
		{
			this.propertyChangeSupport.firePropertyChange( "acknowledged", this.acknowledged, theBool );
			this.acknowledged = theBool;
		}
		#endregion
	}
}
