This folder exists for backup and archival purposes only.

Individual software components may have their own license requirements.

Do not redistribute software from this folder
