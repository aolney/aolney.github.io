namespace AIMLtalk {


    //*********************************************************************
    //
    // SectionHandler Class
    //
    // Inherits from the NameValueFileSectionHandler so that fully
    // qualified assembly name can be avoided in the Web.Config file.
    //
    //*********************************************************************

    public class SectionHandler : System.Configuration.NameValueFileSectionHandler {}
}
