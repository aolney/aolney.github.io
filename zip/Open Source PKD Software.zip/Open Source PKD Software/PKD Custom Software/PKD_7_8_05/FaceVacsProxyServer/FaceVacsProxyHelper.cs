using System;

namespace PKDPlugin
{
	/// <summary>
	/// We need a helper class b/c jess cannot make a remoted object a shadow fact
	/// </summary>
	[Serializable]
	public class FaceVacsProxyHelper : System.MarshalByRefObject
	{
		public string recordID = "";
		public string issuer = "";
		public int personID;
		public string authName = "";
		public string authDate = "";
		public string authSig = "";
		public string name = "";
		public string active = "";
		public string serial = "";
		public int confidence;
		public string receiverWindowIdentifier = "FaceVacsPlugin";
		public bool isNew = false;

		public FaceVacsProxyHelper()
		{
			//Start the FaceVacs process, which will run in a loop
			System.Diagnostics.Process.Start(@"FaceRec_beta.exe", @"c:\FVEntry_3_6_1\etc\facevacs.cfg " + receiverWindowIdentifier );
		}		
	}
}
