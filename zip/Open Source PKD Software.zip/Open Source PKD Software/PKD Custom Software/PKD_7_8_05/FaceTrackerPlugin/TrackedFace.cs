/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	public class TrackedFace
	{
		#region Fields / Constructor
		public int id;
		public SharperCV.CvPoint center;
		public SharperCV.CvRect boundingBox;
		public bool isMatched;
		public int matchCount;

		public int maxWeight = 30;
		public int minWeight = 10;

		public TrackedFace( int id, SharperCV.CvRect boundingBox )
		{
			this.id = id;
			this.boundingBox = boundingBox;
			this.center = Calculator.Center( boundingBox );
			this.isMatched = false;		
			this.matchCount = this.minWeight;
		}	
		#endregion
		public void Match( SharperCV.CvRect face )
		{
			this.boundingBox = face;
			this.center = Calculator.Center( face );
			this.isMatched = true;
			if( this.matchCount < this.maxWeight )
				this.matchCount++;
		}
	}
}
