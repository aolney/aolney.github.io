/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// LSA space wraps the raw LSA space. It provides a hashtable of 
	/// Term objects (key word, value vector & weight), num dimensions and singular values 
	/// for this space. It is intentionally light b/c it is a serializable 
	/// container class
	/// </summary>
	[Serializable]
	public class LSASpace
	{
		//Administrativa
		public string spaceName;
		public string author;
		public string sourceDocumentDescription;
		public readonly System.DateTime creationDate;

		//The core components
		public int numberDimensions;
		public System.Collections.Hashtable termHash;
		public float[] singularValues;

		public LSASpace( string spaceName, string author, string sourceDocumentDescription, int numberDimensions, float[] singularValues, System.Collections.Hashtable termHash )
		{
			this.spaceName = spaceName;
			this.author = author;
			this.sourceDocumentDescription = sourceDocumentDescription;

			this.numberDimensions = numberDimensions;
			this.singularValues = singularValues;
			this.termHash = termHash;

			this.creationDate = System.DateTime.Now;
		}
	}
}
