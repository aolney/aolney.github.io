/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDDialogue
{
	public class NLG
	{
		#region Fields / Constructor
		//Sequencing and speech
		public ExploreRobotHead.TTSTest tts;

		//Models
		public PKDDialogue.TurnSemanticAnalyzer semanticAnalyzer = null;
		public LSAModule.Bigrams bigrams = null;
		public AIMLtalk.ChatBot chatBot = null;
		public ConversationProfileManager conversationProfileManager = null;

		//Dialogue containers
		public System.Collections.ArrayList currentDialogueList = null;
		public System.Collections.ArrayList masterDialogueList = null;
		public System.Collections.ArrayList currentPontificationList = null;
		public System.Collections.ArrayList masterPontificationList = null;
		public System.Collections.ArrayList currentStoryList = null;
		public System.Collections.ArrayList masterStoryList = null;
	
		public string[] pontificationMarkers = new string[] { "Well anyways, ", "And by the way, ", "I was just thinking, ", "You know that reminds me, ", "When you were talking I thought ", "I just had a thought I'd like to share with you, ", "You might be interested in this, ", "Yeah, well the thing that gets me is this, " };
		public string[] storyMarkers = new string[] { "Oh let me read you a passage I really like from #.", "Here's something I wrote that I think you'll like. It's from #.", "In # I wrote a little passage that I'd like to read to you.", "Here's a little writing of mine you can find in #.", "Would you like to hear so of my book, #? Let me read you a little." };

		//Semantic animation constants
		public string positiveBag = "valis god robot friend peace trust";
		public string negativeBag = "pain death suffering uncertainty deception conflict";
		public float[] positiveVector = null;
		public float[] negativeVector = null;
		public float extremeThreshold = .20F;
		public float mildThreshold = .10F;

		//To clean ASR input
		public System.Text.RegularExpressions.Regex percentRegex;
		public System.Text.RegularExpressions.Regex commaRegex;
		public System.Text.RegularExpressions.Regex pushRegex;
		public string microphoneDevice = "Plantronics Headset"; //"AK5370"

		//Cumulative state
		public int sequentialChatterbotTurns = 0;
		public int totalChatterbotTurns = 0;
		public string lastResponse = ""; //for deletion purposes by DeleteLastResponse
		public string lastInput = "";
		/// <summary>
		/// The pause between document collection elements. A comma works well here
		/// </summary>
		public string documentCollectionPause = @" , ";

		//Source files 
		public string lsaFile		= @"pkd_5_3_2005.lsa";
		public string dialogueFile	= @"pkdDialogue.dat";
		public string bigramsFile	= @"pkdBigrams.dat";
		public string pontificationFile = @"Pontification.dat";

		public System.Random random = new Random();
		public bool debug = false;
		public bool useStories = true;
		
		public NLG()
		{
			this.percentRegex = new System.Text.RegularExpressions.Regex( "%[^%]+%", System.Text.RegularExpressions.RegexOptions.Compiled );
			this.commaRegex = new System.Text.RegularExpressions.Regex( "(  )+", System.Text.RegularExpressions.RegexOptions.Compiled );
			this.pushRegex = new System.Text.RegularExpressions.Regex( "(push )+", System.Text.RegularExpressions.RegexOptions.Compiled );

			Console.Write( "Loading TTSScheduler..." );
			this.tts = new ExploreRobotHead.TTSTest();
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading Audio Device..." );
			//this.tts.audioMixerHelper = new AudioMixer.Helper();
			//NEW SECCTION for remoted audiomixer
			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			System.IO.StreamReader reader = new System.IO.StreamReader( "MModalProxyServerConnectionString.txt" );
			string uriString = reader.ReadLine();
			reader.Close();
			//must alter the object type, but use the same host info as MModalProxyServer
			System.Uri uri = new Uri( uriString );
			uriString = uriString.Replace( uri.AbsolutePath , "/AudioMixer.Helper" );
			this.tts.audioMixerHelper = ( AudioMixer.Helper )Activator.GetObject( typeof( AudioMixer.Helper ), uriString );	
			//END new section
			this.tts.audioMixerHelper.SetCurrentMixer( this.microphoneDevice );	//This is the acoustic magic usb adapter device
			this.tts.audioMixerHelper.SetMute( false );				//Set the microphone to be on at startup
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading LSA space..." );
			this.semanticAnalyzer = new PKDDialogue.TurnSemanticAnalyzer( this.lsaFile, new pkd_5_3_2005_ILSACalculatorImplementation() );
			this.positiveVector = this.semanticAnalyzer.GetVector( this.positiveBag );
			this.negativeVector = this.semanticAnalyzer.GetVector( this.negativeBag );
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading Bigrams..." );
			this.bigrams = ( LSAModule.Bigrams) this.semanticAnalyzer.Deserialize( this.bigramsFile );
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading PKD Dialogue..." );
			this.masterDialogueList = ( System.Collections.ArrayList ) this.semanticAnalyzer.Deserialize( this.dialogueFile );
			this.currentDialogueList = ( System.Collections.ArrayList) this.masterDialogueList.Clone();
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading Chatterbot..." );
			this.chatBot = new AIMLtalk.ChatBot();
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading Profiles..." );
			this.conversationProfileManager = new ConversationProfileManager();
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading Pontifications..." );
			this.masterPontificationList = this.ReadInPontifications();
			this.currentPontificationList = ( System.Collections.ArrayList ) this.masterPontificationList.Clone();
			Console.WriteLine( "\tDONE!" );

			Console.Write( "Loading Stories..." );
			this.masterStoryList = this.ReadInStories();
			this.currentStoryList = ( System.Collections.ArrayList ) this.masterStoryList.Clone();
			Console.WriteLine( "\t\tDONE!" );
		}
		#endregion

		#region Ignore
		/// <summary>
		/// Used to find some of the cohesion metrics. a hack that should not be used at runtime
		/// </summary>
		public void TurnToTurnMeasures()
		{
			double totalRelevance = 0;
			double totalInformativity = 0;

			float[] measures = new float[ 2 ];
			System.Collections.ArrayList basis = new System.Collections.ArrayList();
			Turn turn = null;
			for( int i = 0; i < this.currentDialogueList.Count; i++ )
			{
				turn = ( Turn ) this.currentDialogueList[ i ];
				if( turn.isDickSpeaker == false )
				{
					//Set up span with this question
					basis.Clear();
					string[] theSplit = turn.document.text.Split( ' ' );
					foreach( string word in theSplit )
						this.semanticAnalyzer.DecomposeReturnInformativity( this.semanticAnalyzer.GetVector( word ), basis );

					//Decompose the next turn
					if( i + 1 < this.currentDialogueList.Count )
					{
						turn = ( Turn ) this.currentDialogueList[ i + 1 ];
						measures = this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( turn.document.vector, basis );
					}
					else
						break;

					totalRelevance += measures[ 0 ];
					if( !double.IsNaN( measures[ 1 ] ) )
						totalInformativity += measures [ 1 ];
				}
			}

			totalRelevance /= currentDialogueList.Count;
			totalInformativity /= currentDialogueList.Count;

			Console.WriteLine( "Avg turn relevance " + totalRelevance );
			Console.WriteLine( "Avg turn informativity " + totalInformativity );
		}
		#endregion
		#region TTS markup
		/// <summary>
		/// Inserts a SAPI4 style pause used by the Babel TTS
		/// </summary>
		/// <param name="milliseconds"></param>
		/// <returns></returns>
		public string InsertPause( int milliseconds )
		{
			return @"\pau=" + milliseconds + @"\";
		}
		/// <summary>
		/// Inserts a SAPI4 style bookmark used by the Babel TTS
		/// </summary>
		/// <param name="bookmarkId"></param>
		/// <returns></returns>
		public string InsertBookmark( int bookmarkId )
		{
			return @"\mrk=" + bookmarkId + @"\";
		}

		public string DoTTSMarkup( LSAModule.DocumentCollection documentCollection )
		{
			string text = "";
			foreach( LSAModule.AbstractDocument document in documentCollection.children )
			{
				text += this.GetSingleSemanticAnimation( document.vector ) + " " + document.text + this.documentCollectionPause;
			}
			return text + " " + this.GetSingleENDSemanticAnimation( text );
		}
		public string DoTTSMarkup( string inputText, float[] vector )
		{
			return  this.GetSingleSemanticAnimation( vector ) + " " + inputText + " " + this.GetSingleENDSemanticAnimation( inputText );
		}
		
		/// <summary>
		/// Given a string of text, finds an animation that matches it
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		public string GetSingleSemanticAnimation( string text )
		{
			string animation = "";

			//Use LSA to determine the valence and degree of the animation
			float[] textVector = this.semanticAnalyzer.GetVector( text );
			float positiveCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.positiveVector );
			float negativeCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.negativeVector );

			//A positive animation is appropriate
			if( positiveCosine > negativeCosine )
			{
				//an extremely positive animation is appropriate
				if( positiveCosine > this.extremeThreshold )
				{
					animation = this.tts.RandomExtremelyPositiveReactionAnimation();
				}
				else if( positiveCosine > this.mildThreshold )
				{
					animation = this.tts.RandomMildlyPositiveReactionAnimation();
				}
				else
					animation = this.tts.RandomNeutralReactionAnimation();
			}
			else
			{
				if( negativeCosine > this.extremeThreshold )
				{
					animation = this.tts.RandomExtremelyNegativeReactionAnimation();
				}
				else if( negativeCosine > this.mildThreshold )
				{
					animation = this.tts.RandomMildlyNegativeReactionAnimation();
				}
				else
					animation = this.tts.RandomNeutralReactionAnimation();
			}
			return this.tts.animationMarker + animation;
		}

		public string GetSingleENDSemanticAnimation( string text )
		{
			string animation = "";
			//Use LSA to determine the valence and degree of the animation
			float[] textVector = this.semanticAnalyzer.GetVector( text );
			float positiveCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.positiveVector );
			float negativeCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.negativeVector );

			//A positive animation is appropriate
			if( positiveCosine > negativeCosine )
			{
				//an extremely positive animation is appropriate
				if( positiveCosine > this.mildThreshold )
				{
					animation = this.tts.RandomExtremelyPositiveReactionAnimation();
				}
				else
				{
					animation = this.tts.RandomMildlyPositiveReactionAnimation();
				}
			}
			else
			{
				if( negativeCosine > this.mildThreshold )
				{
					animation = this.tts.RandomExtremelyNegativeReactionAnimation();
				}
				else
				{
					animation = this.tts.RandomMildlyNegativeReactionAnimation();
				}
			}
			return this.tts.animationMarker + animation;
		}

		public string GetSingleSemanticAnimation( float[] textVector )
		{
			string animation = "";

			//Use LSA to determine the valence and degree of the animation
			float positiveCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.positiveVector );
			float negativeCosine = this.semanticAnalyzer.lsaCalculator.Cosine( textVector, this.negativeVector );

			//A positive animation is appropriate
			if( positiveCosine > negativeCosine )
			{
				//an extremely positive animation is appropriate
				if( positiveCosine > this.extremeThreshold )
				{
					animation = this.tts.RandomExtremelyPositiveReactionAnimation();
				}
				else if( positiveCosine > this.mildThreshold )
				{
					animation = this.tts.RandomMildlyPositiveReactionAnimation();
				}
				else
					animation = this.tts.RandomNeutralReactionAnimation();
			}
			else
			{
				if( negativeCosine > this.extremeThreshold )
				{
					animation = this.tts.RandomExtremelyNegativeReactionAnimation();
				}
				else if( negativeCosine > this.mildThreshold )
				{
					animation = this.tts.RandomMildlyNegativeReactionAnimation();
				}
				else
					animation = this.tts.RandomNeutralReactionAnimation();
			}
			return this.tts.animationMarker + animation;
		}
		public string DoBatchTTSMarkup( string text )
		{
			string[] theSplit = text.Replace( ".", "| ." ).Replace( ",", "| ," ).Split( '|' );
			System.Text.StringBuilder final = new System.Text.StringBuilder();
			foreach( string line in theSplit )
				final.Append( " " + this.GetSingleSemanticAnimation( line ) + " " + line );
			return final.ToString();
		}
		#endregion
		#region Generate Dialogue
		#region Generate Response Subroutines
		public void GenerateParagraphs( int numberOfParagraphs, string input, float[] inputVector, System.Collections.ArrayList basis, System.Collections.ArrayList responseList )
		{
			LSAModule.Document queryDocument = new LSAModule.Document( 0, input, inputVector );
			System.Collections.ArrayList paragraphList = this.semanticAnalyzer.GetTopNMatchingTurns( queryDocument, currentDialogueList, 20 );
		
			//Generate a response for each of the top matching turns
			Turn turn;
			Response response;
			for( int i = 0; i < numberOfParagraphs; i ++ )
			{
				turn = ( Turn ) paragraphList[ i ];

				response = new Response( NLGSource.Paragraph, turn.document.text, turn.document.vector, turn.document.sortingValue );
				response.AdjustBasisMeasures( this.semanticAnalyzer.QuickDecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
				
				//New section to add pauses after sentences
				response.speakableText = this.DoTTSMarkup( ( LSAModule.DocumentCollection )turn.document );
				//response.speakableText = response.text; //this.DoTTSMarkup( ( LSAModule.DocumentCollection )turn.document );
			
				responseList.Add( response );
			}
		}
		
		public void GenerateSentence( float[] inputVector, System.Collections.ArrayList paragraphList, System.Collections.ArrayList basis, System.Collections.ArrayList responseList )
		{
			LSAModule.DocumentCollection documentCollection = ( LSAModule.DocumentCollection )this.semanticAnalyzer.SummarizeTurnsToSentences( paragraphList, 3 );
			float[] vector = this.semanticAnalyzer.GetLocalWeightedVector( documentCollection.text );
			Response response = new Response( NLGSource.Sentence, documentCollection.text, vector, this.semanticAnalyzer.lsaCalculator.Cosine( vector, inputVector ) );
			response.AdjustBasisMeasures( this.semanticAnalyzer.QuickDecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
			
			responseList.Add( response );
		}

		public Response GenerateChatterbotResponse( string input, float[] inputVector, System.Collections.ArrayList basis, System.Collections.ArrayList responseList )
		{
			char[] theChars = this.chatBot.Send( "me", input ).ToLower().ToCharArray();
			//Clean up the response from the chatterbot for LSA
			char[] newChars = new char[ theChars.Length ];
			char c;
			for( int i = 0; i < theChars.Length; i++ )
			{
				c = theChars[ i ];
				if( char.IsLetter( c ) || c.Equals( ' ' ) || char.IsNumber( c ) )
					newChars[ i ] = c;
				else
					newChars[ i ] = ' ';
			}
			string reply = new string( newChars );
			Response response = null;

			reply = this.pushRegex.Replace( reply, "" );

			if( !reply.Trim().EndsWith( "dangerous recursion   parsing stopped" ) ) //from startswith
			{
				float[] vector = this.semanticAnalyzer.GetLocalWeightedVector( reply );
				response = new Response( NLGSource.Chatterbot, reply, vector, this.semanticAnalyzer.lsaCalculator.Cosine( inputVector, vector ) );
				response.AdjustBasisMeasures( this.semanticAnalyzer.QuickDecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
				
				//response.speakableText = this.commaRegex.Replace( this.percentRegex.Replace( response.text, " , " ), " , " ); // this.DoTTSMarkup( this.commaRegex.Replace( this.percentRegex.Replace( response.text, " , " ), " , " ), response.vector );
				response.speakableText = this.DoTTSMarkup( this.commaRegex.Replace( this.percentRegex.Replace( response.text, " , " ), " , " ), response.vector );
				
				responseList.Add( response );
			}
			return response;
		}

		/// <summary>
		/// Check and see if the response is a fragment. If so, extend it
		/// </summary>
		public Response ExtendResponse( Response response, System.Collections.ArrayList responseList )
		{
			//Get probability that the last word of the turn is the last word of a turn. If below threshold, we 
			//concatenate turns.
			string[] theSplit = response.text.Split( ' ' );
			float probability = bigrams.GetProbablity( theSplit[ theSplit.Length - 1 ], "</t>" );
			Console.WriteLine("Extending probability: " + probability);
			
			//Keep extending as long as we don't end in a turn and still have material to extend with
			if( probability < .011 && responseList.Count > 0 )
			{
				//Just take response in responselist with highest cosine to the current response
				foreach( Response r in responseList )
				{
					if( r.nlgSource.Equals( PKDDialogue.NLGSource.Chatterbot ) )
						r.sortingValue = 0;
					else
						r.sortingValue = this.semanticAnalyzer.lsaCalculator.Cosine( response.vector, r.vector );
				}
				responseList.Sort();

				//Add text of closest response to the the current response and remove it from further consideration
				response.text += " " + ( ( Response ) responseList[ responseList.Count - 1 ]).text;
				response.speakableText += " " + ( ( Response ) responseList[ responseList.Count - 1 ]).speakableText;
				responseList.RemoveAt( responseList.Count - 1 );
				
				//See if we need to extend the new text
				//theSplit = response.text.Split( ' ' );
				//probability = bigrams.GetProbablity( theSplit[ theSplit.Length - 1 ], "</t>" );
			}
			return response;
		}
		
		
		#endregion
		public string GenerateResponse( string input )
		{
			//if( input == this.lastInput )
			//	return "";
			this.lastInput = input;
			
			Response reply = null;

			if( this.totalChatterbotTurns > 9 )
			{
				this.totalChatterbotTurns = 0;
				if( useStories == true )
					return this.GetStory( input + " " + this.lastInput );
			}

			//If the chatterbot has been called 3 times in a row, introduce a topic
			if( this.sequentialChatterbotTurns > 2 )
			{
				this.sequentialChatterbotTurns = 0;
				if( useStories == true )
					return this.GetPontification( input + " " + this.lastInput );
			}

			//Sometimes the ASR gives us garbage with quotes
			input = this.percentRegex.Replace( input, "" );

			//look for this that these those
			/*
			System.Text.RegularExpressions.Regex regex = new System.Text.RegularExpressions.Regex( "(that|those)", System.Text.RegularExpressions.RegexOptions.IgnoreCase );
			if( regex.IsMatch( input ) )
				input += " " + this.lastResponse;
				*/
			input = input.Replace( "'", " " );

			int numberOfParagraphs = 20; //5
			System.Collections.ArrayList responseList = new System.Collections.ArrayList();

			#region Create a basis for calculating cohesion metrics
			System.Collections.ArrayList basis = this.semanticAnalyzer.WordsToBasis( input );
			float[] inputVector = this.semanticAnalyzer.GetLocalWeightedVector( input );
			float inputVectorLength = this.semanticAnalyzer.lsaCalculator.Length( inputVector );
			#endregion
			#region Do generation
			this.GenerateParagraphs( numberOfParagraphs, input, inputVector, basis, responseList );
			//this.GenerateSentence( inputVector, paragraphList, basis, responseList );
			//Default reply is chatterbot reply
			reply = this.GenerateChatterbotResponse( input, inputVector, basis, responseList );
			#endregion
			#region Calculate probability of being a good response
			foreach( Response r in responseList )
			{
				//First equation
				double e =  Math.Exp( -1.394 * r.cosine + 2.441 * r.relevance + 2.323 * r.informativity );
				r.sortingValue = ( float )( e / ( 1 + e ) );
			}
			#endregion
			
			//Sort on probability, ascending
			responseList.Sort();

			//Debug section
			if( debug )
			{
				foreach( Response r in responseList )
				{
					//writer.WriteLine( "Cos:{0}\tRel:{1}\tInfo:{2}\tSource:{3}\tProb:{4}\t{5}", r.cosine, r.relevance, r.informativity, r.nlgSource, r.sortingValue, r.text );
				}
			}

			#region Ad hoc selection rules
			//If input vector length is poor, input is not distinctive enough to do a good query. Use chatterbot
			if( inputVectorLength < .028 )
			{
				Console.WriteLine( "Input vector length is " + inputVectorLength + ". Using chatterbot default" );
				//do nothing, chatterbot is default response
			}
			else
			{
				//Search responselist for most probable response with info > .78. responselist is already sorted ascending on probability
				for( int i = responseList.Count - 1; i > -1; i-- )
				{
					reply = ( Response ) responseList[ i ];
					if( reply.informativity > .70 ) //.78
					{
						responseList.RemoveAt( i ); //if we extend the response, we don't want to repeat ourselves
						break;
					}
				}
				//If reply is a paragraph, remove it from future generation
				//This isn't too slow b/c currentDialogueList is still sorted by the last query
				if( reply.nlgSource.Equals( PKDDialogue.NLGSource.Paragraph ) )
				{
					//Reset the number of sequential chatterbot turns to zero.
					this.sequentialChatterbotTurns = 0;
					for( int i = 0; i < this.currentDialogueList.Count; i++ )
					{
						Turn turn = ( Turn )this.currentDialogueList[ i ];
						if( turn.document.text.StartsWith( reply.text ) )
						{
							this.currentDialogueList.RemoveAt( i );
							break;
						}
					}

					//Extend the reply if it is a fragment
					reply = this.ExtendResponse( reply, responseList );
				}
			}
			#endregion

			//if( debug ) this.writer.WriteLine( "FINAL RESPONSE\t{0}", reply.text );

			this.lastResponse = reply.text; //in case we want to delete it later with DeleteLastResponse

			if( reply.nlgSource.Equals( PKDDialogue.NLGSource.Chatterbot ) )
			{
				this.sequentialChatterbotTurns++;
				this.totalChatterbotTurns++;
			}

			return reply.speakableText.Replace( " t ", "'t " ).Replace( " s ", "'s " ).Replace( "\"", "" ) ;
		}

		public void ResetDialogue()
		{
			this.currentDialogueList = ( System.Collections.ArrayList )this.masterDialogueList.Clone();
			this.currentPontificationList = ( System.Collections.ArrayList ) this.masterPontificationList.Clone();
			this.currentStoryList = ( System.Collections.ArrayList ) this.masterStoryList.Clone();
		}
		/// <summary>
		/// Fake a user input by looking up their conversation profile and choosing an initiator randomly from that.
		/// </summary>
		public void InitiateConversation()
		{
			string input = "tell me a joke";
			if( this.conversationProfileManager.currentConversationProfile != null )
			{
				int selection = this.random.Next( this.conversationProfileManager.currentConversationProfile.initiators.Length );
				input = this.conversationProfileManager.currentConversationProfile.initiators[ selection ];
			}
			this.GenerateResponse( input );
		}
		public string GreetCurrentProfile()
		{
			string greeting = "";

			System.DateTime lastTimeSeen = this.conversationProfileManager.currentConversationProfile.dateTime;

			//If we haven't seen them today or in the last hour or haven't greeted them
			if( !lastTimeSeen.Date.Equals( System.DateTime.Now.Date ) || !lastTimeSeen.Hour.Equals( System.DateTime.Now.Hour ) || !this.conversationProfileManager.hasGreetedCurrentProfile )
			{
				greeting = "Hi " + this.conversationProfileManager.currentConversationProfile.name;
				this.conversationProfileManager.currentConversationProfile.dateTime = System.DateTime.Now;
				this.conversationProfileManager.hasGreetedCurrentProfile = true;
			}

			return greeting;
		}
		public string ThankRecentProfiles()
		{
			System.Collections.ArrayList recentProfiles = new System.Collections.ArrayList();
			foreach( ConversationProfile profile in this.conversationProfileManager.conversationProfileHash.Values )
			{
				//We've seen them today in the last hour
				if( profile.dateTime.Date.Equals( System.DateTime.Now.Date ) && profile.dateTime.Hour.Equals( System.DateTime.Now.Hour ) )
					recentProfiles.Add( profile );
			}

			string thanks = "";
			foreach( ConversationProfile profile in recentProfiles )
			{
				if( profile.priority.Equals( ConversationPriority.Acquaintance ) )
					thanks += " Thank you for coming " + profile.name + this.documentCollectionPause;
				else
					thanks += " Thank you so much for coming " + profile.name + " it was so nice to see you again " + this.documentCollectionPause;
			}
			return thanks;
		}

		#endregion
		/// <summary>
		/// If a pkd response sucks, we can remove it from the dialogue list structure so it 
		/// won't be considered in the future. The list must be saved back to file for the 
		/// change to be permanent.
		/// </summary>
		public void  DeleteLastResponse()
		{
			for( int i = 0; i < this.masterDialogueList.Count; i++ )
			{
				Turn turn = ( Turn )this.masterDialogueList[ i ];
				if( turn.document.text.Equals( this.lastResponse ) )
				{
					this.masterDialogueList.RemoveAt( i );
					break;
				}
			}
		}
		#region Testing
		public void Test()
		{
			//for testing only
			string inputFile = @"C:\Documents and Settings\Andrew Olney\Desktop\fwdTest.txt";
			System.IO.StreamWriter writer = null;
			System.IO.StreamReader reader = null;
			reader = new System.IO.StreamReader( inputFile );
			writer = new System.IO.StreamWriter( inputFile + "OUT" );


			string line = "";
			while( ( line = reader.ReadLine() ) != null )
			{
				if( debug ) writer.WriteLine( "INPUT>" + line );
				GenerateResponse( line );
			}
			if( debug ) writer.Flush();
			if( debug ) writer.Close();
			if( debug ) reader.Close();
		}
		public void ParameterFinding()
		{
			System.IO.StreamReader reader = new System.IO.StreamReader( "1clean.txt" );
			System.IO.StreamWriter writer = new System.IO.StreamWriter( "1cleanout.txt" );
	
			//Write header for output file
			writer.WriteLine( "questionId\tcorrectClass\tcosine\trelevance\tinformativity\tquestion\tresponse\tquestionLength\tresposneLength\tquestionVectorLength\tresponseVectorLength\twordOverlap\toverlapVectorLength\tcos2" );

			string line = "";
			while( ( line = reader.ReadLine() ) != null )
			{
				string[] theSplit = line.Split( '	' );
				string questionId	= theSplit[ 0 ];
				string correctClass	= theSplit[ 1 ];
				string cosine		= theSplit[ 2 ];
				string relevance	= theSplit[ 3 ];
				string informativity= theSplit[ 4 ];
				string question		= theSplit[ 5 ];
				string response		= theSplit[ 6 ];

				//Calculate word overlap
				//Create hashtable containing words in question as keys
				System.Collections.Hashtable questionHash = new System.Collections.Hashtable();
				string[] questionSplit = question.Split( ' ' );
				int questionLength = questionSplit.Length;
				foreach( string word in questionSplit )
				{
					if( !questionHash.ContainsKey( word ) )
						questionHash.Add( word, 0 );
				}
				//Create hashtable containing words in response as keys
				System.Collections.Hashtable responseHash = new System.Collections.Hashtable();
				string[] responseSplit = response.Split( ' ' );
				int responseLength = responseSplit.Length;
				foreach( string word in responseSplit )
				{
					if( !responseHash.ContainsKey( word ) )
						responseHash.Add( word, 0 );
				}
				//Calculate overlap
				float wordOverlap = 0;
				float overlapVectorLength = 0;
				foreach( string word in questionHash.Keys )
				{
					if( responseHash.ContainsKey( word ) && word.Length > 3 )
					{
						wordOverlap++;
						LSAModule.Term term = ( LSAModule.Term ) this.semanticAnalyzer.lsaSpace.termHash[ word ];
						if( term != null )
							overlapVectorLength += this.semanticAnalyzer.lsaCalculator.Length( term.vector );
					}
				}
				wordOverlap /= responseLength + questionLength;

				float questionVectorLength = this.semanticAnalyzer.lsaCalculator.Length( this.semanticAnalyzer.GetLocalWeightedVector( question ) );
				float responseVectorLength = this.semanticAnalyzer.lsaCalculator.Length( this.semanticAnalyzer.GetLocalWeightedVector( response ) );

				float cos2 = this.semanticAnalyzer.CompareTwoStringsWithLocalWeighting( question, response );

				//Write it out to our new file
				writer.WriteLine( questionId + "\t" + correctClass + "\t" + cosine + "\t" + relevance + "\t" + 
					informativity + "\t" + question + "\t" + response + "\t" + questionLength + "\t" + responseLength + "\t" +
					questionVectorLength + "\t" + responseVectorLength + "\t" + wordOverlap + "\t" + overlapVectorLength + "\t" + cos2 );

			}
			writer.Flush();
			writer.Close();
			reader.Close();
		}
		#endregion
		#region Stories
		public System.Collections.ArrayList ReadInStories()
		{
			System.Collections.ArrayList stories = new System.Collections.ArrayList();

			System.IO.DirectoryInfo directoryInfo = new System.IO.DirectoryInfo( System.IO.Directory.GetCurrentDirectory()+"\\stories\\"  );
			System.IO.FileInfo[] fileInfoArray = directoryInfo.GetFiles("*.txt");
			
			int index = 0;
			foreach( System.IO.FileInfo fileInfo in fileInfoArray )
			{
				System.IO.StreamReader reader = new System.IO.StreamReader( fileInfo.FullName );
				System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();
				string line = null;
				while( ( line = reader.ReadLine() ) != null )
				{
					stringBuilder.Append( line + " " );
				}
				string story = stringBuilder.ToString();
				stories.Add( new Story( fileInfo.Name.Replace( fileInfo.Extension, "" ), 
					this.DoBatchTTSMarkup( story ), 
					this.semanticAnalyzer.GetLocalWeightedVector( story ) ) );
				reader.Close();
			}
			return stories;
		}
		public string GetRandomStory()
		{
			int selection = this.random.Next( this.currentStoryList.Count - 1 );
			Story story = ( Story ) this.currentStoryList[ selection ];
			this.currentStoryList.RemoveAt( selection );

			//Select a story marker
			string storyMarker = this.storyMarkers[ this.random.Next( this.storyMarkers.Length - 1 ) ].Replace( "#", story.name );
		
			return storyMarker + " " + story.text; //story.document.text;
		}	
		public string GetStory( string query )
		{
			System.Collections.ArrayList topList = this.semanticAnalyzer.GetTopNMatchingDocuments( new LSAModule.Document( 0, query, this.semanticAnalyzer.GetLocalWeightedVector( query ) ), this.currentStoryList, 1 );

			Story story = ( Story ) topList[ 0 ];

			//Select a story marker
			string storyMarker = this.storyMarkers[ this.random.Next( this.storyMarkers.Length - 1 ) ].Replace( "#", story.name );
		
			return storyMarker + " " + story.text;
		}	
	
		#endregion
		#region Pontifications
		public System.Collections.ArrayList ReadInPontifications()
		{
			System.Collections.ArrayList pontifications = new System.Collections.ArrayList();

			System.IO.StreamReader reader = new System.IO.StreamReader( "Pontification.txt" );
			int index = 0;
			string line = null;
			while( ( line = reader.ReadLine() ) != null )
			{
				LSAModule.Document d = new LSAModule.Document( index++, this.DoBatchTTSMarkup( line ), this.semanticAnalyzer.GetLocalWeightedVector( line ) );
				pontifications.Add( d );
			}
			reader.Close();
			return pontifications;
		}
		public string GetRandomPontification()
		{
			int selection = this.random.Next( this.currentPontificationList.Count - 1 );
			LSAModule.Document pontification = ( LSAModule.Document ) this.currentPontificationList[ selection ];
			this.currentPontificationList.RemoveAt( selection );

			//add pontification marker
			return this.pontificationMarkers[ this.random.Next( pontificationMarkers.Length - 1) ] + pontification.text;
		}
		public string GetPontification( string query )
		{
			System.Collections.ArrayList topList = this.semanticAnalyzer.GetTopNMatchingDocuments( new LSAModule.Document( 0, query, this.semanticAnalyzer.GetVector( query ) ), this.currentPontificationList, 1 );

			LSAModule.Document pontification = ( LSAModule.Document ) topList[ 0 ];

			//add pontification marker
			return this.pontificationMarkers[ this.random.Next( pontificationMarkers.Length - 1) ] + pontification.text;
		}
		#endregion
	}
}
#region Old stuff
/*
 * public void GenerateBackup( string input )
		{
			int numberOfParagraphs = 5;
			System.Collections.ArrayList responseList = new System.Collections.ArrayList();

			//Create a basis for calculating cohesion metrics
			System.Collections.ArrayList basis = new System.Collections.ArrayList();
			float[] inputVector = this.semanticAnalyzer.GetLocalWeightedVector( input );
			float inputVectorLength = this.semanticAnalyzer.lsaCalculator.Length( inputVector );
			this.semanticAnalyzer.DecomposeReturnInformativity( inputVector, basis );
			
			Console.WriteLine( "Input length:{0}", inputVectorLength );

			//------------------
			//Paragraph level
			//------------------
			Console.WriteLine( "_________________________________________________________________" );
			LSAModule.Document document = new LSAModule.Document( 0, input, inputVector );
			System.Collections.ArrayList paragraphList = this.semanticAnalyzer.GetTopNMatchingTurns( document, currentDialogueList, 20 );
			
			//Generate a response for each of the top matching turns
			Turn turn;
			Response response;
			for( int i = 0; i < numberOfParagraphs; i ++ )
			{
				turn = ( Turn ) paragraphList[ i ];
				response = new Response( NLGSource.Paragraph, turn.document.text, turn.document.vector, turn.document.sortingValue );
				float cos1 = this.semanticAnalyzer.lsaCalculator.Cosine( inputVector, response.vector );
				response.AdjustBasisMeasures( this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
				basis.RemoveAt( 1 );
				responseList.Add( response );

				Console.WriteLine( "Paragraph> {0} Cosine:{1}\tRel:{2}\tInfo:{3}\t{4}", i, response.cosine, response.relevance, response.informativity, response.text);	
			}
			Console.WriteLine();

			//------------------
			//Sentence level
			//------------------
			LSAModule.DocumentCollection documentCollection = ( LSAModule.DocumentCollection )this.semanticAnalyzer.SummarizeTurnsToSentences( paragraphList, 3 );
			response = new Response( NLGSource.Sentence, documentCollection.text, this.semanticAnalyzer.GetLocalWeightedVector( documentCollection.text ), this.semanticAnalyzer.CompareTwoStringsWithLocalWeighting( documentCollection.text, input ) );
			response.AdjustBasisMeasures( this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
			basis.RemoveAt( 1 );
			responseList.Add( response );

			Console.WriteLine( "Sentence> Cosine:{0}\tRel:{1}\tInfo:{2}\t{3}", response.cosine, response.relevance, response.informativity, response.text );
			Console.WriteLine();

			//------------------
			//Chatterbot
			//------------------
			char[] theChars = this.chatBot.Send( "me", input ).ToCharArray();
			//Clean up the response from the chatterbot for LSA
			char[] newChars = new char[ theChars.Length ];
			char c;
			for( int i = 0; i < theChars.Length; i++ )
			{
				c = theChars[ i ];
				if( char.IsLetter( c ) || c.Equals( ' ' ) )
					newChars[ i ] = c;
				else
					newChars[ i ] = ' ';
			}
			string reply = new string( newChars );
			response = new Response( NLGSource.Chatterbot, reply, this.semanticAnalyzer.GetLocalWeightedVector( reply ), this.semanticAnalyzer.CompareTwoStringsWithLocalWeighting( reply, input) );
			response.AdjustBasisMeasures( this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( response.vector, basis ) );
			basis.RemoveAt( 1 );
			responseList.Add( response );

			Console.WriteLine( "Chatterbot> Cosine:{0}\tRel:{1}\tInfo:{2}\t{3}", response.cosine, response.relevance, response.informativity, response.text );
			Console.WriteLine();

			//The average turn to turn relevance is .10, the matching average new information is .98
			foreach( Response r in responseList )
			{
				float distance = (float) (Math.Abs( r.relevance - .20 ) + Math.Abs( r.informativity- .95 ) );
				r.cosine  -= distance;
				r.distance = distance;
				Console.WriteLine( "Cosine {0} \tDistance {1} \tAdjusted Cosine {2}", r.cosine + distance, distance, r.cosine );
			}

			responseList.Sort();
			
			//Voting criterion: use the sorted cosines, adjusted by the cohesion distance UNLESS the input
			//vector length is small, in which case the chatterbot is most appropriate
			if( inputVectorLength > .03 )
				reply = (( Response )responseList[ responseList.Count - 1 ]).text;

			//Get probability that the last word of the turn is the last word of a turn. If below threshold, we 
			//concatenate turns.
			string[] theSplit = reply.Split( ' ' );
			float probability = bigrams.GetProbablity( theSplit[ theSplit.Length - 1 ], "</t>" );
			Console.WriteLine( "Response end of turn probability {0}", probability );
			//If probability is less than .005, do another query, and append

			Console.WriteLine( "Response length:{0}", this.semanticAnalyzer.lsaCalculator.Length( this.semanticAnalyzer.GetLocalWeightedVector( reply ) ) );
			Console.WriteLine( "RESPONSE --> " + reply );
			Console.WriteLine( "_________________________________________________________________" );
		}
		
 * public void GenerateOrg( string input )
		{
			//Store and sort, returning the highest as the response
			string[] responses = new string[ 5 ];
			float[] cosines = new float[ 5 ];
			float[] informativity = new float[ 5 ];
			float[] measures = new float[ 2 ];

			//Create a basis for calculating cohesion metrics
			System.Collections.ArrayList basis = new System.Collections.ArrayList();
			float[] inputVector = this.semanticAnalyzer.GetVector( input );
			this.semanticAnalyzer.DecomposeReturnInformativity( inputVector, basis );

			//Paragraph level
			Console.WriteLine( "_________________________________________________________________" );
			LSAModule.Document document = new LSAModule.Document( 0, input, this.semanticAnalyzer.GetVector( input ) );
			System.Collections.ArrayList paragraphList = this.semanticAnalyzer.GetTopNMatchingTurns( document, currentDialogueList, 5 );
			for( int i = 0; i < paragraphList.Count; i ++ )
			{
				Turn turn = ( Turn ) paragraphList[ i ];

				//Storage for sorting
				responses[ i ] = turn.document.text;
				measures = this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( turn.document.vector, basis );
				cosines[ i ] = measures[ 0 ];
				informativity[ i ] = measures[ 1 ];
				basis.RemoveAt( 1 );

				Console.WriteLine( "Paragraph> {0} Cosine:{1} Info:{2} {3}", i, turn.document.sortingValue, informativity[ i ], turn.document.text );	
			}
			Console.WriteLine();

			//Sentence level
			LSAModule.DocumentCollection documentCollection = ( LSAModule.DocumentCollection )this.semanticAnalyzer.SummarizeTurnsToSentences( paragraphList, 3 );
			documentCollection.vector = this.semanticAnalyzer.GetVector( documentCollection.text );
			
			//Storage for sorting
			responses[ 3 ] = documentCollection.text;
			measures = this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( documentCollection.vector, basis );
			cosines[ 3 ] = measures[ 0 ];
			informativity[ 3 ] = measures[ 1 ];
			basis.RemoveAt( 1 );

			Console.WriteLine( "Sentence> Cosine:{0} Info:{1} {2}", cosines[ 3 ], informativity[ 3 ], documentCollection.text );
			Console.WriteLine();

			//Chatterbot
			char[] theChars = this.chatBot.Send( "me", input ).ToCharArray();
			char[] newChars = new char[ theChars.Length ];
			char c;
			for( int i = 0; i < theChars.Length; i++ )
			{
				c = theChars[ i ];
				if( char.IsLetter( c ) || c.Equals( ' ' ) )
					newChars[ i ] = c;
				else
					newChars[ i ] = ' ';
			}
			string reply = new string( newChars );
			
			//Storage for sorting
			responses[ 4 ] = reply;
			measures = this.semanticAnalyzer.DecomposeReturnRelevanceAndInformativity( this.semanticAnalyzer.GetVector( reply ), basis );
			cosines[ 4 ] = measures[ 0 ];
			informativity[ 4 ] = measures[ 1 ];
			basis.RemoveAt( 1 );

			Console.WriteLine( "Chatterbot> Cosine:{0} Info:{1} {2}", cosines[ 4 ], informativity[ 4 ], reply );
			Console.WriteLine();

			//The average turn to turn relevance is .10, the matching average new information is .98
			double[] distances = new double[ 5 ];
			for( int i = 0; i < 5; i++ )
			{
				distances[ i ] = Math.Abs( cosines[ i ] - .20 ) + Math.Abs( informativity[ i ] - .95 );
				Console.WriteLine( "Distance {0} {1}", i, distances[ i ] );
				//NEW penalize by distance
				cosines[ i ] -= ( float )distances[ i ];
			}

			//Penalize the chatterbot and reward the sentence summarizer
			//distances[ 4 ] += .04;
			//distances[ 3 ] -= .2;

			//Sort the responses by distance from this mean so that the closest response is response 0
			//Array.Sort( distances, responses );
			Array.Sort( cosines, responses );
			
			Console.WriteLine( "RESPONSE --> " + responses[ 4 ] );
			Console.WriteLine( "_________________________________________________________________" );
		}
		*/
			
			/*
			//Vote for the response: highest cosine is response
			//Array.Sort( cosines, responses );

			//Do a rank ordering on cosine and informativity, equally weighted
			int[] cosineIndexes = new int[ 5 ];
			int[] infoIndexes = new int[ 5 ];
			//Initialize with indexes corresponding to position
			for( int i = 0; i < 5; i++ )
			{
				cosineIndexes[ i ] = i;
				infoIndexes[ i ] = i;
			}
			//Sort the keys
			Array.Sort( cosines, cosineIndexes );
			Array.Sort( informativity, infoIndexes );

			//Compute rank ordering
			int[] score = new int[ 5 ];
			for( int i = 0; i < 5; i++ )
			{
				score[ cosineIndexes[ i ] ] += i;
				score[ infoIndexes[ i ] ] += i;
			}
			Array.Sort( score, responses );
			*/
#endregion
