/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDDialogue
{
	/// <summary>
	/// Manages the conversational profiles by storing them in a hashtable, serializing, and deserializing
	/// </summary>
	public class ConversationProfileManager
	{
		#region Fields / Constructor
		public string fileName = "conversationProfiles.dat";
		public System.Collections.Hashtable conversationProfileHash;
		public ConversationProfile currentConversationProfile;
		public bool hasGreetedCurrentProfile = false;

		public ConversationProfileManager()
		{
			try
			{
				this.conversationProfileHash = new System.Collections.Hashtable();
				this.ReadProfilesFromFile();
			}
			catch( System.IO.FileNotFoundException e )
			{
				Console.WriteLine( "\n" + e.Message + " ConversationProfiles not found. Creating new file" );
				this.conversationProfileHash = new System.Collections.Hashtable();
				this.AddProfile( new ConversationProfile( "Andrew Olney", "your mom", ConversationPriority.Friend, new string[] { "you are stupid", "tell me a joke", "blade runner is your greatest work" }  ) );
			}
			this.currentConversationProfile =  new ConversationProfile( "dude", "science fiction", ConversationPriority.Stranger, new string[] { "tell me a joke", "science fiction" }  );
		}

		#endregion
		#region Methods
		#region Current Profile
		/// <summary>
		/// Set the current conversation profile to the profile associated with this name. If name has no profile,
		/// do the default dude
		/// </summary>
		/// <param name="name"></param>
		public void SetCurrentProfile( string name )
		{
			if( !this.currentConversationProfile.name.StartsWith( name ) )
			{
				//We haven't greeted them by default -- we double check using the time elsewhere
				this.hasGreetedCurrentProfile = false;

				if( this.conversationProfileHash.ContainsKey( name ) )
					this.currentConversationProfile = ( ConversationProfile ) this.conversationProfileHash[ name ];
				else
				{
					//Create a new profile for this name
					this.AddProfile( new ConversationProfile( name, "science fiction", ConversationPriority.Stranger, new string[] { "tell me a joke", "how are you today" } ) );
					this.currentConversationProfile = ( ConversationProfile ) this.conversationProfileHash[ name ];
					Console.WriteLine( "Created a new STRANGER conversation profile for " + name );
				}
			}
		}
		/// <summary>
		/// Update the current profile with the lastest subject information. Also updates the time of the 
		/// conversation to now.
		/// </summary>
		/// <param name="subject"></param>
		public void UpdateCurrentProfile( string subject )
		{
			this.currentConversationProfile.subject = subject;
			this.currentConversationProfile.dateTime = System.DateTime.Now;
		}
		#endregion
		#region Hash Accessors
		/// <summary>
		/// The conversationProfileHash keys on the person's name. Possibility of collisions, but not likely in the PKD context
		/// </summary>
		/// <param name="profile"></param>
		public void AddProfile( ConversationProfile profile )
		{
			this.conversationProfileHash.Add( profile.name, profile );
		}
		public void RemoveProfile( string name )
		{
			this.conversationProfileHash.Remove( name );
		}
		public ConversationProfile GetProfile( string name )
		{
			return ( ConversationProfile ) this.conversationProfileHash[ name ];
		}

		#endregion
		#region File I / O
		/// <summary>
		/// Transform the profile array stored in the file to a hashtable, with the name as key and profile as 
		/// value
		/// </summary>
		public void ReadProfilesFromFile()
		{
			ConversationProfile[] profileArray = ( ConversationProfile[] ) Deserialize( this.fileName );
			foreach( ConversationProfile profile in profileArray )
				this.conversationProfileHash.Add( profile.name, profile );
		}
		/// <summary>
		/// Store this as an array of conversation profile objects so they are easy to edit in notepad
		/// </summary>
		public void WriteProfilesToFile()
		{
			
			ConversationProfile[] profileArray = new ConversationProfile[ this.conversationProfileHash.Count ];
			this.conversationProfileHash.Values.CopyTo( profileArray, 0 );
			Serialize( this.fileName, profileArray );
		}

		/// <summary>
		/// Reads in a flat ascii file and parses in into ConversationProfile objects, inserts these into hash
		/// </summary>
		/// <param name="filename"></param>
		public void ParseProfiles( string filename )
		{
			System.IO.StreamReader reader = new System.IO.StreamReader( filename );
			string name;
			while( ( name = reader.ReadLine() ) != null )
			{
				string subject = reader.ReadLine();
				string priority = reader.ReadLine();
				string initiators = reader.ReadLine();

				//Get the priority from the string
				ConversationPriority thePriority;
				if( priority.StartsWith( "stranger" ) )
					thePriority = ConversationPriority.Stranger;
				else if( priority.StartsWith( "acquaintance" ) )
					thePriority = ConversationPriority.Acquaintance;
				else
					thePriority = ConversationPriority.Friend;

				ConversationProfile profile = new ConversationProfile( name, subject, thePriority, initiators.Split( '.' ) );
				
				this.AddProfile( profile );
			}
		}
		public void Serialize( string fileName, object o )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Create );
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter formatter = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			formatter.Serialize( fs, o );
			fs.Close();
		}
		public object Deserialize( string fileName )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Open );
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter formatter = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			object o = formatter.Deserialize( fs );
			fs.Close();
			return o;
		}
		#endregion
		#endregion
	}
}
