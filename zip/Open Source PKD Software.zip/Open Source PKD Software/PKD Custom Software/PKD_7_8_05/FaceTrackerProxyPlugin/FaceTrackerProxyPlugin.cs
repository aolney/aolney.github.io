/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	public class FaceTrackerPlugin : PKDPlugin.AbstractJessPlugin
	{
		#region Fields / Constructor
		//for tracking multiple faces and representing that in jess. we max out at 10 heads
		public int[] headSize = new int[ 10 ];
		public int[] headX = new int[ 10 ];
		public int[] headY = new int[ 10 ];
		public int[] headId = new int[ 10 ];
		public int[] tempheadSize = new int[ 10 ];
		public int[] tempheadX = new int[ 10 ];
		public int[] tempheadY = new int[ 10 ];
		public int[] tempheadId = new int[ 10 ];

		public int numberHeadsTracked = 0;
		public int centerFace;
		public int centerFaceX;
		public int centerFaceY;
		public int centerFaceHeadSize;
		public FaceTrackerProxyHelper faceTrackerProxyHelper;
		
		public FaceTrackerPlugin() : base()
		{ 
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
			
			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			System.IO.StreamReader reader = new System.IO.StreamReader( "FaceTrackerProxyServerConnectionString.txt" );
			string uri = reader.ReadLine();
			reader.Close();
			this.faceTrackerProxyHelper = ( PKDPlugin.FaceTrackerProxyHelper )Activator.GetObject( typeof( PKDPlugin.FaceTrackerProxyHelper ), uri );	
			
			//We lauch a thread to poll the proxy object for changes. We can't use delegates and events b/c 
			//of the lack of serialization attributes in the ikvm classpath (property change listeners)
			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}

		#endregion
		#region Methods
		public void Run()
		{
			while( true )
			{
				#region Update Shadow Fact
				this.tempheadId[ 0 ] = this.faceTrackerProxyHelper.headId0;
				this.tempheadId[ 1 ] = this.faceTrackerProxyHelper.headId1;
				this.tempheadId[ 2 ] = this.faceTrackerProxyHelper.headId2;
				this.tempheadId[ 3 ] = this.faceTrackerProxyHelper.headId3;
				this.tempheadId[ 4 ] = this.faceTrackerProxyHelper.headId4;
				this.tempheadId[ 5 ] = this.faceTrackerProxyHelper.headId5;
				this.tempheadId[ 6 ] = this.faceTrackerProxyHelper.headId6;
				this.tempheadId[ 7 ] = this.faceTrackerProxyHelper.headId7;
				this.tempheadId[ 8 ] = this.faceTrackerProxyHelper.headId8;
				this.tempheadId[ 9 ] = this.faceTrackerProxyHelper.headId9;

				this.tempheadSize[ 0 ] = this.faceTrackerProxyHelper.headSize0;
				this.tempheadSize[ 1 ] = this.faceTrackerProxyHelper.headSize1;
				this.tempheadSize[ 2 ] = this.faceTrackerProxyHelper.headSize2;
				this.tempheadSize[ 3 ] = this.faceTrackerProxyHelper.headSize3;
				this.tempheadSize[ 4 ] = this.faceTrackerProxyHelper.headSize4;
				this.tempheadSize[ 5 ] = this.faceTrackerProxyHelper.headSize5;
				this.tempheadSize[ 6 ] = this.faceTrackerProxyHelper.headSize6;
				this.tempheadSize[ 7 ] = this.faceTrackerProxyHelper.headSize7;
				this.tempheadSize[ 8 ] = this.faceTrackerProxyHelper.headSize8;
				this.tempheadSize[ 9 ] = this.faceTrackerProxyHelper.headSize9;

				this.tempheadX[ 0 ] = this.faceTrackerProxyHelper.headX0;
				this.tempheadX[ 1 ] = this.faceTrackerProxyHelper.headX1;
				this.tempheadX[ 2 ] = this.faceTrackerProxyHelper.headX2;
				this.tempheadX[ 3 ] = this.faceTrackerProxyHelper.headX3;
				this.tempheadX[ 4 ] = this.faceTrackerProxyHelper.headX4;
				this.tempheadX[ 5 ] = this.faceTrackerProxyHelper.headX5;
				this.tempheadX[ 6 ] = this.faceTrackerProxyHelper.headX6;
				this.tempheadX[ 7 ] = this.faceTrackerProxyHelper.headX7;
				this.tempheadX[ 8 ] = this.faceTrackerProxyHelper.headX8;
				this.tempheadX[ 9 ] = this.faceTrackerProxyHelper.headX9;

				this.tempheadY[ 0 ] = this.faceTrackerProxyHelper.headY0;
				this.tempheadY[ 1 ] = this.faceTrackerProxyHelper.headY1;
				this.tempheadY[ 2 ] = this.faceTrackerProxyHelper.headY2;
				this.tempheadY[ 3 ] = this.faceTrackerProxyHelper.headY3;
				this.tempheadY[ 4 ] = this.faceTrackerProxyHelper.headY4;
				this.tempheadY[ 5 ] = this.faceTrackerProxyHelper.headY5;
				this.tempheadY[ 6 ] = this.faceTrackerProxyHelper.headY6;
				this.tempheadY[ 7 ] = this.faceTrackerProxyHelper.headY7;
				this.tempheadY[ 8 ] = this.faceTrackerProxyHelper.headY8;
				this.tempheadY[ 9 ] = this.faceTrackerProxyHelper.headY9;

				
				propertyChangeSupport.firePropertyChange("headsize", this.headSize, this.tempheadSize );
				propertyChangeSupport.firePropertyChange("headx", this.headX, this.tempheadX );
				propertyChangeSupport.firePropertyChange("heady", this.headY, this.tempheadY);
				propertyChangeSupport.firePropertyChange("headid", this.headId, this.tempheadId );
				propertyChangeSupport.firePropertyChange("numberheadstracked", this.numberHeadsTracked, this.faceTrackerProxyHelper.numberHeadsTracked );
				propertyChangeSupport.firePropertyChange("centerface", this.centerFace, this.faceTrackerProxyHelper.centerFace );
				this.propertyChangeSupport.firePropertyChange( "centerfacex", this.centerFaceX, this.faceTrackerProxyHelper.centerFaceX );
				this.propertyChangeSupport.firePropertyChange( "centerfacey", this.centerFaceY, this.faceTrackerProxyHelper.centerFaceY );
				this.propertyChangeSupport.firePropertyChange( "centerfaceheadsize", this.centerFaceHeadSize, this.faceTrackerProxyHelper.centerFaceHeadSize );
			
				//copy new values to old values
				this.numberHeadsTracked = this.faceTrackerProxyHelper.numberHeadsTracked;
				this.centerFace = this.faceTrackerProxyHelper.centerFace;
				this.centerFaceX = this.faceTrackerProxyHelper.centerFaceX;
				this.centerFaceY = this.faceTrackerProxyHelper.centerFaceY;
				this.centerFaceHeadSize = this.faceTrackerProxyHelper.centerFaceHeadSize;

				this.headId[ 0 ] = this.faceTrackerProxyHelper.headId0;
				this.headId[ 1 ] = this.faceTrackerProxyHelper.headId1;
				this.headId[ 2 ] = this.faceTrackerProxyHelper.headId2;
				this.headId[ 3 ] = this.faceTrackerProxyHelper.headId3;
				this.headId[ 4 ] = this.faceTrackerProxyHelper.headId4;
				this.headId[ 5 ] = this.faceTrackerProxyHelper.headId5;
				this.headId[ 6 ] = this.faceTrackerProxyHelper.headId6;
				this.headId[ 7 ] = this.faceTrackerProxyHelper.headId7;
				this.headId[ 8 ] = this.faceTrackerProxyHelper.headId8;
				this.headId[ 9 ] = this.faceTrackerProxyHelper.headId9;


				this.headSize[ 0 ] = this.faceTrackerProxyHelper.headSize0;
				this.headSize[ 1 ] = this.faceTrackerProxyHelper.headSize1;
				this.headSize[ 2 ] = this.faceTrackerProxyHelper.headSize2;
				this.headSize[ 3 ] = this.faceTrackerProxyHelper.headSize3;
				this.headSize[ 4 ] = this.faceTrackerProxyHelper.headSize4;
				this.headSize[ 5 ] = this.faceTrackerProxyHelper.headSize5;
				this.headSize[ 6 ] = this.faceTrackerProxyHelper.headSize6;
				this.headSize[ 7 ] = this.faceTrackerProxyHelper.headSize7;
				this.headSize[ 8 ] = this.faceTrackerProxyHelper.headSize8;
				this.headSize[ 9 ] = this.faceTrackerProxyHelper.headSize9;

				this.headX[ 0 ] = this.faceTrackerProxyHelper.headX0;
				this.headX[ 1 ] = this.faceTrackerProxyHelper.headX1;
				this.headX[ 2 ] = this.faceTrackerProxyHelper.headX2;
				this.headX[ 3 ] = this.faceTrackerProxyHelper.headX3;
				this.headX[ 4 ] = this.faceTrackerProxyHelper.headX4;
				this.headX[ 5 ] = this.faceTrackerProxyHelper.headX5;
				this.headX[ 6 ] = this.faceTrackerProxyHelper.headX6;
				this.headX[ 7 ] = this.faceTrackerProxyHelper.headX7;
				this.headX[ 8 ] = this.faceTrackerProxyHelper.headX8;
				this.headX[ 9 ] = this.faceTrackerProxyHelper.headX9;

				this.headY[ 0 ] = this.faceTrackerProxyHelper.headY0;
				this.headY[ 1 ] = this.faceTrackerProxyHelper.headY1;
				this.headY[ 2 ] = this.faceTrackerProxyHelper.headY2;
				this.headY[ 3 ] = this.faceTrackerProxyHelper.headY3;
				this.headY[ 4 ] = this.faceTrackerProxyHelper.headY4;
				this.headY[ 5 ] = this.faceTrackerProxyHelper.headY5;
				this.headY[ 6 ] = this.faceTrackerProxyHelper.headY6;
				this.headY[ 7 ] = this.faceTrackerProxyHelper.headY7;
				this.headY[ 8 ] = this.faceTrackerProxyHelper.headY8;
				this.headY[ 9 ] = this.faceTrackerProxyHelper.headY9;

				System.Threading.Thread.Sleep( 50 );
				#endregion
			}
		}
		#endregion	
		#region ShadowFact Accessors
		//The capitalization on these is critical for the java introspector
		public int[] getHeadsize()
		{
			return this.headSize;
		}
		public int[] getHeadx()
		{
			return this.headX;
		}
		public int[] getHeady()
		{
			return this.headY;
		}
		public int[] getHeadid()
		{
			return this.headId;
		}
		public int getNumberheadstracked()
		{
			return this.numberHeadsTracked;
		}
		public int getCenterface()
		{
			return this.centerFace;
		}
		public int getCenterfacex()
		{
			return this.centerFaceX;
		}
		public int getCenterfacey()
		{
			return this.centerFaceY;
		}
		public int getCenterfaceheadsize()
		{
			return this.centerFaceHeadSize;
		}
		#endregion
	}
}
