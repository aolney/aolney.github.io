using System;

namespace PKDPlugin
{
	/// <summary>
	/// We need a helper class b/c jess cannot make a remoted object a shadow fact
	/// </summary>
	[Serializable]
	public class WirelessKeypadProxyHelper : System.MarshalByRefObject
	{		
		public char key;

		public WirelessKeypadProxyHelper()
		{
		}
	}
}
