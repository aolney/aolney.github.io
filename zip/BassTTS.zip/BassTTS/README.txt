Copyright (c) <2004> <Andrew Olney>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

CONCEPT:

The source code and executable synchronize text to speech via SAPI 5.1 to input voltages on the parallel 
port output lines.

This has been used to make a Billy Bass animatronic fish talk via TTS.  For more information on how to connect 
a Billy Bass to your parallel port, visit http://bigmouth.here-n-there.com/

I actually ripped all of the circuitry out except for the motors, and am driving the motors via a 
parallel port relay board. However, if you follow the bigmouth.here-n-there directions, you 
should be able to do this without a relay board, since the voltages involved are TTL.

Because of the peculiarities of my set up, you may want to change the address of the parallel port and the 
output bytes.

REQUIREMENTS:

To run the executable, you will need the .NET Framework Version 1.1 Redistributable Package 
available at
http://www.microsoft.com/downloads/details.aspx?FamilyId=262D25E3-F589-4842-8157-034D1E7CF3A3&displaylang=en

as well as a SAPI 5.1 voice and engine (often preinstalled in XP) available at 
http://www.microsoft.com/speech/download/sdk51/

To recompile the code, you will need the  .NET Framework SDK Version 1.1, which 
is available at 
http://www.microsoft.com/downloads/details.aspx?FamilyId=9B3A2CA6-3647-4070-9F41-A333C6B9181D&displaylang=en

LICENSE:

This code is provided AS-IS, for no particular purpose, and no warranty is expressed or implied.

You can destroy your motherboard by improperly hooking up electronics to your parallel port.

Use it at your own risk.


Andrew Olney
aolney@memphis.edu
