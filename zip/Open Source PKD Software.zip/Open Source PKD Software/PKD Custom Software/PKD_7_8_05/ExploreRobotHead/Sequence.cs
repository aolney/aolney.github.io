/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace ExploreRobotHead
{
	/// <summary>
	/// A sequence holds speakable text and acts like a wrapper to keep track of 
	/// what words have been spoken so that an animation can be triggered at the 
	/// right time. We need it b/c babel doesn't appear to support bookmarks.
	/// </summary>
	public class Sequence
	{
		public int wordIndex;
		public int animationIndex;
		public System.Collections.ArrayList sequence;
		public string text;
		public Sequence( string speakable )
		{
			string[] theSplit = speakable.Replace( "  ", " " ).Split( ' ' );
			System.Text.StringBuilder stringBuilder = new System.Text.StringBuilder();

			sequence = new System.Collections.ArrayList();

			//The character position that the animation should start on
			int characterPosition = 0;
			int lastCharacterPosition = 0;

			for( int i = 0; i < theSplit.Length; i++ )
			{
				//An animation starts with an animation tag
				if( theSplit[ i ].StartsWith( @"\!bm" ) )
				{
					theSplit[ i ] = theSplit[ i ].Replace( @"\!bm", "" );
					this.sequence.Add( new SequenceElement( lastCharacterPosition, theSplit[ i ] ) );
				}
				else
				{
					lastCharacterPosition = characterPosition; //so animation is played on word, not after word
					characterPosition += theSplit[ i ].Length + 1; //+1 for the whitespace
					stringBuilder.Append( theSplit[ i ] + " " );
				}
			}
			this.text = stringBuilder.ToString();
		}
	}

	public class SequenceElement
	{
		public int index;
		public string animationName;

		public SequenceElement( int index, string animationName )
		{
			this.index = index;
			this.animationName = animationName;
		}
	}
}
