<%@ Application Codebehind="Global.asax.cs" Inherits="AIMLtalk.Global" %>
