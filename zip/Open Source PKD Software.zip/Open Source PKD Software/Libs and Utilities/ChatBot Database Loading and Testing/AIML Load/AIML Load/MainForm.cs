/*
 * Created by SharpDevelop.
 * User: Gary Dubuque
 * Date: 4/16/2005
 * Time: 8:28 PM
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
using System;
using System.Drawing;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using System.Collections;
using System.Collections.Specialized;
using System.IO;
using System.Xml;

namespace AIML_Load
{
	/// <summary>
	/// Description of MainForm.
	/// </summary>
	public class MainForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RadioButton radList;
		private System.Windows.Forms.StatusBar statusBar1;
		private System.Windows.Forms.TextBox txtPassword;
		private System.Windows.Forms.TextBox txtServer;
		private System.Windows.Forms.Button btnMake;
		private System.Windows.Forms.Button btnBrowse;
		private System.Windows.Forms.RadioButton radAIML;
		private System.Windows.Forms.TextBox txtDB;
		private System.Windows.Forms.CheckBox chkClear;
		private System.Windows.Forms.Button btnNewDB;
		private System.Windows.Forms.Button btnSave;
		private System.Windows.Forms.Label lblAccount;
		private System.Windows.Forms.Button btnStats;
		private System.Windows.Forms.Button btnCreate;
		private System.Windows.Forms.Label lblPassword;
		private System.Windows.Forms.CheckBox chkWinTrust;
		private System.Windows.Forms.TextBox txtFileName;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.TextBox txtAccount;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtTemplate;
		private System.Windows.Forms.TextBox txtPattern;

		protected SqlConnection cnx;
		protected int IfToken = 0;
		protected string strServer = "(local)";
		protected string strDB = "AIML";

		public MainForm()
		{
			//
			// The InitializeComponent() call is required for Windows Forms designer support.
			//
			InitializeComponent();
			
			txtFileName.Text = Application.StartupPath.ToString() + "\\AIML.AIML";
		}
		
		[STAThread]
		public static void Main(string[] args)
		{
			Application.Run(new MainForm());
		}
		
		#region Windows Forms Designer generated code
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent() {
			this.txtPattern = new System.Windows.Forms.TextBox();
			this.txtTemplate = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtAccount = new System.Windows.Forms.TextBox();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtFileName = new System.Windows.Forms.TextBox();
			this.chkWinTrust = new System.Windows.Forms.CheckBox();
			this.lblPassword = new System.Windows.Forms.Label();
			this.btnCreate = new System.Windows.Forms.Button();
			this.btnStats = new System.Windows.Forms.Button();
			this.lblAccount = new System.Windows.Forms.Label();
			this.btnSave = new System.Windows.Forms.Button();
			this.btnNewDB = new System.Windows.Forms.Button();
			this.chkClear = new System.Windows.Forms.CheckBox();
			this.txtDB = new System.Windows.Forms.TextBox();
			this.radAIML = new System.Windows.Forms.RadioButton();
			this.btnBrowse = new System.Windows.Forms.Button();
			this.btnMake = new System.Windows.Forms.Button();
			this.txtServer = new System.Windows.Forms.TextBox();
			this.txtPassword = new System.Windows.Forms.TextBox();
			this.statusBar1 = new System.Windows.Forms.StatusBar();
			this.radList = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// txtPattern
			// 
			this.txtPattern.Location = new System.Drawing.Point(16, 224);
			this.txtPattern.Name = "txtPattern";
			this.txtPattern.Size = new System.Drawing.Size(552, 21);
			this.txtPattern.TabIndex = 7;
			this.txtPattern.Text = "";
			// 
			// txtTemplate
			// 
			this.txtTemplate.Location = new System.Drawing.Point(16, 264);
			this.txtTemplate.Multiline = true;
			this.txtTemplate.Name = "txtTemplate";
			this.txtTemplate.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.txtTemplate.Size = new System.Drawing.Size(552, 136);
			this.txtTemplate.TabIndex = 8;
			this.txtTemplate.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(312, 56);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 16);
			this.label4.TabIndex = 22;
			this.label4.Text = "Database:";
			// 
			// txtAccount
			// 
			this.txtAccount.Enabled = false;
			this.txtAccount.Location = new System.Drawing.Point(224, 88);
			this.txtAccount.Name = "txtAccount";
			this.txtAccount.Size = new System.Drawing.Size(344, 21);
			this.txtAccount.TabIndex = 15;
			this.txtAccount.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 208);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(360, 16);
			this.label1.TabIndex = 9;
			this.label1.Text = "Pattern:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(24, 248);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(120, 16);
			this.label2.TabIndex = 10;
			this.label2.Text = "Template (or Results):";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 56);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 16);
			this.label3.TabIndex = 20;
			this.label3.Text = "SQL Server:";
			// 
			// txtFileName
			// 
			this.txtFileName.Location = new System.Drawing.Point(16, 176);
			this.txtFileName.Name = "txtFileName";
			this.txtFileName.Size = new System.Drawing.Size(552, 21);
			this.txtFileName.TabIndex = 6;
			this.txtFileName.Text = "";
			// 
			// chkWinTrust
			// 
			this.chkWinTrust.Checked = true;
			this.chkWinTrust.CheckState = System.Windows.Forms.CheckState.Checked;
			this.chkWinTrust.Location = new System.Drawing.Point(32, 80);
			this.chkWinTrust.Name = "chkWinTrust";
			this.chkWinTrust.Size = new System.Drawing.Size(96, 56);
			this.chkWinTrust.TabIndex = 14;
			this.chkWinTrust.Text = "Use Windows Authenication";
			this.chkWinTrust.CheckedChanged += new System.EventHandler(this.ChkWinTrustCheckedChanged);
			// 
			// lblPassword
			// 
			this.lblPassword.Enabled = false;
			this.lblPassword.Location = new System.Drawing.Point(136, 112);
			this.lblPassword.Name = "lblPassword";
			this.lblPassword.Size = new System.Drawing.Size(72, 16);
			this.lblPassword.TabIndex = 18;
			this.lblPassword.Text = "Password:";
			this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnCreate
			// 
			this.btnCreate.Location = new System.Drawing.Point(96, 16);
			this.btnCreate.Name = "btnCreate";
			this.btnCreate.Size = new System.Drawing.Size(88, 24);
			this.btnCreate.TabIndex = 11;
			this.btnCreate.Text = "Install Tables";
			this.btnCreate.Click += new System.EventHandler(this.BtnCreateClick);
			// 
			// btnStats
			// 
			this.btnStats.Location = new System.Drawing.Point(272, 16);
			this.btnStats.Name = "btnStats";
			this.btnStats.Size = new System.Drawing.Size(48, 24);
			this.btnStats.TabIndex = 0;
			this.btnStats.Text = "Stats";
			this.btnStats.Click += new System.EventHandler(this.BtnStatsClick);
			// 
			// lblAccount
			// 
			this.lblAccount.Enabled = false;
			this.lblAccount.Location = new System.Drawing.Point(136, 88);
			this.lblAccount.Name = "lblAccount";
			this.lblAccount.Size = new System.Drawing.Size(72, 16);
			this.lblAccount.TabIndex = 16;
			this.lblAccount.Text = "DB Account:";
			this.lblAccount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// btnSave
			// 
			this.btnSave.Location = new System.Drawing.Point(336, 16);
			this.btnSave.Name = "btnSave";
			this.btnSave.Size = new System.Drawing.Size(56, 24);
			this.btnSave.TabIndex = 1;
			this.btnSave.Text = "Learn";
			this.btnSave.Click += new System.EventHandler(this.BtnSaveClick);
			// 
			// btnNewDB
			// 
			this.btnNewDB.Location = new System.Drawing.Point(192, 16);
			this.btnNewDB.Name = "btnNewDB";
			this.btnNewDB.Size = new System.Drawing.Size(64, 24);
			this.btnNewDB.TabIndex = 3;
			this.btnNewDB.Text = "Clear DB";
			this.btnNewDB.Click += new System.EventHandler(this.BtnNewDBClick);
			// 
			// chkClear
			// 
			this.chkClear.Location = new System.Drawing.Point(400, 16);
			this.chkClear.Name = "chkClear";
			this.chkClear.Size = new System.Drawing.Size(176, 24);
			this.chkClear.TabIndex = 2;
			this.chkClear.Text = "Clear existing AIML in DB first";
			// 
			// txtDB
			// 
			this.txtDB.Location = new System.Drawing.Point(376, 56);
			this.txtDB.Name = "txtDB";
			this.txtDB.Size = new System.Drawing.Size(192, 21);
			this.txtDB.TabIndex = 23;
			this.txtDB.Text = "AIML";
			// 
			// radAIML
			// 
			this.radAIML.Checked = true;
			this.radAIML.Location = new System.Drawing.Point(16, 152);
			this.radAIML.Name = "radAIML";
			this.radAIML.Size = new System.Drawing.Size(144, 24);
			this.radAIML.TabIndex = 4;
			this.radAIML.TabStop = true;
			this.radAIML.Text = "Enter AIML File Name:";
			// 
			// btnBrowse
			// 
			this.btnBrowse.Location = new System.Drawing.Point(464, 152);
			this.btnBrowse.Name = "btnBrowse";
			this.btnBrowse.Size = new System.Drawing.Size(104, 23);
			this.btnBrowse.TabIndex = 13;
			this.btnBrowse.Text = "Browse for File";
			this.btnBrowse.Click += new System.EventHandler(this.BtnBrowseClick);
			// 
			// btnMake
			// 
			this.btnMake.Location = new System.Drawing.Point(16, 16);
			this.btnMake.Name = "btnMake";
			this.btnMake.Size = new System.Drawing.Size(72, 24);
			this.btnMake.TabIndex = 24;
			this.btnMake.Text = "Create DB";
			this.btnMake.Click += new System.EventHandler(this.BtnMakeClick);
			// 
			// txtServer
			// 
			this.txtServer.Location = new System.Drawing.Point(96, 56);
			this.txtServer.Name = "txtServer";
			this.txtServer.Size = new System.Drawing.Size(200, 21);
			this.txtServer.TabIndex = 21;
			this.txtServer.Text = "(local)";
			// 
			// txtPassword
			// 
			this.txtPassword.Enabled = false;
			this.txtPassword.Location = new System.Drawing.Point(224, 112);
			this.txtPassword.Name = "txtPassword";
			this.txtPassword.Size = new System.Drawing.Size(344, 21);
			this.txtPassword.TabIndex = 17;
			this.txtPassword.Text = "";
			// 
			// statusBar1
			// 
			this.statusBar1.Location = new System.Drawing.Point(0, 408);
			this.statusBar1.Name = "statusBar1";
			this.statusBar1.Size = new System.Drawing.Size(584, 22);
			this.statusBar1.TabIndex = 19;
			// 
			// radList
			// 
			this.radList.Location = new System.Drawing.Point(160, 152);
			this.radList.Name = "radList";
			this.radList.Size = new System.Drawing.Size(240, 24);
			this.radList.TabIndex = 5;
			this.radList.Text = "Enter List (of AIML files) File Name:";
			// 
			// MainForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 14);
			this.ClientSize = new System.Drawing.Size(584, 430);
			this.Controls.Add(this.btnMake);
			this.Controls.Add(this.txtDB);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtServer);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.statusBar1);
			this.Controls.Add(this.lblPassword);
			this.Controls.Add(this.txtPassword);
			this.Controls.Add(this.lblAccount);
			this.Controls.Add(this.txtAccount);
			this.Controls.Add(this.chkWinTrust);
			this.Controls.Add(this.btnBrowse);
			this.Controls.Add(this.btnCreate);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtTemplate);
			this.Controls.Add(this.txtPattern);
			this.Controls.Add(this.txtFileName);
			this.Controls.Add(this.btnStats);
			this.Controls.Add(this.radList);
			this.Controls.Add(this.radAIML);
			this.Controls.Add(this.chkClear);
			this.Controls.Add(this.btnSave);
			this.Controls.Add(this.btnNewDB);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "MainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "AIML DB Build";
			this.ResumeLayout(false);
		}
		#endregion
    
		void GetConnection()
		{
			strServer = txtServer.Text;
			strDB = txtDB.Text;
			
			if (chkWinTrust.Checked)
			{
				cnx = new SqlConnection("Server=" + strServer + ";Trusted_Connection=true;database=" + strDB + ";");
			}
			else
			{
				cnx = new SqlConnection("Server=" + strServer + ";UID=" + txtAccount.Text + ";PWD=" + txtPassword.Text + ";database=" + strDB + ";");
			}
			cnx.Open();
		}
		
		void BtnStatsClick(object sender, System.EventArgs e)
		{
			GetConnection();
			
			txtPattern.Text = "";
			txtTemplate.Text = "Context Types: " + GetContextStats() + "  Pattern Words: " + GetPatternStats() + "  Templates: " + GetTemplateStats() + "  Predicates: " + GetPredicateStats();
			
			cnx.Close();			
		}
    
		string GetContextStats()
		{
			long cnt = 0;
			SqlCommand cmd = new SqlCommand("CountContext", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) cnt = (Int32) rdr[0];
				rdr.Close();
			}
    
			return cnt.ToString();
		}
     
		string GetPatternStats()
		{
			long cnt = 0;
			SqlCommand cmd = new SqlCommand("CountPattern", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) cnt = (Int32) rdr[0];
				rdr.Close();
			}
    
			return cnt.ToString();
		}
				   
		string GetTemplateStats()
		{
			long cnt = 0;
			SqlCommand cmd = new SqlCommand("CountTemplate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) cnt = (Int32) rdr[0];
				rdr.Close();
			}
    
			return cnt.ToString();
		}
   
		string GetPredicateStats()
		{
			long cnt = 0;
			SqlCommand cmd = new SqlCommand("CountPredicate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) cnt = (Int32) rdr[0];
				rdr.Close();
			}
    
			return cnt.ToString();
		}
		
		void BtnNewDBClick(object sender, System.EventArgs e)
		{
 			GetConnection();
			
			SqlCommand cmdDropPat = new SqlCommand("DropPattern", cnx);
			cmdDropPat.CommandType = CommandType.StoredProcedure;
			Int32 retDropPat = cmdDropPat.ExecuteNonQuery();
    
			SqlCommand cmdDropCon = new SqlCommand("DropContext", cnx);
			cmdDropCon.CommandType = CommandType.StoredProcedure;
			Int32 retDropCon = cmdDropCon.ExecuteNonQuery();
    
			SqlCommand cmdDropTmp = new SqlCommand("DropTemplate", cnx);
			cmdDropTmp.CommandType = CommandType.StoredProcedure;
			Int32 retDropTmp = cmdDropTmp.ExecuteNonQuery();
    
			SqlCommand cmdDropPrd = new SqlCommand("DropPredicate", cnx);
			cmdDropPrd.CommandType = CommandType.StoredProcedure;
			Int32 retDropPrd = cmdDropPrd.ExecuteNonQuery();
    
			SqlCommand cmdMakePat = new SqlCommand("CreatePattern", cnx);
			cmdMakePat.CommandType = CommandType.StoredProcedure;
			Int32 retMakePat = cmdMakePat.ExecuteNonQuery();
    
			SqlCommand cmdMakeCon = new SqlCommand("CreateContext", cnx);
			cmdMakeCon.CommandType = CommandType.StoredProcedure;
			Int32 retMakeCon = cmdMakeCon.ExecuteNonQuery();
    
			SqlCommand cmdMakeTmp = new SqlCommand("CreateTemplate", cnx);
			cmdMakeTmp.CommandType = CommandType.StoredProcedure;
			Int32 retMakeTmp = cmdMakeTmp.ExecuteNonQuery();
   
			SqlCommand cmdMakePrd = new SqlCommand("CreatePredicate", cnx);
			cmdMakePrd.CommandType = CommandType.StoredProcedure;
			Int32 retMakePrd = cmdMakePrd.ExecuteNonQuery();
    		
			long PatternNodeID = AddWord(0,"Pattern Root Node");
    
			SqlCommand cmdMakePatIdx = new SqlCommand("CreatePatternIndex", cnx);
			cmdMakePatIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakePatIdx = cmdMakePatIdx.ExecuteNonQuery();
    
			long ContextNodeID = AddContext(0,"Context Root Node",0);
    
			SqlCommand cmdMakeConIdx = new SqlCommand("CreateContextIndex", cnx);
			cmdMakeConIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakeConIdx = cmdMakeConIdx.ExecuteNonQuery();
     		
			SqlCommand cmdAddPrd = new SqlCommand("InsertPredicate", cnx);
			cmdAddPrd.CommandType = CommandType.StoredProcedure;
			cmdAddPrd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = "Seeker";
			cmdAddPrd.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = "New Cases";
			cmdAddPrd.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = "~~Global~~";
			cmdAddPrd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = "Copyright";
			cmdAddPrd.Parameters.Add("@Token",SqlDbType.VarChar,250).Value = "Written by Gary Dubuque on April 15, 2005";
			Int32 retAddPrd = cmdAddPrd.ExecuteNonQuery();
    
			SqlCommand cmdMakePrdIdx = new SqlCommand("CreatePredicateIndex", cnx);
			cmdMakePrdIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakePrdIdx = cmdMakePrdIdx.ExecuteNonQuery();
    
			cnx.Close();
			
			statusBar1.Text = strDB + " database now has all tables and indexes recreated.";
		}
   
		void ClearAIML()
		{
			SqlCommand cmdDropPat = new SqlCommand("DropPattern", cnx);
			cmdDropPat.CommandType = CommandType.StoredProcedure;
			Int32 retDropPat = cmdDropPat.ExecuteNonQuery();
    
			SqlCommand cmdDropCon = new SqlCommand("DropContext", cnx);
			cmdDropCon.CommandType = CommandType.StoredProcedure;
			Int32 retDropCon = cmdDropCon.ExecuteNonQuery();
    
			SqlCommand cmdDropTmp = new SqlCommand("DropTemplate", cnx);
			cmdDropTmp.CommandType = CommandType.StoredProcedure;
			Int32 retDropTmp = cmdDropTmp.ExecuteNonQuery();
    
			SqlCommand cmdMakePat = new SqlCommand("CreatePattern", cnx);
			cmdMakePat.CommandType = CommandType.StoredProcedure;
			Int32 retMakePat = cmdMakePat.ExecuteNonQuery();
    
			SqlCommand cmdMakeCon = new SqlCommand("CreateContext", cnx);
			cmdMakeCon.CommandType = CommandType.StoredProcedure;
			Int32 retMakeCon = cmdMakeCon.ExecuteNonQuery();
    
			SqlCommand cmdMakeTmp = new SqlCommand("CreateTemplate", cnx);
			cmdMakeTmp.CommandType = CommandType.StoredProcedure;
			Int32 retMakeTmp = cmdMakeTmp.ExecuteNonQuery();
    
			long PatternNodeID = AddWord(0,"Pattern Root Node");
    
			SqlCommand cmdMakePatIdx = new SqlCommand("CreatePatternIndex", cnx);
			cmdMakePatIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakePatIdx = cmdMakePatIdx.ExecuteNonQuery();
    
			long ContextNodeID = AddContext(0,"Context Root Node",0);
    
			SqlCommand cmdMakeConIdx = new SqlCommand("CreateContextIndex", cnx);
			cmdMakeConIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakeConIdx = cmdMakeConIdx.ExecuteNonQuery();
			
			statusBar1.Text = strDB + " database now has AIML tables and indexes recreated.";
		}

		int getRank(string ctype)
		{
			int rank = 9999;
			if (ctype.Equals("that")) rank = 1;
			if (ctype.Equals("topic")) rank = 2;
			if (ctype.Equals("if")) rank += 1;

			return rank;
		}
    
		Boolean docat(string pattern, string context, string tmplt)
		{
			string [] cntxts = context.Split(';');
			int at;
			string ctype = "";
			string cdata = "";

			if (pattern == "") return false;

			long catNode = AddGM(1,pattern);
			long contextNode = 0;

			foreach (string s in cntxts)
			{
				if ((at = s.IndexOf(",")) > 0)
				{
					ctype = s.Substring(0, at);
					cdata = s.Substring(at + 1);

					if (ctype.Length > 0 && cdata.Length > 0) 
					{
						contextNode = AddContext(catNode, ctype, getRank(ctype));
						if (ctype == "if") 
						{
							IfToken++;
							catNode = AddWord(-contextNode, "if" + IfToken.ToString());
							AddTemplate(-catNode, cdata);
						}
						else
						{
							catNode = AddGM(-contextNode, cdata);
						}
					}
				}
			}

			return AddTemplate(catNode,tmplt);
		}
    
		void doxml()
		{
			string fn = "\\";
			string fileName = "" + txtFileName.Text;
			string fileStats = "";
			long lngCat = 0;
			long lngTotalCat = 0;
			FileStream fs;
			StreamReader rdr;
			Boolean lp = true;
			FileInfo[] fnlist;
			int i;
			string fname = "";

			i = fileName.LastIndexOf("\\");
			if (i >= 0) {
				if (i > 0) fn = fileName.Substring(0, i + 1); else fn = "\\";
				fileName = fileName.Substring(i + 1);
			} else fn = Application.StartupPath.ToString() + "\\";

			DirectoryInfo directoryInfo = new DirectoryInfo(fn);
    
			if (fileName == "")
			{
				fn = directoryInfo.FullName + "aiml.aiml";
			}
			else
			{
				fn = directoryInfo.FullName + fileName;
				i = fn.LastIndexOf("\\");
				if (i >= 0) 
				{
					if (i > 0) fileName = fn.Substring(0, i); else fileName = "\\";
					directoryInfo = new DirectoryInfo(fileName);
				}
			}
    
			if (radAIML.Checked)
			{
				txtPattern.Text = fn;
				lngCat = loadxml(fn);
				txtTemplate.Text = "Total categories read = " + lngCat.ToString();
			}
			else
			{
				fs = new FileStream(fn,FileMode.Open, FileAccess.Read);
				rdr = new StreamReader(fs);
    
				while (lp)
				{
					try 
					{
						fn = rdr.ReadLine().Trim();
						if (fn.ToUpper() == "<EOF>") break;
						if (fn != "")
						{
							fnlist = directoryInfo.GetFiles(fn);
							for (i = 0;i < fnlist.Length;i++)
							{
								fname = fnlist[i].Name;
								fileName = fnlist[i].DirectoryName + "\\" + fname;
								lngCat = loadxml(fileName);
								fileStats += "Total categories read (" + fname + ") = " + lngCat.ToString() + "\r\n";
								lngTotalCat += lngCat;
							}
						}
					}
					catch (Exception ex)
					{
						fileStats += "\r\nError (" + fname + ") = " + ex.Message + "\r\n";
						lp = false;
					}
				}
    
				rdr.Close();
				fs.Close();
    
				txtTemplate.Text = fileStats + "\r\nTotal categories read = " + lngTotalCat.ToString();
			}
		}
    
		long loadxml(string XmlFile)
		{
			string topic = "";
			string that = "";
			string pattern = "*";
			string context = "";
			string template = "";
			long lngCat = 0;
    
			//load the xml file into the XmlTextReader object.
			XmlTextReader XmlRdr = new XmlTextReader(XmlFile);
			
			statusBar1.Text = "Reading file: " + XmlFile;
			Application.DoEvents();
    
			//while moving through the xml document.
			while (XmlRdr.Read())
			{
				//check the node type and look for the element type
				//whose Name property is equal to aiml tags: topic, category, pattern, that, template
				if (XmlRdr.NodeType == XmlNodeType.Element)
				{
					if (XmlRdr.Name == "topic") topic = "topic," + XmlRdr.GetAttribute("name") + ";";
					if (XmlRdr.Name == "category")
					{
						if (XmlRdr.Depth == 1) topic = "";
						pattern = "";
						context = "";
						that = "";
						template = "";
					}
					if (XmlRdr.Name == "pattern") pattern = XmlRdr.ReadInnerXml();
					if (XmlRdr.Name == "context") context += XmlRdr.GetAttribute("name") + "," + XmlRdr.ReadInnerXml() + ";";
					if (XmlRdr.Name == "if") context += "if," + XmlRdr.ReadInnerXml() + ";";
					if (XmlRdr.Name == "that")    that = "that," + XmlRdr.ReadInnerXml() + ";";
					if (XmlRdr.Name == "template")
					{
						template = XmlRdr.ReadInnerXml();
						if (template != "")
						{
							// need to fix old AIML stuff in template
							// like <get_predicate/> is <get name="predicate"/>
							docat(pattern, that + topic + context, template);
							lngCat += 1;
						}
					}
				}
			}
    
			XmlRdr.Close();
    
			return lngCat;
		}
     
		Boolean AddTemplate(long ParentID,string Template)
		{
			string tmplt = Template.Trim();
    
			SqlCommand cmd = new SqlCommand("InsertTemplate", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
    
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ParentID;
			cmd.Parameters.Add("@Script",SqlDbType.Text).Value = tmplt;
    
			Int32 ret = cmd.ExecuteNonQuery();
			return (ret == 1);
		}
     
		long FindWord(long ID, string Token)
		{
			long ans = 0;
			SqlCommand cmd = new SqlCommand("SelectNodeByTierWord", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
			cmd.Parameters.Add("@Word",SqlDbType.VarChar,250).Value = Token;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (Int32) rdr["NodeID"];
				rdr.Close();
			}
    
			return ans;
		}

		long AddWord(long ID, string Token)
		{
			long ans = FindWord(ID, Token);
    
			if (ans == 0) 
			{
				SqlCommand cmd = new SqlCommand("InsertWord", cnx);
				cmd.CommandType = CommandType.StoredProcedure;
    
				cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
				cmd.Parameters.Add("@Word",SqlDbType.VarChar,250).Value = Token;
				cmd.Parameters.Add("@NodeID",SqlDbType.Int).Direction = ParameterDirection.Output;
    
				Int32 ret = cmd.ExecuteNonQuery();
    
				ans = (Int32) cmd.Parameters["@NodeID"].Value;
			}
    
			return ans;
		}
    
		long FindContext(long ID, string Token)
		{
			long ans = 0;
			SqlCommand cmd = new SqlCommand("SelectNodeByTierType", cnx);
			cmd.CommandType = CommandType.StoredProcedure;
			cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
			cmd.Parameters.Add("@Type",SqlDbType.VarChar,250).Value = Token;
			SqlDataReader rdr = cmd.ExecuteReader();
    
			if (rdr != null) 
			{
				while (rdr.Read()) ans = (Int32) rdr["NodeID"];
				rdr.Close();
			}
    
			return ans;
		}
    
		long AddContext(long ID, string Token, long Rank)
		{
			long ans = FindContext(ID, Token);
    
			if (ans == 0) 
			{
				SqlCommand cmd = new SqlCommand("InsertContext", cnx);
				cmd.CommandType = CommandType.StoredProcedure;
    
				cmd.Parameters.Add("@ParentID",SqlDbType.Int).Value = ID;
				cmd.Parameters.Add("@Type",SqlDbType.VarChar,250).Value = Token;
				cmd.Parameters.Add("@Rank",SqlDbType.Int).Value = Rank;
				cmd.Parameters.Add("@NodeID",SqlDbType.Int).Direction = ParameterDirection.Output;
    
				Int32 ret = cmd.ExecuteNonQuery();
    
				ans = (Int32) cmd.Parameters["@NodeID"].Value;
			}
    
			return ans;
		}

		long AddGM(long ID, string pattern)
		{
						
			string patrn = pattern.ToUpper();
    
			//         patrn = patrn.Replace("<bot/>","HOMER");
			patrn = patrn.Replace("<bot/>","ALICE");
			patrn = patrn.Replace("<bot />","ALICE");

			if (patrn.EndsWith("*"))
			{
				patrn += ":";
				patrn = patrn.Replace("*:","@");
			}

			return AddNode(ID,patrn);
		}
    
		long AddNode(long ID, string pattern)
		{
			string str = pattern.TrimStart(null);
    
			if (str == "") return ID;

			string word = str;
			string tail = "";
			int at = str.IndexOf(" ");
    
			if (at >= 0)
			{
				word = str.Substring(0,at).TrimEnd(null);
				tail = str.Substring(at);
			}
    
			return AddNode(AddWord(ID, word), tail);
		}
		
		void BtnSaveClick(object sender, System.EventArgs e)
		{
			GetConnection();
			
			string patrn = "" + txtPattern.Text;
			string tmplt = "" + txtTemplate.Text;

			if (chkClear.Checked)
			{
				ClearAIML();
				chkClear.Checked = false;
			}
    
			if (patrn == "") 
			{
				txtTemplate.Text = "Loading DB...";
				Application.DoEvents();
				doxml();
			}
			else if (docat(patrn, "", tmplt))
			{
				txtPattern.Text = "";
				txtTemplate.Text = "";
			}
			
			cnx.Close();			
			statusBar1.Text = "Database is loaded.";
		}
		
		void BtnCreateClick(object sender, System.EventArgs e)
		{
			txtTemplate.Text = "Building DB...";
			
			GetConnection();
			
			string strSQL = "CREATE PROCEDURE CreateContext AS CREATE TABLE Context (NodeID int IDENTITY(1,1) PRIMARY KEY,ParentID int NOT NULL,Type varchar(250) NOT NULL,Rank int DEFAULT 9999)";
			SqlCommand cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			Int32 ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE CreatePattern AS CREATE TABLE Pattern (NodeID int IDENTITY(1,1) PRIMARY KEY,ParentID int NOT NULL,Word varchar(250) NOT NULL)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE CreatePredicate AS CREATE TABLE Predicate (PredicateID int IDENTITY(1,1) PRIMARY KEY,Client varchar(250) NOT NULL,Subject varchar(200) NOT NULL,Class varchar(200) NOT NULL,Tag varchar(250) NOT NULL,CF float DEFAULT 1,Token text)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE CreateTemplate AS CREATE TABLE Template (TemplateID int IDENTITY(1,1) PRIMARY KEY,ParentID int NOT NULL,Script text NOT NULL)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			SqlCommand cmdMakeCon = new SqlCommand("CreateContext", cnx);
			cmdMakeCon.CommandType = CommandType.StoredProcedure;
			Int32 retMakeCon = cmdMakeCon.ExecuteNonQuery();
    
			SqlCommand cmdMakePat = new SqlCommand("CreatePattern", cnx);
			cmdMakePat.CommandType = CommandType.StoredProcedure;
			Int32 retMakePat = cmdMakePat.ExecuteNonQuery();
   
			SqlCommand cmdMakePrd = new SqlCommand("CreatePredicate", cnx);
			cmdMakePrd.CommandType = CommandType.StoredProcedure;
			Int32 retMakePrd = cmdMakePrd.ExecuteNonQuery();
    
			SqlCommand cmdMakeTmp = new SqlCommand("CreateTemplate", cnx);
			cmdMakeTmp.CommandType = CommandType.StoredProcedure;
			Int32 retMakeTmp = cmdMakeTmp.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE InsertContext @ParentID int, @Type varchar(250), @Rank int, @NodeID int OUT AS INSERT INTO Context (ParentID, Type, Rank) VALUES (@ParentID, @Type, @Rank) SET @NodeID = @@Identity RETURN @@ROWCOUNT";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE InsertPredicate @Client varchar(250), @Subject varchar(200), @Class varchar(200), @Tag varchar(250), @Token text AS INSERT INTO Predicate (Client, Subject, Class, Tag, Token) VALUES (@Client, @Subject, @Class, @Tag, @Token)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE InsertTemplate @ParentID int, @Script text AS INSERT INTO Template (ParentID, Script) VALUES (@ParentID, @Script)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE InsertWord @ParentID int, @Word varchar(250), @NodeID int OUT AS INSERT INTO Pattern (ParentID, Word) VALUES (@ParentID, @Word) SET @NodeID = @@Identity RETURN @@ROWCOUNT";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
			
			SqlCommand cmdAddCon = new SqlCommand("InsertContext", cnx);
			cmdAddCon.CommandType = CommandType.StoredProcedure;
			cmdAddCon.Parameters.Add("@ParentID",SqlDbType.Int).Value = 0;
			cmdAddCon.Parameters.Add("@Type",SqlDbType.VarChar,250).Value = "Context Root Node";
			cmdAddCon.Parameters.Add("@Rank",SqlDbType.Int).Value = 0;
			cmdAddCon.Parameters.Add("@NodeID",SqlDbType.Int).Direction = ParameterDirection.Output;
			ret = cmdAddCon.ExecuteNonQuery();
     		
			SqlCommand cmdAddPat = new SqlCommand("InsertWord", cnx);
			cmdAddPat.CommandType = CommandType.StoredProcedure;
			cmdAddPat.Parameters.Add("@ParentID",SqlDbType.Int).Value = 0;
			cmdAddPat.Parameters.Add("@Word",SqlDbType.VarChar,250).Value = "Pattern Root Node";
			cmdAddPat.Parameters.Add("@NodeID",SqlDbType.Int).Direction = ParameterDirection.Output;
			ret = cmdAddPat.ExecuteNonQuery();
     		
			SqlCommand cmdAddPrd = new SqlCommand("InsertPredicate", cnx);
			cmdAddPrd.CommandType = CommandType.StoredProcedure;
			cmdAddPrd.Parameters.Add("@Client",SqlDbType.VarChar,250).Value = "Seeker";
			cmdAddPrd.Parameters.Add("@Subject",SqlDbType.VarChar,200).Value = "New Cases";
			cmdAddPrd.Parameters.Add("@Class",SqlDbType.VarChar,200).Value = "Global";
			cmdAddPrd.Parameters.Add("@Tag",SqlDbType.VarChar,250).Value = "Copyright";
			cmdAddPrd.Parameters.Add("@Token",SqlDbType.VarChar,250).Value = "Written by Gary Dubuque on April 15, 2005";
			ret = cmdAddPrd.ExecuteNonQuery();
   
			strSQL = "CREATE PROCEDURE CreateContextIndex AS CREATE INDEX IX_Context ON Context (ParentID)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE CreatePatternIndex AS CREATE UNIQUE INDEX IX_Pattern ON Pattern (ParentID,Word)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE CreatePredicateIndex AS CREATE INDEX IX_Predicate ON Predicate (Client,Subject,Class,Tag)";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			SqlCommand cmdMakeConIdx = new SqlCommand("CreateContextIndex", cnx);
			cmdMakeConIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakeConIdx = cmdMakeConIdx.ExecuteNonQuery();
    
			SqlCommand cmdMakePatIdx = new SqlCommand("CreatePatternIndex", cnx);
			cmdMakePatIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakePatIdx = cmdMakePatIdx.ExecuteNonQuery();
    
			SqlCommand cmdMakePrdIdx = new SqlCommand("CreatePredicateIndex", cnx);
			cmdMakePrdIdx.CommandType = CommandType.StoredProcedure;
			Int32 retMakePrdIdx = cmdMakePrdIdx.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE DropContext AS DROP TABLE Context";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE DropPattern AS DROP TABLE Pattern";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE DropPredicate AS DROP TABLE Predicate";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
    
			strSQL = "CREATE PROCEDURE DropTemplate AS DROP TABLE Template";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectListByTier @ParentID int AS Select Type From Context Where ParentID = @ParentID Order by Rank";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectNodeByTierType @ParentID int, @Type varchar(250) AS Select NodeID From Context Where ParentID = @ParentID And Type = @Type";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectNodeByTierWord @ParentID int, @Word varchar(250) AS Select NodeID From Pattern Where ParentID = @ParentID And Word = @Word";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectPredicate @Client varchar(250), @Subject varchar(250), @Class varchar(250), @Tag varchar(250) AS Select Token From Predicate Where Client = @Client And Subject = @Subject And Class = @Class And Tag = @Tag";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectTemplate @TemplateID int AS Select Script From Template Where TemplateID = @TemplateID";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectTemplateByNodeID @NodeID int AS Select TemplateID From Template Where ParentID = @NodeID";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE SelectWordByNodeID @NodeID int AS Select Word From Pattern Where NodeID = @NodeID";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE UpdatePredicate @Client varchar(250), @Subject varchar(200), @Class varchar(200), @Tag varchar(250), @Token text AS UPDATE Predicate SET Token = @Token Where Client = @Client And Subject = @Subject And Class = @Class And Tag = @Tag";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE DeletePredicate @Client varchar(250), @Subject varchar(200), @Class varchar(200), @Tag varchar(250) AS DELETE Predicate Where Client = @Client And Subject = @Subject And Class = @Class And Tag = @Tag";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE CountContext AS  Select COUNT(*) From Context";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE CountPattern AS  Select COUNT(*) From Pattern";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE CountTemplate AS  Select COUNT(*) From Template";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();
      
			strSQL = "CREATE PROCEDURE CountPredicate AS Select COUNT(*) From Predicate";
			cmd = new SqlCommand(strSQL, cnx);
			cmd.CommandType = CommandType.Text;   
			ret = cmd.ExecuteNonQuery();

			cnx.Close();
			
			txtTemplate.Text = "";
			statusBar1.Text = strDB + " database now has tables and procedures created.";
		}
		
		void ChkWinTrustCheckedChanged(object sender, System.EventArgs e)
		{
			if (chkWinTrust.Checked)
			{
				lblAccount.Enabled = false;
				txtAccount.Enabled = false;
				lblPassword.Enabled = false;
				txtPassword.Enabled = false;
			}
			else
			{
				lblAccount.Enabled = true;
				txtAccount.Enabled = true;
				lblPassword.Enabled = true;
				txtPassword.Enabled = true;
			}
		}
		
		void BtnBrowseClick(object sender, System.EventArgs e)
		{
			if (openFileDialog1.ShowDialog() != System.Windows.Forms.DialogResult.Cancel)
			{
				txtFileName.Text = openFileDialog1.FileName;
			}
		}
		
		void BtnMakeClick(object sender, System.EventArgs e)
		{
			
			txtTemplate.Text = "Making DB...";
			
			strServer = txtServer.Text;
			strDB = txtDB.Text;
			
			if (chkWinTrust.Checked)
			{
				cnx = new SqlConnection("Server=" + strServer + ";Trusted_Connection=true;");
			}
			else
			{
				cnx = new SqlConnection("Server=" + strServer + ";UID=" + txtAccount.Text + ";PWD=" + txtPassword.Text + ";");
			}
			cnx.Open();
			
			string strSQL;
			SqlCommand cmd;
			Int32 ret;
			
			try {
				strSQL = "DROP DATABASE " + strDB;
				cmd = new SqlCommand(strSQL, cnx);
				cmd.CommandType = CommandType.Text;   
				ret = cmd.ExecuteNonQuery();
			} catch {
				txtTemplate.Text = "Creating DB...";
			}
			
			if (txtPattern.Text != "drop") {
				strSQL = "CREATE DATABASE " + strDB;
				cmd = new SqlCommand(strSQL, cnx);
				cmd.CommandType = CommandType.Text;   
				ret = cmd.ExecuteNonQuery();
			}
			cnx.Close();
			
			txtTemplate.Text = "";
			
			if (txtPattern.Text == "drop") {
				statusBar1.Text = strDB + " database now is gone.";
			} else {
				statusBar1.Text = strDB + " database now exists.";
			}
			
			txtPattern.Text = "";
		}
		
	}
}
