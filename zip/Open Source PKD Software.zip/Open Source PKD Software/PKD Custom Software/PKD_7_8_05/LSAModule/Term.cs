/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// Term holds LSA information associated with a word
	/// </summary>
	[Serializable]
	public class Term
	{
		public float scale;		//weighting on this word
		public float[] vector;

		public Term( float scale, float[] vector )
		{
			this.scale = scale;
			this.vector = vector;		
		}
	}

	/// <summary>
	/// Only use this to read in the matrix.txt and terms.dat files, which
	/// must be rectified by the index (primary key)
	/// </summary>
	public class IndexedTerm : IComparable
	{
		public string word;
		public int index;
		public float scale;
		
		public IndexedTerm( string word, int index, float scale )
		{
			this.word = word;
			this.index = index;
			this.scale = scale;
		}
		#region IComparable Members

		public int CompareTo(object obj)
		{
			IndexedTerm temp = obj as IndexedTerm;
			if( temp != null ) 
			{
				return this.index.CompareTo( temp.index );
			}
			else
				throw new ArgumentException("object is not a IndexedTerm");
		}

		#endregion
	}

	/// <summary>
	/// Only use this to read in the matrix.txt and terms.dat files, which
	/// must be rectified by the index (primary key)
	/// </summary>
	public class IndexedVector : IComparable
	{
		public int index;
		public float[] vector;

		public IndexedVector( int index, float[] vector )
		{
			this.index = index;
			this.vector = vector;
		}
		#region IComparable Members

		public int CompareTo(object obj)
		{
			IndexedVector temp = obj as IndexedVector;
			if( temp != null ) 
			{
				return this.index.CompareTo( temp.index );
			}
			else
				throw new ArgumentException("object is not a IndexedVector");
		}

		#endregion
	}
}