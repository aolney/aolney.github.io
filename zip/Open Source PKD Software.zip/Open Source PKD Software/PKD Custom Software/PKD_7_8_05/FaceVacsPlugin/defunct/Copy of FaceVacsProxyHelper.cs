using System;

namespace PKDPlugin
{
	/// <summary>
	/// A delegate for notifying the client side shadow fact that it needs to update
	/// </summary>
	[Serializable]
	public delegate void UpdateShadowFact();

	[Serializable]
	public class FaceVacsData 
	{
		public string recordID = "";
		public string issuer = "";
		public int personID;
		public string authName = "";
		public string authDate = "";
		public string authSig = "";
		public string name = "";
		public string active = "";
		public string serial = "";
		public int confidence;
		public FaceVacsData() {}
	}

	/// <summary>
	/// We need a helper class b/c jess cannot make a remoted object a shadow fact
	/// </summary>
	[Serializable]
	public class FaceVacsProxyHelper : System.MarshalByRefObject
	{
		public FaceVacsData currentData = null;
		public FaceVacsData newData = null;
		public PKDPlugin.UpdateShadowFact updateShadowFact = null;
		public string receiverWindowIdentifier = "FaceVacsPlugin";

		public FaceVacsProxyHelper()
		{
			this.currentData = new FaceVacsData();
			this.newData = new FaceVacsData();

			//Start the FaceVacs process, which will run in a loop
			System.Diagnostics.Process.Start(@"FaceRec_beta.exe", @"c:\FVEntry_3_6_1\etc\facevacs.cfg " + receiverWindowIdentifier );
		}

		public void SetNotificationDelegate( PKDPlugin.UpdateShadowFact updateShadowFact )
		{
			this.updateShadowFact = updateShadowFact;
		}

		public void Update()
		{
			if( this.updateShadowFact != null )
				this.updateShadowFact();

			//Copy over the new values
			this.currentData.active = this.newData.active ;
			this.currentData.authDate = this.newData.authDate ;
			this.currentData.authName = this.newData.authName ;
			this.currentData.authSig = this.newData.authSig ;
			this.currentData.confidence = this.newData.confidence ;
			this.currentData.issuer = this.newData.issuer ;
			this.currentData.name = this.newData.name ;
			this.currentData.personID = this.newData.personID ;
			this.currentData.recordID = this.newData.recordID ;
			this.currentData.serial = this.newData.serial ;
		}
	}
}
