/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using System.Reflection;

namespace PKDPlugin
{
	public class PluginManager
	{
		#region Fields / Constructor
		public System.Collections.Hashtable pluginEventHandlersHash = new System.Collections.Hashtable();
		public System.Collections.ArrayList pluginList = new System.Collections.ArrayList();
		public string pluginPath = @"plugins\";

		public PluginManager()
		{
			this.pluginEventHandlersHash = new System.Collections.Hashtable();
			this.pluginList = new System.Collections.ArrayList();
		}

		#endregion
		#region Plugin Loading/Unloading
		public void LoadAllPlugins( string path, jess.Rete engine )
		{	
			string[] assemblyNames = System.IO.Directory.GetFiles( path, "*.dll" );      

			foreach( string assemblyName in assemblyNames )
			{
				//Just in case these take a long time and we are starving other processes
				System.Threading.Thread.Sleep( 100 );
				LoadPlugin( assemblyName, engine );
			}
		}
		public void UnloadAllPlugins()
		{
			foreach( IJessPlugin plugin in this.pluginList )
			{
				plugin.UnregisterEventHandler( this.pluginEventHandlersHash );
			}
		}
		public bool UnloadPlugin( string assemblyName )
		{
			foreach( PluginData pluginData in this.pluginList )
			{
				if( pluginData.assemblyName.Equals( assemblyName ) )
				{
					this.pluginList.Remove( pluginData );
					return true;
				}
			}
			return false;
		}
		/// <summary>
		/// Find types in the assembly that are compatible with the target. Add these 
		/// as plugins
		/// </summary>
		/// <param name="assemblyName"></param>
		/// <returns></returns>
		public bool LoadPlugin( string assemblyName, jess.Rete engine )
		{
			Type targetType = typeof( PKDPlugin.IJessPlugin );
         
			try
			{
				Assembly assembly = Assembly.LoadFrom( assemblyName );
				Type[] types = assembly.GetExportedTypes();         
				foreach(Type aType in types)
				{
					if( targetType.IsAssignableFrom( aType ) )
					{
						Console.Write( "Loading " + aType.Name + "..." );
						
						System.Runtime.Remoting.ObjectHandle objectHandle = Activator.CreateInstanceFrom( assemblyName, aType.ToString() );
						PKDPlugin.IJessPlugin aPlugin = ( PKDPlugin.IJessPlugin ) objectHandle.Unwrap();
						//aPlugin.DeclareExports( engine );
						aPlugin.RegisterEventHandler( this.pluginEventHandlersHash );
						//Because the ikvm runtime requires a cli namespace for the java classloader to find the class
						string name = "cli." + aType.FullName;
						engine.defclass( aType.Name, name, null );
						engine.definstance( aType.Name, aPlugin, true );
						this.pluginList.Add( new PluginData( assemblyName, aPlugin) );    
						
						if( aType.Name.Length < 13 )
							Console.WriteLine( "\t\tDONE!" );
						else
							Console.WriteLine( "\tDONE!" );
					}
				}       
			}
			catch( System.Exception e )
			{
				Console.WriteLine( e.Message );
			}
			return true;
		}
		#endregion
		#region I / O
		public void FireEvent( PKDPlugin.CoreEvents eventID, PKDPlugin.CoreEventArgs e)
		{
			if( this.pluginEventHandlersHash[ eventID ] != null )
			{
				( ( PKDPlugin.CoreEventHandler )( this.pluginEventHandlersHash[ eventID ] ) )( this, e );
			}
		}

		/*
		public void Import( jess.Rete engine )
		{
			foreach( PKDPlugin.PluginData pluginData in this.pluginList )
			{
				pluginData.plugin.Export( engine );
			}
		}
		*/
		#endregion
	}

	/// <summary>
	/// A convenient way to store the plugin name with the object so that we can unload single plugins 
	/// by name at runtime
	/// </summary>
	public class PluginData
	{
		public string assemblyName;
		public PKDPlugin.IJessPlugin plugin;

		public PluginData( string assemblyName, PKDPlugin.IJessPlugin plugin )
		{
			this.assemblyName = assemblyName;
			this.plugin = plugin;
		}
	}
}