/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	/// <summary>
	/// We need a helper class b/c jess cannot make a remoted object a shadow fact
	/// </summary>
	[Serializable]
	public class FaceTrackerProxyHelper : System.MarshalByRefObject
	{
		//B/c I can't get the framework to remote an array for some reason (trust issue?)
		public int headSize0;
		public int headSize1;
		public int headSize2;
		public int headSize3;
		public int headSize4;
		public int headSize5;
		public int headSize6;
		public int headSize7;
		public int headSize8;
		public int headSize9;
		
		public int headX0;
		public int headX1;
		public int headX2;
		public int headX3;
		public int headX4;
		public int headX5;
		public int headX6;
		public int headX7;
		public int headX8;
		public int headX9;
		
		public int headY0;
		public int headY1;
		public int headY2;
		public int headY3;
		public int headY4;
		public int headY5;
		public int headY6;
		public int headY7;
		public int headY8;
		public int headY9;


		public int headId0;
		public int headId1;
		public int headId2;
		public int headId3;
		public int headId4;
		public int headId5;
		public int headId6;
		public int headId7;
		public int headId8;
		public int headId9;
		

		public int numberHeadsTracked;
		public int centerFace;
		public int centerFaceX;
		public int centerFaceY;
		public int centerFaceHeadSize;
	
		public FaceTrackerProxyHelper()
		{
		}
	}
}
