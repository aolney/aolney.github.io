using System;

namespace PKDPlugin
{
	public class TrackedFace
	{
		#region Fields / Constructor
		public int id;
		public SharperCV.CvPoint center;
		public SharperCV.CvRect boundingBox;
		public bool isMatched;
		public int matchCount;

		public int maxWeight = 30;
		public int minWeight = 10;

		public TrackedFace( int id, SharperCV.CvRect boundingBox )
		{
			this.id = id;
			this.boundingBox = boundingBox;
			this.center = Calculator.Center( boundingBox );
			this.isMatched = false;		
			this.matchCount = this.minWeight;
		}	
		#endregion
		public void Match( SharperCV.CvRect face )
		{
			this.boundingBox = face;
			this.center = Calculator.Center( face );
			this.isMatched = true;
			if( this.matchCount < this.maxWeight )
				this.matchCount++;
		}
	}
}
