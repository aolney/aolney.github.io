using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WirelessKeypadProxyServer
{
	/// <summary>
	/// Summary description for WirelessKeypadProxyServer.
	/// </summary>
	public class WirelessKeypadProxyServer : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		public PKDPlugin.WirelessKeypadProxyHelper wirelessKeypadProxyHelper = null;

		public WirelessKeypadProxyServer()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.Name = "WirelessKeyboardProxyServer";
			this.Text = "WirelessKeyboardProxyServer";

			this.KeyPress += new KeyPressEventHandler( Form1_KeyPress );

			//Start a server to host remoted objects
			int port = 1979;
			string name = "PKDPlugin.WirelessKeypadProxyHelper";
			Type type = Type.GetType( name );
			System.Runtime.Remoting.Channels.Tcp.TcpChannel tcpServerChannel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel( port );
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel( tcpServerChannel );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( type, name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );
	
			//The trick -- get an instance of the singleton back from the server to initialize the class member
			//Now we can modify the object and changes will be mirrored on the client
			string uri = "tcp://localhost:" + port + "/" + name;
			this.wirelessKeypadProxyHelper = ( PKDPlugin.WirelessKeypadProxyHelper ) Activator.GetObject( type, uri );
		}

		public void Form1_KeyPress( object o, System.Windows.Forms.KeyPressEventArgs args )
		{
			this.wirelessKeypadProxyHelper.key = args.KeyChar;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.Size = new System.Drawing.Size(300,300);
			this.Text = "Form1";
		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new WirelessKeypadProxyServer());
		}
	}
}
