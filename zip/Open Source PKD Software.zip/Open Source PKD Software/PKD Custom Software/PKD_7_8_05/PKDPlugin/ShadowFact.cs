/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	[Serializable]
	public class ShadowFact
	{
		protected java.beans.PropertyChangeSupport propertyChangeSupport;
		
		public ShadowFact()
		{
			this.propertyChangeSupport = new java.beans.PropertyChangeSupport( this );
		}
		
		public void addPropertyChangeListener( java.beans.PropertyChangeListener p ) 
		{
			propertyChangeSupport.addPropertyChangeListener( p );
		}
		
		public void removePropertyChangeListener( java.beans.PropertyChangeListener p ) 
		{
			propertyChangeSupport.removePropertyChangeListener( p );
		}
	}
	
	/// <summary>
	/// This is an example of a working shadow fact implementation
	/// </summary>
	public class Thermometer : ShadowFact
	{
		private int m_floor;
		private double m_oldReading;
		public Thermometer( int floor ) 
		{
			m_floor = floor;
			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();
		}
		public int getFloor() 
		{
			return m_floor;
		}
		public double getReading() 
		{
			System.Random random = new Random();
			return random.NextDouble();
		}
		public void Run() 
		{
			while (true) 
			{
				double reading = getReading();
				propertyChangeSupport.firePropertyChange("reading", new java.lang.Double( m_oldReading ), new java.lang.Double( reading ) );
				m_oldReading = reading;
				System.Threading.Thread.Sleep( 500 );
			}
		}
	}
}
