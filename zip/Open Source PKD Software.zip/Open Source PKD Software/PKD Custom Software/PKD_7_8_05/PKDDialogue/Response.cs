/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDDialogue
{
	public enum NLGSource { Paragraph = 0, Sentence, Chatterbot };

	/// <summary>
	/// An NLG response to input. Contains vector measures for ranking and cohesion calculation
	/// </summary>
	public class Response : IComparable 
	{
		#region Fields / Constructor
		public string text;
		public string speakableText;
		public float[] vector;
		public float sortingValue;
		public float cosine;
		public float relevance;
		public float informativity;
		public NLGSource nlgSource;

		public Response( NLGSource nlgSource, string text, float[] vector, float cosine )
		{
			this.nlgSource = nlgSource;
			this.text = text;
			this.vector = vector;
			this.cosine = cosine;
		}

		#endregion
		public void AdjustBasisMeasures( float[] measures )
		{
			this.relevance = measures[ 0 ];
			this.informativity = measures[ 1 ];
		}
		#region IComparable Members
		public int CompareTo(object obj)
		{
			Response response = obj as Response;
			if( response != null ) 
			{
				return this.sortingValue.CompareTo( response.sortingValue );
			}
			else
				throw new ArgumentException("object is not an Response");
		}
		#endregion
	}
}
