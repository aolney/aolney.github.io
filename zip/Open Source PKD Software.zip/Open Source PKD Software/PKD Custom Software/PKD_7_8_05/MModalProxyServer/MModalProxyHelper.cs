using System;

namespace PKDPlugin
{
	/// <summary>
	/// We need a helper class b/c jess cannot make a remoted object a shadow fact
	/// </summary>
	[Serializable]
	public class MModalProxyHelper : System.MarshalByRefObject
	{
		public string text = "";
		//If the ASR is working, the robot can act attentive
		public bool isWorking = false;
		//If the utterance is ready, the robot can respond
		public bool utteranceReady = false;
		public bool isNew = false;
	
		public MModalProxyHelper()
		{
		}
	}
}
