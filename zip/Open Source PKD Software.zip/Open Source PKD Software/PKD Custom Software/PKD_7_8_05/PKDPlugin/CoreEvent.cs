/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	/// <summary>
	/// The core events that a plugin may currently be interested in
	/// </summary>
	public enum CoreEvents 
	{
		Audio, Viseme, Animation
	};

	/// <summary>
	/// An event has a type as well as associated data
	/// </summary>
	public class CoreEventArgs
	{
		public CoreEvents EventType;
		public object EventData;

		public CoreEventArgs(CoreEvents type, object data)
		{
			EventType = type;
			EventData = data;
		}
	}

	public delegate void CoreEventHandler( object sender, CoreEventArgs e );

	/// <summary>
	/// Defines a pairing of core event handler and the event it handles.  A convenient way to store 
	/// these values in an ArrayList for registering/unregistering events and their handlers with 
	/// the core
	/// </summary>
	[Serializable]
	public class CoreEventHandlerPair
	{
		public CoreEventHandler handler;
		public CoreEvents eventToHandle;

		public CoreEventHandlerPair( CoreEventHandler handler, CoreEvents eventToHandle )
		{
			this.handler = handler;
			this.eventToHandle = eventToHandle;
		}
	}
}
