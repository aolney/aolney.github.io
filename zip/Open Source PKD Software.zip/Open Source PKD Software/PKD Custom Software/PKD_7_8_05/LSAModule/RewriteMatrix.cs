/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// Read in the terms.dat and matrix.txt files and create an LSAModuleObject. Serialize it.
	/// </summary>
	public class RewriteMatrix
	{
		#region Fields/Constructor
		public int numberDocuments = 0;
		public int numberTerms = 0;    
		public int numberFactors = 0;
    
		public string matrixFile;
		public string termsFile;
 
		public System.IO.StreamReader matrixReader = null;
		public System.IO.StreamReader termsReader = null;

		//Assorted strucutures used to construct a space
		//Used to rectify the terms with the vectors, joining on the primary key, index
		private System.Collections.ArrayList indexedTermsList = null;
		private System.Collections.ArrayList indexedVectorsList = null;
		private float[] singularValues = null;
		private System.Collections.Hashtable termHash = null;

		public RewriteMatrix( string matrixFile, string termsFile )
		{
			this.matrixFile = matrixFile;
			this.termsFile = termsFile;

			this.matrixReader = new System.IO.StreamReader( this.matrixFile );
			this.termsReader = new System.IO.StreamReader( this.termsFile );

			this.indexedVectorsList = new System.Collections.ArrayList();
			this.indexedTermsList = new System.Collections.ArrayList();
			this.termHash = new System.Collections.Hashtable();
		}
		#endregion
		#region Populate
		/// <summary>
		/// Loads the terms into a list, loads vectors into a list, cross indexes lists
		/// and creates a term hash (word, {vector,scale} )
		/// </summary>
		private void Populate()
		{
			LoadTerms();
			LoadMatrix();
			CreateTermHash();
		}

		#region LoadTerms
		/// <summary>
		/// Read terms.dat. Each line is triple word\tindex\tweight. Triples are stored 
		/// as IndexedTerms in a list
		/// </summary>
		private void LoadTerms()
		{
			Console.Write( "Loading Terms..." );
			string line = "";
			while( ( line = this.termsReader.ReadLine() ) != null )
			{
				string[] theSplit = line.Split( '\t' );
				this.indexedTermsList.Add( new IndexedTerm( theSplit[ 0 ], int.Parse( theSplit[ 1 ] ), float.Parse( theSplit[ 2 ] ) ) );
			}
			this.termsReader.Close();
			Console.WriteLine( " Done!" );
		}

		#endregion
		#region LoadMatrix
		/// <summary>
		/// Reads matrix.txt. There are 3 regions of vectors, term vectors, document vectors, 
		/// and singular values.  We don't care about document vectors. Term vectors are 
		/// stored as IndexedVectors in a list
		/// </summary>
		private void LoadMatrix()
		{		
			Console.Write( "Loading Matrix..." );
			matrixReader.ReadLine(); matrixReader.ReadLine();                      //header line..ignore
    
			string[] theSplit = matrixReader.ReadLine().Split( new char[] {',',' '} );

			this.numberDocuments = int.Parse( theSplit[ 1 ].Trim() );
			this.numberTerms = int.Parse( theSplit[ 4 ].Trim() );
			this.numberFactors = int.Parse( theSplit[ 7 ].Trim() );

			Console.Write( "Loading Terms Vectors..." );
			matrixReader.ReadLine();                                            // Term vectors ...
			ProcessTerms( this.numberTerms );

			Console.Write( "Skipping Document Vectors..." );
			matrixReader.ReadLine();                                            // Document vectors ...
			Skip( this.numberDocuments );

			Console.Write( "Loading Singular Values..." );
			matrixReader.ReadLine();                                            // Singular values...
			this.singularValues = GetNextVector();

			matrixReader.Close();
			Console.WriteLine( " Done!" );
		}

		/// <summary>
		/// A silly method to skip past the document vectors we don't care about
		/// </summary>
		/// <param name="vectors"></param>
		private void Skip( int vectors )
		{
			//Assume a maximum of 6 values per line
			int linesPerVector = (int) System.Math.Ceiling( this.numberFactors / 6.0 );
			int linesToSkip = vectors * linesPerVector;
			for( int i = 0; i < linesToSkip; i++ )
				this.matrixReader.ReadLine();
		}
	
		/// <summary>
		/// Turn the vectors in the terms region of the file into IndexedVectors and store them 
		/// in a list
		/// </summary>
		/// <param name="vectors"></param>
		private void ProcessTerms( int vectors ) 
		{
			for (int i = 0; i < vectors; i++) 
			{
				//index is i + 1 b/c terms.dat has a 1 based index
				this.indexedVectorsList.Add( new IndexedVector( i + 1, GetNextVector() ) );
			}	
		}
		/// <summary>
		/// A maximum of six floats per line, sometimes less, depending on 
		/// the number of dimensions. We're therefore cagey about reading 
		/// lines.
		/// </summary>
		/// <returns></returns>
		private float[] GetNextVector()
		{
			float[] aVector = new float[ this.numberFactors ];
	
			int index = 0;
			while( index < this.numberFactors )
			{
				string[] theSplit = this.matrixReader.ReadLine().Split( ' ' );
			
				foreach( string aFloat in theSplit )
				{
					if( aFloat.Trim() != "" )
						aVector[ index ] = float.Parse( aFloat.Trim() );
					index++;
				}
			}
			return aVector;
		}
		#endregion
		#region CreateTermHash
		/// <summary>
		/// Cross index the indexed lists of terms and vectors. Combine these two 
		/// redundant data structures into a non-redundant term hash
		/// </summary>
		private void CreateTermHash()
		{
			Console.Write( "Creating Term Hash..." );
			//Sanity check -- we should have a vector for every term
			if( this.indexedVectorsList.Count != this.indexedTermsList.Count )
				throw new System.ApplicationException( "There is not an equal number of terms and vectors" );

			//Sort the term list by index
			this.indexedTermsList.Sort();

			//Sort the matrix list by index
			this.indexedVectorsList.Sort();

			//Iterate over both lists, matching on index and populating the LSASpace hashtable
			for( int i = 0; i < this.indexedVectorsList.Count; i++ )
			{
				IndexedTerm indexedTerm = ( IndexedTerm ) this.indexedTermsList[ i ];
				IndexedVector indexedVector = ( IndexedVector ) this.indexedVectorsList[ i ];

				//Sanity check -- indexes should match
				if( indexedTerm.index != indexedVector.index )
					throw new System.ApplicationException( "The indexes for term " + indexedTerm.word + " at index " + indexedTerm.index + " do not match " );

				termHash.Add( indexedTerm.word, new Term( indexedTerm.scale, indexedVector.vector ) );
			}
			Console.WriteLine( " Done!" );
		}
		#endregion
		#endregion
		#region CreateLSASpace
		/// <summary>
		/// Populate the termHash with terms and vectors, then make a space. Note the added 
		/// features for tracking author, creation date, and documents used in the space
		/// </summary>
		/// <param name="spaceName"></param>
		/// <param name="author"></param>
		/// <param name="sourceDocumentDescription"></param>
		/// <returns></returns>
		public LSASpace CreateLSASpace( string spaceName, string author, string sourceDocumentDescription )
		{
			//Read in files, cross index terms with vectors, create term hash
			Populate();

			return new LSASpace( spaceName, author, sourceDocumentDescription, this.numberFactors, this.singularValues, this.termHash );
		}
		#endregion
		#region SerializeLSASpace
		/// <summary>
		/// The name of the file is automatically generated from the name and date of the space
		/// </summary>
		/// <param name="lsaSpace"></param>
		public void SerializeLSASpace( LSASpace lsaSpace )
		{
			string dateString = lsaSpace.creationDate.ToShortDateString().Replace( "/", "_" );
			System.IO.FileStream fs = new System.IO.FileStream( lsaSpace.spaceName + "_" + dateString + ".lsa", System.IO.FileMode.Create );
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			formatter.Serialize( fs, lsaSpace );
			fs.Close();
		}
		#endregion
		#region GetSourceFiles
		/// <summary>
		/// Given a directory name, returns a string of all the files in that directory, 
		/// with file extensions and spaces between file names. Convenient when calling 
		/// CreateLSASpace with lots of source files
		/// </summary>
		/// <param name="directoryName"></param>
		/// <returns></returns>
		public string GetSourceFiles( string directoryName )
		{
			//What files are in the space?
			System.IO.DirectoryInfo di = new System.IO.DirectoryInfo( directoryName );
			System.IO.FileInfo[] fi = di.GetFiles();
			string sourceFiles = "";
			foreach( System.IO.FileInfo info in fi )
				sourceFiles += " " + info.Name;
			return sourceFiles;
		}
		#endregion
		#region Generate Code for Custom ILSACalculator Implementations
		/// <summary>
		/// Unwrap loops/etc and build a custom LSACalculator class for this particular space. Should be 
		/// faster than the normal loops. Watch changing the namespaces or classnames of items in this 
		/// assembly -- it may break the code generated here.
		/// </summary>
		/// <param name="lsaSpace"></param>
		public void ImplementCustomILSACalculator( LSASpace lsaSpace )
		{
			string className = lsaSpace.spaceName + "_" + lsaSpace.creationDate.ToShortDateString().Replace( "/", "_" ) + "_ILSACalculatorImplementation";
			System.IO.StreamWriter writer = new System.IO.StreamWriter( className + ".cs" );
			#region Write Custom Class
			writer.WriteLine( @"//Dynamically created ILSACalculatorImplementation for space " + lsaSpace.spaceName + " on date " + lsaSpace.creationDate.ToShortDateString() );
			//Begin class
			writer.WriteLine( "using LSAModule;" );
			writer.WriteLine( "public class " + className + " : ILSACalculator" );
			writer.WriteLine( "{" );
			//Method Cosine
			writer.WriteLine( "\tpublic float Cosine( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat cosine = DotProduct( aVector, bVector ) / ( Length( aVector ) * Length( bVector ) );" );
			writer.WriteLine( "\t\treturn System.Single.IsNaN( cosine ) ? (float) 0 : cosine;" );
			writer.WriteLine( "\t}" );
			//Method Length
			writer.WriteLine( "\tpublic float Length( float[] aVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\treturn (float) System.Math.Sqrt( (double) DotProduct( aVector, aVector ) );" );
			writer.WriteLine( "\t}" );
			//Method DotProduct
			writer.WriteLine( "\tpublic float DotProduct( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.Write( "\t\treturn aVector[0] * bVector[0] " );
			for( int i = 1; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\t+ aVector[{0}] * bVector[{0}] ", i );
			writer.WriteLine(";");
			writer.WriteLine( "\t}" );
			//Method Normalized 
			writer.WriteLine( "\tpublic float[] Normalized( float[] aVector ) " );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			writer.WriteLine( "\t\tfloat length = Length( aVector );" );
			writer.WriteLine( "\t\tif (length > .00000001)" );
			writer.WriteLine( "\t\t{" );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\t\tresultVector[{0}] = aVector[{0}] / length; ", i );
			writer.WriteLine( "\t\t}" );
			writer.WriteLine( "\t\telse" );
			writer.WriteLine( "\t\t{" );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\t\tresultVector[{0}] = 0; ", i );
			writer.WriteLine( "\t\t}" );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//Method ElementWiseAddition
			writer.WriteLine( "\tpublic float[] ElementWiseAddition( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\tresultVector[{0}] = aVector[{0}] + bVector[{0}]; ", i );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//Method ElementWiseSubtraction
			writer.WriteLine( "\tpublic float[] ElementWiseSubtraction( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\tresultVector[{0}] = aVector[{0}] - bVector[{0}]; ", i );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//Method ParallelVectorToSpan
			writer.WriteLine( "\tpublic float[] ParallelVectorToSpan( float[] aVector, System.Collections.ArrayList aSpan )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] parallelVector = new float[{0}];", lsaSpace.numberDimensions );
			writer.WriteLine( "\t\tfor (int j = 0; j < aSpan.Count ; j ++)" );
			writer.WriteLine( "\t\t{" );
			writer.WriteLine( "\t\t\tfloat[] aSpanVector = (float[])aSpan[j];" );
			writer.WriteLine( "\t\t\tfloat dotP = DotProduct( aVector, aSpanVector);" );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\t\tparallelVector[{0}] +=  dotP * aSpanVector[{0}];", i );
			writer.WriteLine( "\t\t}" );
			writer.WriteLine( "\t\treturn parallelVector;" );
			writer.WriteLine( "\t}" );
			//Method ElementWiseMultiplication
			writer.WriteLine( "\tpublic float[] ElementWiseMultiplication( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\tresultVector[{0}] = aVector[{0}] * bVector[{0}]; ", i );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//Method ElementWiseDivision
			writer.WriteLine( "\tpublic float[] ElementWiseDivision( float[] aVector, float[] bVector )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\tresultVector[{0}] = aVector[{0}] / bVector[{0}]; ", i );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//Method ScalarMultiplication
			writer.WriteLine( "\tpublic float[] ScalarMultiplication( float[] aVector, float scalar )" );
			writer.WriteLine( "\t{" );
			writer.WriteLine( "\t\tfloat[] resultVector = new float[{0}];", lsaSpace.numberDimensions );
			for( int i = 0; i < lsaSpace.numberDimensions; i++ )
				writer.WriteLine( "\t\tresultVector[{0}] = aVector[{0}] * scalar; ", i );
			writer.WriteLine( "\t\treturn resultVector;" );
			writer.WriteLine( "\t}" );
			//End class
			writer.WriteLine( "}" );
			writer.Flush();
			writer.Close();
			#endregion
			#region Compile Custom Class
			System.Reflection.Assembly thisAssembly = System.Reflection.Assembly.GetExecutingAssembly();
			//Figure out where the runtime is installed and what the name of the executing assembly is (which provides reference to ILSACalculator and LSASpace, needed for compilation)
			string arguments = string.Format( @"/c {0}csc /optimize+ /target:library /reference:{1} {2}.cs > compile.out", System.Runtime.InteropServices.RuntimeEnvironment.GetRuntimeDirectory(), System.IO.Path.GetFileName( thisAssembly.Location ), className );
			System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo( "cmd.exe", arguments );
			psi.WindowStyle = System.Diagnostics.ProcessWindowStyle.Minimized;
			System.Diagnostics.Process process = System.Diagnostics.Process.Start( psi );
			process.WaitForExit();
			#endregion
		}
		#endregion
	}
}