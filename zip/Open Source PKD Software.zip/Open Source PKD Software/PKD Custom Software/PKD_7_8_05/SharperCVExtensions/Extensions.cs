/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using SharperCV;

namespace SharperCVExtensions
{
	/// <summary>
	/// Extensions is a wrapper class for PInvoked methods from OpenCV
	/// </summary>
	public class Extensions
	{
		#region Platform invoke methods
		/*
		 * UpdateMotionHistory
		void cvUpdateMotionHistory( const CvArr* S, CvArr* MHI, double timestamp, double duration );
		S
			Silhouette mask that has non-zero pixels where the motion occurs. 
		MHI
			Motion history image, that is updated by the function (single-channel, 32-bit floating-point) 
		timestamp
			Current time in milliseconds or other units. 
		duration
			Maximal duration of motion track in the same units as timestamp. 
			*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern void cvUpdateMotionHistory(System.IntPtr S, System.IntPtr MHI, double timestamp, double duration );

		/*
		void cvCalcMotionGradient( const CvArr* MHI, CvArr* mask, CvArr* orientation, double delta1, double delta2, int apertureSize=3 );
		MHI
			Motion history image. 
		mask
			Mask image; marks pixels where motion gradient data is correct. Output parameter. 
		orientation
			Motion gradient orientation image; contains angles from 0 to ~360�. 
		delta1, delta2
			The function finds minimum (m(x,y)) and maximum (M(x,y)) MHI values over each pixel (x,y) neihborhood and assumes the gradient is valid only if
			min(delta1,delta2) <= M(x,y)-m(x,y) <= max(delta1,delta2).
		apertureSize
			Aperture size of derivative operators used by the function: CV_SCHARR, 1, 3, 5 or 7 (see cvSobel). 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern void cvCalcMotionGradient(System.IntPtr MHI, System.IntPtr mask, System.IntPtr orientation, double delta1, double delta2, int aperatureSize );

		/*
		double cvCalcGlobalOrientation( const CvArr* orientation, const CvArr* mask, const CvArr* MHI, double currTimestamp, double mhiDuration );
		orientation
			Motion gradient orientation image; calculated by the function cvCalcMotionGradient. 
		mask
			Mask image. It may be a conjunction of valid gradient mask, obtained with cvCalcMotionGradient and mask of the region, whose direction needs to be calculated. 
		MHI
			Motion history image. 
		timestamp
			Current time in milliseconds or other units, it is better to store time passed to cvUpdateMotionHistory before and reuse it here, because running cvUpdateMotionHistory and cvCalcMotionGradient on large images may take some time. 
		duration
			Maximal duration of motion track in milliseconds, the same as in cvUpdateMotionHistory. 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern double cvCalcGlobalOrientation(System.IntPtr orientation, System.IntPtr mask, System.IntPtr MHI, double currTimestamp, double mhiDuration );

		/*
		CvSeq* cvSegmentMotion( const CvArr* MHI, CvArr* segMask, CvMemStorage* storage, double timestamp, double segthresh );
		mhi
			Motion history image. 
		segMask
			Image where the mask found should be stored, single-channel, 32-bit floating-point. 
		storage
			Memory storage that will contain a sequence of motion connected components. 
		timestamp
			Current time in milliseconds or other units. 
		segthresh
			Segmentation threshold; recommended to be equal to the interval between motion history "steps" or greater. 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern System.IntPtr cvSegmentMotion(System.IntPtr mhi, System.IntPtr segMash, System.IntPtr storage, double timestamp, double segthresh );

		/*
		 * void cvConvertScale( const CvArr* A, CvArr* B, double scale=1, double shift=0 );
		A
			Source array. 
		B
			Destination array. 
		scale
			Scale factor. 
		shift
			Value added to the scaled source array elements. 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern void cvConvertScale(System.IntPtr A, System.IntPtr B, double scale, double shift );

		/*
		void cvResize( const CvArr* I, CvArr* J, int interpolation=CV_INTER_LINEAR );
		I
			Source image. 
		J
			Destination image. 
		Interpolation method:
			* CV_INTER_NN - nearest-neigbor interpolation,
			* CV_INTER_LINEAR - bilinear interpolation (used by default) 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern void cvResize( System.IntPtr I, System.IntPtr J, int interpolation );

		/*
		 * void cvGetRawData( const CvArr* array, uchar** data, int* step, CvSize* roiSize );
			array
				Array header. 
			data
				Output pointer to the whole image origin or ROI origin if ROI is set. 
			step
				Output full row length in bytes. 
			roiSize
				Output ROI size. 
		*/
		[System.Runtime.InteropServices.DllImport("cv.dll", CallingConvention = System.Runtime.InteropServices.CallingConvention.Winapi, CharSet = System.Runtime.InteropServices.CharSet.Ansi)]
		public static extern void cvGetRawData( System.IntPtr array, System.IntPtr data, System.IntPtr step, System.IntPtr roiSize );

		#endregion
	}	
	#region My inherits from the SharperCV source
	/// <summary>
	/// Because ArrHandle is protected and its a pain to decompile the orginal CvImage class
	/// </summary>
	public class MyCvImage : SharperCV.CvImage
	{
		//Inherit constructors
		//static MyCvImage()

		public MyCvImage(SharperCV.CvSize size, SharperCV.BitDepths depth, int channels) : base ( size, depth, channels) {}
		public MyCvImage(string fileName, int isColor) : base( fileName, isColor ) {}
		public MyCvImage(string fileName) : base( fileName ) {}
		protected MyCvImage(System.IntPtr handle) : base( handle ) {}

		//public unsafe MyCvImage(double[] pts) : base( pts ) {}

		public System.IntPtr GetPixelAddress( int x, int y, int channel )
		{
			return base.getPixelAddr( x, y, channel );
		}
		public System.IntPtr myArrHandle
		{
			get
			{
				return this.ArrHandle;
			}
			set
			{
				this.ArrHandle = value;
			}
		}
	}
	public class MyCvMemStorage : SharperCV.CvMemStorage
	{
		public MyCvMemStorage() : base() {}
		public System.IntPtr myMemHandle
		{
			get
			{ 
				return this.myMemHandle;
			}
			set
			{
				this.myMemHandle = value;
			}
		}
	}
	#endregion
}
