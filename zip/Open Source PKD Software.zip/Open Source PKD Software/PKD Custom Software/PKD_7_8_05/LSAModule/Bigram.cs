/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// A Hashtable of hashtables containing frequencies. Key (previous word, current word). <s> and </s> match 
	/// the end of a sentence, <t> and </t> match the end of a turn.
	/// </summary>
	[Serializable]
	public class Bigrams
	{
		System.Collections.Hashtable previousWordHash = null;
		int numberTokens = 0;
	
		public Bigrams()
		{
			this.previousWordHash = new System.Collections.Hashtable();
		}

		/// <summary>
		/// Increment the count of a bigram
		/// </summary>
		/// <param name="previousWord"></param>
		/// <param name="currentWord"></param>
		public void Count( string previousWord, string currentWord )
		{
			this.numberTokens++;

			if( this.previousWordHash.ContainsKey( previousWord ) )
			{
				//Get the associated hashtable
				System.Collections.Hashtable currentWordHash = ( System.Collections.Hashtable ) this.previousWordHash[ previousWord ];
				if( currentWordHash.ContainsKey( currentWord ) )
				{
					float frequency = ( float ) currentWordHash[ currentWord ];
					currentWordHash[ currentWord ] = frequency + 1;
				}
				else
				{
					currentWordHash.Add( currentWord, (float)1 );
				}
				this.previousWordHash[ previousWord ] = currentWordHash;
			}
			else
			{
				//Create a hashtable for previous word
				System.Collections.Hashtable currentWordHash = new System.Collections.Hashtable();
				currentWordHash.Add( currentWord, (float)1 );
				this.previousWordHash.Add( previousWord, currentWordHash );
			}
		}
		/// <summary>
		/// Currently uses Witten-Bell smoothing
		/// </summary>
		public void Smooth()
		{
			//B/c we can modify the hashtable we are enumerating
			System.Collections.Hashtable smoothPreviousWordHash = new System.Collections.Hashtable( this.previousWordHash );

			foreach( string previousWord in this.previousWordHash.Keys )
			{
				System.Collections.Hashtable currentWordHash = ( System.Collections.Hashtable ) this.previousWordHash[ previousWord ];
				System.Collections.Hashtable smoothCurrentWordHash = new System.Collections.Hashtable( currentWordHash );

				//Calculate values used in smoothing
				int typesStartingWithPreviousWord = currentWordHash.Count;
				float tokensStartingWithPreviousWord = 0;
				foreach( string currentWord in currentWordHash.Keys )
					tokensStartingWithPreviousWord += ( float ) currentWordHash[ currentWord ];
				int unseenBigramsStartingWithPreviousWord = this.previousWordHash.Count - typesStartingWithPreviousWord;

				//Create an "unseen" frequency for all unseen bigrams that begin with previousWord
				float unseenFrequency = ( float )typesStartingWithPreviousWord / ( unseenBigramsStartingWithPreviousWord * ( this.numberTokens + typesStartingWithPreviousWord ) );
				smoothCurrentWordHash.Add( "*", unseenFrequency );

				//Now discount all the bigrams that did occur so that the total probability mass is one
				foreach( System.Collections.DictionaryEntry entry in currentWordHash )
				{
					float frequency = ( float ) entry.Value;
					frequency = frequency / ( tokensStartingWithPreviousWord + typesStartingWithPreviousWord );
					smoothCurrentWordHash[ entry.Key ] = frequency;
				}
				smoothPreviousWordHash[ previousWord ] = smoothCurrentWordHash;
			}
			this.previousWordHash = smoothPreviousWordHash;
		}

		/// <summary>
		/// A convenient way to access the hashtable for the values we are interested in
		/// </summary>
		/// <param name="previousWord"></param>
		/// <param name="currentWord"></param>
		/// <returns></returns>
		public float GetProbablity( string previousWord, string currentWord )
		{
			if( this.previousWordHash.ContainsKey( previousWord ) )
			{
				System.Collections.Hashtable currentWordHash = ( System.Collections.Hashtable ) this.previousWordHash[ previousWord ];
				//This bigram has occured
				if( currentWordHash.ContainsKey( currentWord ) )
					return ( float ) currentWordHash[ currentWord ];
				//This bigram never occurred -- we return the frequency of the unknown "*"
				else
					return ( float ) currentWordHash[ "*" ];
			}
			//This will never happen in the pkd application
			return ( float ) 0;
		}
	}
}
