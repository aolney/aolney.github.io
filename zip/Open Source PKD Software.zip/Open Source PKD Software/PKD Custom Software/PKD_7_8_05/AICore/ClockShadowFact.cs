/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace AICore
{
	/// <summary>
	/// We need a clock to keep track of how long certain events have lasted
	/// </summary>
	public class ClockShadowFact : PKDPlugin.ShadowFact
	{
		#region Fields / Constructor
		public int minute;
		public int hour;
		public int day;
		public int month;
		public int year;
		public int elapsedMinutes;

		//probably don't belong here, but they make the rules simpler
		public bool isAlone;
		public int minutesAlone;

		public System.TimeSpan timeSpan;

		public ClockShadowFact()
		{
			//We only update in one minute increments by default
			this.timeSpan = new TimeSpan( 0, 1, 0 );

			System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
			thread.Start();			
		}

		#endregion
		/// <summary>
		/// We only care about time increments of one minute
		/// </summary>
		public void Run()
		{
			System.DateTime now = System.DateTime.Now;
			while( true )
			{
				now = System.DateTime.Now;

				//Fire off events so that the jess shadowfact is updated
				propertyChangeSupport.firePropertyChange( "minute", this.minute, now.Minute );
				propertyChangeSupport.firePropertyChange( "hour", this.hour, now.Hour );
				propertyChangeSupport.firePropertyChange( "day", this.day, now.Day );
				propertyChangeSupport.firePropertyChange( "month", this.month, now.Month );
				propertyChangeSupport.firePropertyChange( "year", this.year, now.Year );
				propertyChangeSupport.firePropertyChange( "elapsedminutes", this.elapsedMinutes, this.elapsedMinutes + 1 );

				if( this.isAlone )
				{
					this.propertyChangeSupport.firePropertyChange( "minutesalone", this.minutesAlone, this.minutesAlone + 1 );
					this.minutesAlone++;
				}
				//Update our fields with the new values
				this.minute = now.Minute;
				this.hour = now.Hour;
				this.day = now.Day;
				this.month = now.Month;
				this.year = now.Year;
				this.elapsedMinutes++;

				System.Threading.Thread.Sleep( this.timeSpan );
			}
		}
		#region ShadowFact Accessors
		public int getMinute()
		{
			return this.minute;
		}
		public int getHour()
		{
			return this.hour;
		}
		public int getDay()
		{
			return this.day;
		}
		public int getMonth()
		{
			return this.month;
		}
		public int getYear()
		{
			return this.year;
		}

		public int getElapsedminutes()
		{
			return this.elapsedMinutes;
		}
		public void setElapsedminutes( int minutes )
		{
			this.propertyChangeSupport.firePropertyChange( "elapsedminutes", this.elapsedMinutes, minutes );
			this.elapsedMinutes = minutes;
		}

		public bool getIsalone()
		{
			return this.isAlone;
		}
		/// <summary>
		/// Sets isalone flag to true and sets minutes alone to zero
		/// </summary>
		/// <param name="theBool"></param>
		public void setIsalone( bool theBool )
		{
			this.propertyChangeSupport.firePropertyChange( "isalone", this.isAlone, theBool );
			this.propertyChangeSupport.firePropertyChange( "minutesalone", this.minutesAlone, 0 );
			this.isAlone = theBool;
			this.minutesAlone = 0;
		}

		public int getMinutesalone()
		{
			return this.minutesAlone;
		}
		public void setMinutesalone( int minutes )
		{
			this.propertyChangeSupport.firePropertyChange( "minutesalone", this.minutesAlone, minutes );
			this.minutesAlone = minutes;
		}
		#endregion
	}
}
