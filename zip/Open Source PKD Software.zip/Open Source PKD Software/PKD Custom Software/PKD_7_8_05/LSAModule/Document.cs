/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// Composite design pattern. A document can be atomic, or a recursive collection of subdocuments
	/// </summary>
	[Serializable]
	public abstract class AbstractDocument : IComparable
	{
		public int index;		
		public string text;
		public float[] vector;
		public float informativity = 0;
		public float relevance = 0;
		public float sortingValue;		//Not persistent storage

		// Constructors
		public AbstractDocument( int index, string text, float[] vector )
		{
			this.index = index;
			this.text = text;
			this.vector = vector;
		}
		#region IComparable Members
		public int CompareTo(object obj)
		{
			AbstractDocument document = obj as AbstractDocument;
			if( document != null ) 
			{
				return this.sortingValue.CompareTo( document.sortingValue );
			}
			else
				throw new ArgumentException("object is not an AbstractDocument");
		}
		#endregion
	}

	[Serializable]
	public class DocumentCollection : AbstractDocument
	{
		public System.Collections.ArrayList children = new System.Collections.ArrayList();

		public DocumentCollection( int index, string text, float[] vector ) : base( index, text, vector ) {}
	}

	[Serializable]
	public class Document : AbstractDocument
	{
		public Document( int index, string text, float[] vector ) : base( index, text, vector ) {}
	}	
}