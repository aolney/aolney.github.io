/*
Copyright (c) 2009, Andrew M Olney
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the University of Memphis nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace TopicModel
{
    /// <summary>
    /// Generalizing topic models, consider a data set where:
    /// 1. The data set is made up of samples
    /// 2. Each sample is a set of tokens
    /// 3. Some tokens appear in multiple samples
    /// 
    /// The goal is to find categories such that we can define
    /// 1. a probability distribution of tokens for each category
    /// 2. a probability distribution of categories for each sample
    /// 
    /// In the case of the netflix prize, each sample is a customer, and the 
    /// tokens are the movies seen by that customer.
    /// </summary>
    [Serializable]
    public sealed class FastParallelTopicModel
    {
        public DataSet.DataSet dataSet;
        public CenterSpace.Free.MersenneTwister twister;

        /// <summary>
        /// NOTE: assuming that we want only 255 categories here to save space
        /// </summary>
        public byte[] categoryForToken; // 1 x number of tokens: each cell is a topic index assigned to this token
        
        //To make things faster, we change these to 1 dimensional arrays
        //public int[,] countTypeCategory; //T x C: times type is assigned to category (not inc current instance)
        //public int[,] countSampleCategory; //S x C: times category is assigned to a token in sample (not inc current instance)
        public int[] countTypeCategory;
        public int[] countSampleCategory;

        public int[] countTokenCategory; //1 x C: number of tokens assigned to this category

        //These can stay 2 dimensional: we really don't use them much
        public double[,] thetaStats;
        public double[,] phiStats;

        public int numberCategories;
        public double beta;
        public double alpha;
        public System.Random random;
        public int countTypes;
        public int iterations;
        public int burnIn;
        public int sampleLag;

        public int changesThisIteration; //to measure convergence

        public FastParallelTopicModel(DataSet.DataSet dataSet, int numberCategories, double alpha, double beta, int iterations, int burnIn, int sampleLag)
        {
            this.dataSet = dataSet;
            this.numberCategories = numberCategories;
            this.beta = beta;
            this.alpha = alpha;

            this.thetaStats = new double[this.dataSet.sampleHash.Count, numberCategories];
            this.phiStats = new double[this.dataSet.typeHash.Count, numberCategories];

            this.categoryForToken = new byte[this.dataSet.sampleAtToken.Length];
            
            //this.countTypeCategory = new int[this.dataSet.typeHash.Count, numberCategories];
            //this.countSampleCategory = new int[this.dataSet.sampleHash.Count, numberCategories];
            this.countTypeCategory = new int[this.dataSet.typeHash.Count * numberCategories];
            this.countSampleCategory = new int[this.dataSet.sampleHash.Count * numberCategories];
            
            this.countTokenCategory = new int[numberCategories];

            //to make things easier to read
            this.countTypes = this.dataSet.typeHash.Count;

            this.twister = new CenterSpace.Free.MersenneTwister();
            this.random = new Random(); //perhaps faster than twister?

            this.iterations = iterations;
            this.sampleLag = sampleLag;
            this.burnIn = burnIn;
        }

        public void RandomInitialization()
        {
            //-------------------------------------
            //randomly assign a category to each token
            //-------------------------------------
            System.Console.WriteLine("Randomly assigning a category to each token");
            int randomCategory = twister.Next(numberCategories);

            int i, nnz = dataSet.typeAtToken.Length;
            for (i = 0; i < nnz; i++)
            {
                //our random assignment
                randomCategory = twister.Next(numberCategories - 1);
                categoryForToken[i] = (byte)randomCategory;
            }          
        }

        public void LoadInitialization( string filename )
        {
            System.Console.WriteLine("Loading categories for each token");

            this.categoryForToken = (byte[])VectorSpace.Utility.Deserialize(filename);
        }

        public void ParallelGibbsEstimation(int numberThreads )
        {
            int numStats = 0;
            int typeIndex, sampleIndex, category;
            int i, nnz = dataSet.typeAtToken.Length;
            
            //adjust the counts: we've initialized this.categoryForToken elsewhere
            for (i = 0; i < nnz; i++)
            {
                typeIndex = dataSet.typeAtToken[i];
                sampleIndex = dataSet.sampleAtToken[i];
                category = this.categoryForToken[i];

                //countSampleCategory[sampleIndex, category]++;
                //countTypeCategory[typeIndex, category]++;

                countSampleCategory[sampleIndex * this.numberCategories + category]++;
                countTypeCategory[typeIndex * this.numberCategories + category]++;

                countTokenCategory[category]++;
            }

            //-------------------------------------
            // Gibbs sample with burnIn
            //-------------------------------------
            System.Console.WriteLine("Begin Gibbs sampling");

            int k, j;

            //parallel stuff
            int chunkSize = nnz / numberThreads;
            int start, end;

            System.Collections.ArrayList threadList = new System.Collections.ArrayList();

            for (i = 0; i < this.iterations; i++)
            {
                

                //if( i % 100 ==0 ) 
                System.Console.WriteLine(i + ":\t" + System.DateTime.Now + "\t " + this.changesThisIteration);
                this.changesThisIteration = 0;

                //start some threads, evenly splitting up the work
                //This might be faster with the thread pool if we had a lot of processors
                System.Threading.Thread thread;

                threadList = new System.Collections.ArrayList();
                for (j = 0; j < numberThreads - 1; j++)
                {
                    start = j * chunkSize;
                    end = ((j + 1) * chunkSize) - 1;
                    thread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(this.ParallelChunk));
                    thread.Start(new Chunk(start, end));
                    threadList.Add(thread);
                }
                //last thread has odd size
                start = j * chunkSize;
                end = nnz;
                thread = new System.Threading.Thread(new System.Threading.ParameterizedThreadStart(this.ParallelChunk));
                thread.Start(new Chunk(start, end));
                threadList.Add(thread);

                //wait for the threads to finish
                foreach (System.Threading.Thread t in threadList)
                    t.Join();

                //save samples after burnin at regular intervals
                if (i > burnIn && (i % sampleLag == 0))
                {

                    Console.WriteLine("Saving sample at iteration " + i);
                    for (k = 0; k < numberCategories; k++)
                    {
                        //for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                        //    thetaStats[m, k] += (countSampleCategory[m, k] + alpha) /
                        //                 (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                        //for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                        //    phiStats[n, k] += (countTypeCategory[n, k] + beta) /
                        //                (countTokenCategory[k] + countTypes * beta);

                        for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                            thetaStats[m, k] += (countSampleCategory[m * this.numberCategories + k] + alpha) /
                                         (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                        for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                            phiStats[n, k] += (countTypeCategory[n * this.numberCategories + k] + beta) /
                                        (countTokenCategory[k] + countTypes * beta);
                    }
                    numStats++;

                    WriteStats(thetaStats, phiStats, numStats, "");
                    
                }

                if (i % 10 == 0)
                {
                    this.CorrectNoise();
                    //WriteStats(thetaStats, phiStats, numStats, "temp_" );
                }
            }

            #region Calculate theta and phi from Gibbs sample
            //-------------------------------------------
            // Calculate theta and phi from Gibbs sample
            //-------------------------------------------
            //averages first
            double[,] theta = new double[thetaStats.GetLength(0), thetaStats.GetLength(1)];
            double[,] phi = new double[phiStats.GetLength(0), phiStats.GetLength(1)];

            for (k = 0; k < numberCategories; k++)
            {
                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m, k] = thetaStats[m, k] / numStats;

                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n, k] = phiStats[n, k] / numStats;
            }
            VectorSpace.Utility.Serialize("average_theta.dat", theta);
            VectorSpace.Utility.Serialize("average_phi.dat", phi);

            //final values
            for (k = 0; k < numberCategories; k++)
            {
                //for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                //    theta[m, k] = (countSampleCategory[m, k] + alpha) /
                //                 (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                //for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                //    phi[n, k] = (countTypeCategory[n, k] + beta) /
                //                (countTokenCategory[k] + countTypes * beta);

                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m, k] = (countSampleCategory[m * this.numberCategories + k] + alpha) /
                                 (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n, k] = (countTypeCategory[n * this.numberCategories + k] + beta) /
                                (countTokenCategory[k] + countTypes * beta);
            }
            VectorSpace.Utility.Serialize("final_theta.dat", theta);
            VectorSpace.Utility.Serialize("final_phi.dat", phi);

            //Save everything else
            VectorSpace.Utility.Serialize("categoryForToken.dat", categoryForToken);

            VectorSpace.Utility.Serialize("countTypeCategory.dat", countTypeCategory);
            VectorSpace.Utility.Serialize("countSampleCategory.dat", countSampleCategory);
            VectorSpace.Utility.Serialize("countTokenCategory.dat", countTokenCategory);
            #endregion
        }

        public void WriteStats(double[,] thetaStats, double[,] phiStats, int numStats, string prefix)
        {
            //averages first
            double[,] theta = new double[thetaStats.GetLength(0), thetaStats.GetLength(1)];
            double[,] phi = new double[phiStats.GetLength(0), phiStats.GetLength(1)];

            for (int k = 0; k < numberCategories; k++)
            {
                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m, k] = thetaStats[m, k] / numStats;

                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n, k] = phiStats[n, k] / numStats;
            }
            VectorSpace.Utility.Serialize(prefix + "average_theta.dat", theta);
            VectorSpace.Utility.Serialize(prefix + "average_phi.dat", phi);

            //will slow things down, but better safe than sorry
            VectorSpace.Utility.Serialize(prefix + "categoryForToken.dat", categoryForToken);
        }

        public void ParallelChunk(object o)// int start, int end )
        {
            byte category,startingCategory;
            int sample, type, k, j;
            //int last = numberCategories - 1;
            double[] p;
            double u;
            double totalP, accumulator;
            
            Chunk chunk = (Chunk)o;
            double countTypesTimesBeta = this.countTypes * beta;

            System.Random threadRandom = new Random();

            for (j = chunk.start; j < chunk.end; j++)
            {
                //to make things easier to read
                category = categoryForToken[j];
                sample = this.dataSet.sampleAtToken[j];
                type = this.dataSet.typeAtToken[j];

                startingCategory = category;
                //remove current instance from consideration
                
                    //countSampleCategory[sample, category]--;
                    //countTypeCategory[type, category]--;
                    countSampleCategory[sample * this.numberCategories + category]--;
                    countTypeCategory[type * this.numberCategories + category]--;
                    countTokenCategory[category]--;
                    //this.dataSet.tokensInSample[sample]--;

                    //do sampling
                    p = new double[numberCategories];
                    totalP = 0;
                    for (k = 0; k < numberCategories; k++)
                    {
                        //p[k] = ((countTypeCategory[type, k] + beta) / (countTokenCategory[k] + countTypesTimesBeta))
                        //    * ((countSampleCategory[sample, k] + alpha)); // McCallum says this is optional, since it is constant across categories: / (this.dataSet.tokensInSample[sample] + numberCategories * alpha));
                        p[k] = ((countTypeCategory[type * this.numberCategories + k] + beta) / (countTokenCategory[k] + countTypesTimesBeta))
                            * ((countSampleCategory[sample * this.numberCategories + k] + alpha)); // McCallum says this is optional, since it is constant across categories: / (this.dataSet.tokensInSample[sample] + numberCategories * alpha));
                        
                        totalP += p[k];
                    }
                    //cumulate parameters
                    //for (k = 1; k < p.Length; k++)
                    //    p[k] += p[k - 1];

                    // scale sample (p[] unnormalized)
                    //neither of our randomization methods are thread safe. Bummer
                    //lock (this.random)
                    //{
                        //u = twister.NextDouble() * p[last];
                        //u = this.random.NextDouble() * totalP; //p[last];
                    //}
                    u = threadRandom.NextDouble() * totalP; 
               
                    accumulator = p[0];
                    category = 0;
                    while (u > accumulator)
                    {
                        category++;
                        accumulator += p[category];
                    }
                    //for (category = 0; category < p.Length; category++)
                    //    if (u < p[category]) break;

                    //sanity check
                    if (category == this.numberCategories)
                        category--;

                    //countSampleCategory[sample, category]++;
                    //countTypeCategory[type, category]++;
                    countSampleCategory[sample * this.numberCategories + category]++;
                    countTypeCategory[type * this.numberCategories + category]++;
                    countTokenCategory[category]++;
                    //this.dataSet.tokensInSample[sample]++;
               

                categoryForToken[j] = category;

                if (startingCategory != category)
                    this.changesThisIteration++;
                //if (categoryForToken[j] == 0 && categoryForToken[j - 1] == 0 && j > 1)
                 //   Console.WriteLine(j);
            }
        }


        public void CorrectNoise()
        {
            int nnz = this.dataSet.typeAtToken.Length;
            int category, sample, type;

            //clear out current estimates
            //this.countTypeCategory = new int[this.dataSet.typeHash.Count, this.numberCategories];
            //this.countSampleCategory = new int[this.dataSet.sampleHash.Count, this.numberCategories];
            this.countTypeCategory = new int[this.dataSet.typeHash.Count * this.numberCategories];
            this.countSampleCategory = new int[this.dataSet.sampleHash.Count * this.numberCategories];
            this.countTokenCategory = new int[this.numberCategories];

            for (int i = 0; i < nnz; i++)
            {
                type = dataSet.typeAtToken[i];
                sample = dataSet.sampleAtToken[i];
                category = this.categoryForToken[i];

                //this.countSampleCategory[sample, category]++;
                //this.countTypeCategory[type, category]++;
                this.countSampleCategory[sample * this.numberCategories + category]++;
                this.countTypeCategory[type * this.numberCategories + category]++;
                this.countTokenCategory[category]++;
            }
        }
    }

    //public class Chunk
    //{
    //    public int start;
    //    public int end;

    //    public Chunk(int start, int end)
    //    {
    //        this.start = start;
    //        this.end = end;
    //    }
    //}
}
