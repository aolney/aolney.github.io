/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace LSAModule
{
	/// <summary>
	/// Semantic analyzer does high level (string to string) semantic analysis
	/// </summary>
	public class SemanticAnalyzer
	{
		public LSASpace lsaSpace = null;
		public ILSACalculator lsaCalculator = null;
		#region Constructors
		public SemanticAnalyzer( ILSACalculator lsaCalculator )
		{
			this.lsaCalculator = lsaCalculator;
		}
		public SemanticAnalyzer( string lsaFileName, ILSACalculator lsaCalculator )
		{
			this.lsaCalculator = lsaCalculator;
			this.InitializeSpace( lsaFileName );
		}
		#endregion
		#region Comparison / Calculation
		public float CompareTwoStrings( string aString, string bString )
		{
			float[] aVector = GetVector( aString );
			float[] bVector = GetVector( bString );
			return this.lsaCalculator.Cosine( aVector, bVector );
		}

		public float CompareTwoStringsWithLocalWeighting( string aString, string bString )
		{
			float[] aVector = GetLocalWeightedVector( aString );
			float[] bVector = GetLocalWeightedVector( bString );
			return this.lsaCalculator.Cosine( aVector, bVector );
		}

		/// <summary>
		/// No local weighting in this calculation
		/// </summary>
		/// <param name="aString"></param>
		/// <returns></returns>
		public float[] GetVector( string text )
		{
			string[] theSplit = text.ToLower().Split(' ');
			float[] resultVector = new float[ this.lsaSpace.numberDimensions ];
			for( int i = 0; i < theSplit.Length; i++ )
			{
				Term term = ( Term ) lsaSpace.termHash[ theSplit[ i ] ];
				if( term != null )
					resultVector = this.lsaCalculator.ElementWiseAddition( resultVector, term.vector );
			}
			return resultVector;
		}
		public float[] GetLocalWeightedVector( string text )
		{
			//find the frequencies of the words in the text
			string[] theSplit = text.ToLower().Split(' ');
			System.Collections.Hashtable frequencyHash = new System.Collections.Hashtable();
			for( int i = 0; i < theSplit.Length; i++ )
			{
				if( frequencyHash.ContainsKey( theSplit[ i ] ) )
					frequencyHash[ theSplit[ i ] ] = (int)frequencyHash[ theSplit[ i ] ] + 1;
				else
					frequencyHash[ theSplit[ i ] ] = 1;
			}
			//Weight by the frequency in the hash
			float[] resultVector = new float[ this.lsaSpace.numberDimensions ];
			foreach( string key in frequencyHash.Keys )
			{
				Term term = ( Term ) lsaSpace.termHash[ key ];
				if( term != null )
				{
					//scale by frequency and add to result vector
					resultVector = this.lsaCalculator.ElementWiseAddition( resultVector, this.lsaCalculator.ScalarMultiplication( term.vector, (float)Math.Log( (int)frequencyHash[ key ] + 1 ) ) );
				}
			}
			return resultVector;
		}

		#region Orthonormal Basis
		/// <summary>
		/// Takes a string, splits on whitespace, decomposes each word to the basis, and returns the basis. It's a little 
		/// bit obfuscated for speed -- check out one of the other decomposition methods for a clearer picture of the algorithm.
		/// </summary>
		/// <param name="text"></param>
		/// <returns></returns>
		public System.Collections.ArrayList WordsToBasis( string text )
		{
			System.Collections.ArrayList basis = new System.Collections.ArrayList();

			string[] theSplit = text.ToLower().Split(' ');
			Term term = null;
			for( int i = 0; i < theSplit.Length; i++ )
			{
				term = ( Term ) lsaSpace.termHash[ theSplit[ i ] ];
				if( term != null )
				{
					basis.Add( this.lsaCalculator.Normalized( this.lsaCalculator.ElementWiseSubtraction( term.vector, this.lsaCalculator.ParallelVectorToSpan( term.vector, basis ) ) ) );
				}
			}
			return basis;
		}
		/// <summary>
		/// A generic decomposition, taking a vector to be decomposed and a basis, returning the 
		/// residual (length of the perpendicular component)
		/// </summary>
		/// <param name="vector"></param>
		/// <param name="basis"></param>
		/// <returns></returns>
		public float DecomposeReturnInformativity( float[] vector, System.Collections.ArrayList basis ) 
		{
			float[] parallelVector = this.lsaCalculator.ParallelVectorToSpan( vector, basis );
			float[] perpendicularVector = this.lsaCalculator.ElementWiseSubtraction( vector, parallelVector );
			float[] normalizedPerpendicular = this.lsaCalculator.Normalized( perpendicularVector );
			basis.Add( normalizedPerpendicular );
			return lsaCalculator.Length( perpendicularVector ) / lsaCalculator.Length( vector );
		}

		/// <summary>
		/// Decompose a word to the basis and only return relevance (cosine of vector to parallel component of projection
		/// Don't add perpendicular component to basis
		/// </summary>
		/// <param name="vector"></param>
		/// <param name="basis"></param>
		/// <returns></returns>
		public float QuickDecomposeReturnRelevance( float[] vector, System.Collections.ArrayList basis ) 
		{
			return this.lsaCalculator.Cosine( this.lsaCalculator.ParallelVectorToSpan( vector, basis ), vector );
		}

		/// <summary>
		/// Don't update the basis. 
		/// </summary>
		/// <param name="vector"></param>
		/// <param name="basis"></param>
		/// <returns></returns>
		public float[] QuickDecomposeReturnRelevanceAndInformativity( float[] vector, System.Collections.ArrayList basis ) 
		{
			float[] parallelVector = this.lsaCalculator.ParallelVectorToSpan( vector, basis );
			float[] perpendicularVector = this.lsaCalculator.ElementWiseSubtraction( vector, parallelVector );
			float[] normalizedPerpendicular = this.lsaCalculator.Normalized( perpendicularVector );
			return new float[] { lsaCalculator.Cosine( parallelVector, vector ), lsaCalculator.Length( perpendicularVector ) / lsaCalculator.Length( vector ) };
		}

		/// <summary>
		/// Decompose and return both cohesion values
		/// </summary>
		/// <param name="vector"></param>
		/// <param name="basis"></param>
		/// <returns></returns>
		public float[] DecomposeReturnRelevanceAndInformativity( float[] vector, System.Collections.ArrayList basis ) 
		{
			float[] parallelVector = this.lsaCalculator.ParallelVectorToSpan( vector, basis );
			float[] perpendicularVector = this.lsaCalculator.ElementWiseSubtraction( vector, parallelVector );
			float[] normalizedPerpendicular = this.lsaCalculator.Normalized( perpendicularVector );
			basis.Add( normalizedPerpendicular );
			return new float[] { lsaCalculator.Cosine( parallelVector, vector ), lsaCalculator.Length( perpendicularVector ) / lsaCalculator.Length( vector ) };
		}

		/// <summary>
		/// A decomposition specific to a the AbstractDocument class, which has fields for informativity 
		/// and relevance
		/// </summary>
		/// <param name="abstractDocument"></param>
		/// <param name="basis"></param>
		public void DecomposeDocument( AbstractDocument abstractDocument, System.Collections.ArrayList basis ) 
		{
			float[] parallelVector = this.lsaCalculator.ParallelVectorToSpan( abstractDocument.vector, basis );
			float[] perpendicularVector = this.lsaCalculator.ElementWiseSubtraction( abstractDocument.vector, parallelVector );
			float[] normalizedPerpendicular = this.lsaCalculator.Normalized( perpendicularVector );
			basis.Add( normalizedPerpendicular );
			abstractDocument.informativity = lsaCalculator.Length( perpendicularVector ) / lsaCalculator.Length( abstractDocument.vector );
			abstractDocument.relevance = lsaCalculator.Cosine( parallelVector, abstractDocument.vector );
		}
		#endregion
		#endregion
		#region Information Retrieval
		/// <summary>
		/// Calculate cosine between this document and all documents in the collection
		/// </summary>
		/// <param name="queryDocument"></param>
		/// <param name="allDocuments"></param>
		/// <param name="N"></param>
		/// <returns></returns>
		public System.Collections.ArrayList GetTopNMatchingDocuments( AbstractDocument queryDocument, System.Collections.ArrayList allDocuments, int N )
		{
			int numDocuments = allDocuments.Count;

			//Caculate cosine of every element in the collection with the document
			for( int i = 0; i < numDocuments; i++ )
			{
				AbstractDocument document = ( AbstractDocument ) allDocuments[ i ];
				document.sortingValue = this.lsaCalculator.Cosine( queryDocument.vector, document.vector );
			}
			
			//Use the framework's handy quicksorting ability
			allDocuments.Sort();

			return new System.Collections.ArrayList( allDocuments ).GetRange( 0, N );
		}
		#endregion
		#region Update LSA space
		public void InitializeSpace( string fileName )
		{
			ReadLSASpaceFromFile( fileName );
			ScaleLSASpaceByGlobalWeights();
			ScaleLSASpaceBySingularValues();
		}
		public void ReadLSASpaceFromFile( string fileName )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Open);
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			this.lsaSpace = ( LSASpace )formatter.Deserialize( fs );
			fs.Close();
		}
		public void ScaleLSASpaceByGlobalWeights()
		{
			foreach( Term term in this.lsaSpace.termHash.Values )
			{
				term.vector = this.lsaCalculator.ScalarMultiplication( term.vector, term.scale );
			}
		}
		public void ScaleLSASpaceBySingularValues()
		{
			foreach( Term term in this.lsaSpace.termHash.Values )
			{
				term.vector = this.lsaCalculator.ElementWiseDivision( term.vector, this.lsaSpace.singularValues );
			}
		}
		public void Serialize( string fileName, object o )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Create );
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			formatter.Serialize( fs, o );
			fs.Close();
		}
		public object Deserialize( string fileName )
		{
			System.IO.FileStream fs = new System.IO.FileStream( fileName, System.IO.FileMode.Open );
			System.Runtime.Serialization.Formatters.Binary.BinaryFormatter formatter = new System.Runtime.Serialization.Formatters.Binary.BinaryFormatter();
			object o = formatter.Deserialize( fs );
			fs.Close();
			return o;
		}
		#endregion
	}
}
