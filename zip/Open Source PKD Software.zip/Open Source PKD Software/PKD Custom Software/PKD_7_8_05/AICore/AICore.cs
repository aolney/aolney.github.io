/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using System.Runtime.Remoting.Channels;
using Ch.Elca.Iiop;
using Ch.Elca.Iiop.Services;
using omg.org.CosNaming;

namespace AICore
{
	/// <summary>
	/// Kind of like a facade, giving access to all the other pieces in the system.
	/// </summary>
	public class AICore
	{
		#region Fields / Constructor
		//Jess related
		public jess.Rete ruleEngine;
		/// <summary>
		/// Potentially, it is a good idea to keep track of the facts, but this is not currently
		/// in use -- we're only using shadowfacts, and they work a little differently
		/// </summary>
		public System.Collections.ArrayList ruleEngineFacts;
		public pkd.jess.JessTabShell ontologyEngine;

		//Plugin related
		public PKDPlugin.PluginManager pluginManager;

		public ClockShadowFact clock;

		//NLG related
		public PKDDialogue.NLG nlg;
		
		public string microphoneDevice = "AK5370"; // "Plantronics Headset"; //"AK5370"; //"Plantronics Headset";

		public AICore()
		{
		
			Console.Write( "Loading JessSharp..." );
			this.ruleEngine = new jess.Rete();
			Console.WriteLine( "\t\tDONE!" );

			Console.Write( "Loading PluginManager..." );
			this.pluginManager = new PKDPlugin.PluginManager();	
			Console.WriteLine( "\tDONE!" );
			
			Console.Write( "Loading Clock..." );
			this.clock = new ClockShadowFact();
			Type t = clock.GetType();
			string name = "cli." + t.FullName;
			this.ruleEngine.defclass( t.Name, name, null );
			this.ruleEngine.definstance( t.Name, clock, true );
			Console.WriteLine( "\t\tDONE!" );
			
			this.nlg = new PKDDialogue.NLG();
			this.nlg.microphoneDevice = this.microphoneDevice; //HACK
			
			this.ruleEngineFacts = new System.Collections.ArrayList();
		}
		#endregion
		#region Methods
		#region Ontology Engine
		/// <summary>
		/// We use a CORBA style remoting to connect to a java rmi server which presents an interface 
		/// to a java instatiation of JessTab (jess + protege), i.e. we instantiate an ontology database and 
		/// rule engine here
		/// </summary>
		public void StartOntologyEngine()
		{
			string nameServiceHost = "localhost";
			int nameServicePort = 1050;

			// register the channel
			IiopClientChannel channel = new IiopClientChannel();
			ChannelServices.RegisterChannel(channel);

			// access COS nameing service
			CorbaInit init = CorbaInit.GetInit();
			NamingContext nameService = init.GetNameService(nameServiceHost, nameServicePort);
			NameComponent[] name = new NameComponent[] { new NameComponent("jessTabShell", "") };
			// get the reference to the adder
			this.ontologyEngine = ( pkd.jess.JessTabShell )nameService.resolve(name);
		}
		#endregion
		#region Create Rules
		/// <summary>
		/// There is some strong coupling here b/c if no fact matches the fact the rule asserts, then an exception is thrown.
		/// Therefore there needs to be a way of matching rules to plugins, or unasserting rules when the matching plugins aren't there
		/// </summary>
		public void CreateRules()
		{
			System.IO.StreamReader reader = new System.IO.StreamReader( "rules.txt" );
			string line = null;
			while( ( line = reader.ReadLine() ) != null )
			{
				this.ruleEngine.executeCommand( line );
			}
			#region old rules
			/*
			 * //( printout t "" <"" ?headx "" "" ?heady ""> "")
			//---------------------------------------------------
			// FACETRACK
			//---------------------------------------------------
			this.ruleEngine.executeCommand( @"(defrule track-with-head 
											""If a face is detected with the camera, move so that the face is in the center field of view""
											(FaceTrackerPlugin( centerfaceheadsize ?headsize )( centerfacex ?headx )( centerfacey ?heady ) ( numberheadstracked ~0 ) )
											=>
											(TrackWithHead ?headx ?heady ?headsize)
											) " );
			//FACETRACK IS ALONE
			this.ruleEngine.executeCommand( @"( defrule noface-set-clock-alone
											""if no faces are detected, set is alone to true. this starts a clock that counts how long we've been alone""
											( FaceTrackerPlugin ( numberheadstracked 0 ) ) 
											?fact <- ( ClockShadowFact ( isalone FALSE ) ) 
											=>
											( modify ?fact ( isalone TRUE ) )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule face-not-alone
											""if a face is detected, set alone to true. clock minutes alone will go to zero""
											( FaceTrackerPlugin ( numberheadstracked ~0 ) )
											?fact <- ( ClockShadowFact ( isalone TRUE ) ) 
											=>
											( modify ?fact ( isalone FALSE ) )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule alone-play-animation
											""if alone for a while, play an animation""
											( ClockShadowFact ( isalone TRUE ) ( minutesalone ?time ) )
											( test ( <> ?time 0 ) )
											=>
											( GazeAnimationTemplate 116 118 125 1000 )
											) " );
			//USE TEST HERE TO SAY SIZE OF CENTER FACE MUST BE > 100
			//( FaceTrackerPlugin ( centerfaceheadsize ?headsize ) ) 
			//( test ( > ?headsize 100 ) ) 
			//( test ( neq ?text """" ) )
			//---------------------------------------------------
			// SPEECH RECOGNITION
			//---------------------------------------------------
			this.ruleEngine.executeCommand( @"(defrule reply-to-speech 
											""If a complete spoken input is detected, generate a reply string using natural language generation techniques. reset clock to know if a long time has passed since the other person spoke""
											?fact <- ( MModalPlugin( isworking FALSE )( text ?text )( utteranceready TRUE ) ) 
											( test ( neq ?text """" ) )
											( test ( TestAsr ?text ) )
											=>
											( modify ?fact ( utteranceready FALSE ) )
											( TextToSpeech ( GenerateResponse ?text ) )
											( PlayReactionAnimation ?text )
											( ResetClock )
											) " );
			
			this.ruleEngine.executeCommand( @"(defrule anticipate-speech-animation 
											""When the ASR is working on a result, play an animation""
											?fact <- ( MModalPlugin( isworking TRUE )( utteranceready FALSE ) ) 
											=>
											( PlayAnticipatoryAnimation )
											) " );
										
			
			//( AloneAnimation ?time )
										
			
			
			this.ruleEngine.executeCommand( @"( defrule recognize-face-load-profile 
											""when recognizing a face, load the profile. set acknowledged to true, so we only load a profile for a person once""
											?fact <- ( FaceVacsPlugin ( name ?name ) ( acknowledged FALSE ) ( confidence ?confidence ) )
											( test ( > ?confidence 150 ) )
											=>
											( modify ?fact ( acknowledged TRUE ) )
											( SetCurrentProfile ?name )
											( ConditionalGreet )
											) " );	
											
			//---------------------------------------------------
			// WIRELESS KEYPAD
			//---------------------------------------------------
			this.ruleEngine.executeCommand( @"( defrule keypad-look-stool 
											""use the keypad to cause the robot to look at the stool""
											?fact <- ( WirelessKeypadPlugin ( command ""lookstool"" ) )
											=>
											( GazeAnimationTemplate 124 118 137 1000 )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule keypad-look-couch 
											""use the keypad to cause the robot to look at the door""
											?fact <- ( WirelessKeypadPlugin ( command ""lookcouch"" ) )
											=>
											( GazeAnimationTemplate 150 118 137 1000 )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule keypad-look-door 
											""use the keypad to cause the robot to look at the door""
											?fact <- ( WirelessKeypadPlugin ( command ""lookdoor"" ) )
											=>
											( GazeAnimationTemplate 116 118 125 1000 )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule keypad-mute-microphone 
											""use the keypad to mute the microphone""
											?fact <- ( WirelessKeypadPlugin ( command ""mute"" ) )
											=>
											( MuteMicrophone TRUE )
											) " );
			this.ruleEngine.executeCommand( @"( defrule keypad-unmute-microphone 
											""use the keypad to unmute the microphone""
											( WirelessKeypadPlugin ( command ""unmute"" ) )
											?fact <- ( MModalPlugin( isworking ?isworking ) ) 
											=>
											( MuteMicrophone FALSE )
											( modify ?fact ( isworking FALSE ) )
											) " );
			this.ruleEngine.executeCommand( @"( defrule keypad-angry-animation 
											""use the keypad to play an angry animation on the robot""
											?fact <- ( WirelessKeypadPlugin ( command angryanimation ) )
											=>
											( PlayAnimation blink )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule keypad-happy-animation 
											""use the keypad to play a happy animation on the robot""
											?fact <- ( WirelessKeypadPlugin ( command happyanimation ) )
											=>
											( PlayAnimation blink )
											) " );	
			this.ruleEngine.executeCommand( @"( defrule keypad-play-story
											""use the keypad to play a story""
											?fact <- ( WirelessKeypadPlugin ( command ""playstory"" ) )
											=>
											( TextToSpeech ( PlayStory ) )
											) " );
			this.ruleEngine.executeCommand( @"( defrule keypad-play-pontification
											""use the keypad to play a pontification""
											?fact <- ( WirelessKeypadPlugin ( command ""playpontification"" ) )
											=>
											( TextToSpeech ( PlayPontification ) )
											) " );
			this.ruleEngine.executeCommand( @"( defrule keypad-stop-speech
											""use the keypad to stop the robot's speech""
											( WirelessKeypadPlugin ( command ""stopspeech"" ) )
											=>
											( StopSpeech )
											) " );
			*/
			#endregion
		}
		#endregion
		#region UserFunctions
		/// <summary>
		/// Create all custom jess-callable functions. Pass in the core so that functions can access 
		/// everything in it.
		/// </summary>
		public void CreateUserFunctions()
		{
			this.ruleEngine.addUserfunction( new TrackWithHead( this ) );
			this.ruleEngine.addUserfunction( new GenerateResponse( this ) );
			this.ruleEngine.addUserfunction( new TextToSpeech( this ) );
			this.ruleEngine.addUserfunction( new Shutdown( this ) );
			this.ruleEngine.addUserfunction( new ResetClock( this ) );
			this.ruleEngine.addUserfunction( new OpenComPort( this ) );
			this.ruleEngine.addUserfunction( new SetCurrentProfile( this ) );
			this.ruleEngine.addUserfunction( new InitiateConversation( this ) );
			this.ruleEngine.addUserfunction( new AloneAnimation( this ) );
			this.ruleEngine.addUserfunction( new ConditionalGreet( this ) );
			this.ruleEngine.addUserfunction( new Thank( this ) );
			this.ruleEngine.addUserfunction( new SendServo( this ) );
			this.ruleEngine.addUserfunction( new MuteMicrophone( this ) );
			this.ruleEngine.addUserfunction( new TestAsr( this ) );
			this.ruleEngine.addUserfunction( new DeleteLastResponse( this ) );
			this.ruleEngine.addUserfunction( new PlayAnimation( this ) );
			this.ruleEngine.addUserfunction( new PlayAnticipatoryAnimation( this ) );
			this.ruleEngine.addUserfunction( new PlayReactionAnimation( this ) );
			this.ruleEngine.addUserfunction( new ResetServos( this ) );
			this.ruleEngine.addUserfunction( new ResetDialogue( this ) );
			this.ruleEngine.addUserfunction( new GazeAnimationTemplate( this ) );
			this.ruleEngine.addUserfunction( new UseStories( this ) );
			this.ruleEngine.addUserfunction( new PlayStory( this ) );
			this.ruleEngine.addUserfunction( new PlayPontification( this ) );
			this.ruleEngine.addUserfunction( new StopSpeech( this ) );
			#region Testing
			/*
			this.ruleEngine.addUserfunction( new Test( this ) );
			this.ruleEngine.addUserfunction( new TurnCohesion( this ) );
			this.ruleEngine.addUserfunction( new PFind( this ) );
			*/
			#endregion
		}
		#endregion
		#endregion
	}
}
