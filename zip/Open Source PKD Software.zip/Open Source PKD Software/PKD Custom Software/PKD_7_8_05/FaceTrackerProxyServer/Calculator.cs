using System;
using SharperCV;

namespace PKDPlugin
{

	public class Calculator
	{
		public static CvPoint BetweenTheEyes( CvRect rect )
		{			
			return new CvPoint(rect.x + rect.width/2, rect.y + rect.height/3);
		}

		public static CvPoint Center(CvRect rect)
		{			
			return new CvPoint(rect.x + rect.width/2, rect.y + rect.height/2);
		}
		
		public static double Distance(CvRect r1, CvRect r2)
		{
			return Distance( Center(r1), Center(r2));
		}

		public static double Distance(CvPoint p1, CvPoint p2)
		{
			return Math.Pow((Math.Pow((p1.x - p2.x), 2) + Math.Pow((p1.y - p2.y), 2)), 0.5);
		}	

		/// <summary>
		/// True if the center of the target is inside the boundary
		/// </summary>
		/// <param name="boundary"></param>
		/// <param name="target"></param>
		/// <returns></returns>
		public static bool DoesBound(CvRect boundary, CvRect target)
		{
			CvPoint tc = Calculator.Center(target);

			return tc.x > boundary.x && tc.x < boundary.x + boundary.width &&
				tc.y > boundary.y && tc.y < boundary.y + boundary.height;
		}
		/// <summary>
		/// True if one number is more than half the size of the other
		/// </summary>
		/// <param name="aSize"></param>
		/// <param name="bSize"></param>
		/// <returns></returns>
		public static bool SimilarSize( int aSize, int bSize )
		{
			return 2*aSize > bSize && 2*bSize > aSize;
		}
	}
}
