/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using SharperCV;

namespace PKDPlugin
{

	public class Calculator
	{
		public static CvPoint BetweenTheEyes( CvRect rect )
		{			
			return new CvPoint(rect.x + rect.width/2, rect.y + rect.height/3);
		}

		public static CvPoint Center(CvRect rect)
		{			
			return new CvPoint(rect.x + rect.width/2, rect.y + rect.height/2);
		}
		
		public static double Distance(CvRect r1, CvRect r2)
		{
			return Distance( Center(r1), Center(r2));
		}

		public static double Distance(CvPoint p1, CvPoint p2)
		{
			return Math.Pow((Math.Pow((p1.x - p2.x), 2) + Math.Pow((p1.y - p2.y), 2)), 0.5);
		}	

		/// <summary>
		/// True if the center of the target is inside the boundary
		/// </summary>
		/// <param name="boundary"></param>
		/// <param name="target"></param>
		/// <returns></returns>
		public static bool DoesBound(CvRect boundary, CvRect target)
		{
			CvPoint tc = Calculator.Center(target);

			return tc.x > boundary.x && tc.x < boundary.x + boundary.width &&
				tc.y > boundary.y && tc.y < boundary.y + boundary.height;
		}
		/// <summary>
		/// True if one number is more than half the size of the other
		/// </summary>
		/// <param name="aSize"></param>
		/// <param name="bSize"></param>
		/// <returns></returns>
		public static bool SimilarSize( int aSize, int bSize )
		{
			return 2*aSize > bSize && 2*bSize > aSize;
		}
	}
}
