/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using System;
using SpeechLib;
using System.Threading;
using System.Net.Sockets;
using System.IO;

namespace ExploreRobotHead
{
	public delegate void StatusOutputDelegate( string status );
	/// <summary>
	/// You can type in text and synthesize the text with a speech engine while simultaneously
	/// sending visual (viseme) information over a serial cable to a robot head for the purposes of 
	/// lip synchronozation. It needs to be rewritten for a modular application.  Note that you require 
	/// the interop library for SAPI 5, as well as a SAPI 5 compliant speech engine to make this work. 
	/// Obviously you also need the .NET framework redistributable.
	/// Currently it opens a port to a tweaked version of the OpenCV HaarFaceDetect, so it requires that 
	/// and a compatible camera.  It also requires a compatible robot head -- most of the parameters 
	/// for servo motion have been hardcoded, which needs to be changed in the future.
	/// Right now I'm just having a look around :)
	/// Current complied version uses framework 1.1
	/// </summary>
	public class TTSTest
	{
		public bool isAnticipating = false;
		#region Fields / Constructor
		//The SAPI 5 voice object
		public SpVoiceClass voice;
		public SpeechVoiceSpeakFlags SpFlags;
		//Our serial port object
		private JustinIO.CommPort serialPort = new JustinIO.CommPort();
		public StatusOutputDelegate statusOutputDelegate;
		//An arraylist of arraylists, each representing a timeslice
		public System.Collections.ArrayList animationQueue = new System.Collections.ArrayList();
		//animationfilename/arraylist of slices, each slice an array of bytes
		public System.Collections.Hashtable animationToBookmarkHash = new System.Collections.Hashtable();
		public System.Collections.Hashtable animationHash = new System.Collections.Hashtable();
		public System.Collections.ArrayList generalAnimationList = new System.Collections.ArrayList();
		public System.Collections.ArrayList extremelyPositiveReactionAnimationList = new System.Collections.ArrayList();
		public System.Collections.ArrayList mildlyPositiveReactionAnimationList = new System.Collections.ArrayList();
		public System.Collections.ArrayList extremelyNegativeReactionAnimationList = new System.Collections.ArrayList();
		public System.Collections.ArrayList mildlyNegativeReactionAnimationList = new System.Collections.ArrayList();
		public System.Collections.ArrayList neutralReactionAnimationList = new System.Collections.ArrayList();
		
		public System.Collections.ArrayList anticipatoryAnimationList = new System.Collections.ArrayList();

		public byte[,] servoMinMaxDefaultList = null;

		public bool animationPlaying = false;
		public bool isSpeaking = false;

		public Sequence currentSequence = null;

		public System.Random random = new Random();
		public int animationToBookmarkIndex = 0;
		public string animationMarker = @"\!bm";

		public int gazeAnimationTemplateCount = 0;

		//We shouldn't need the AudioMixer, but the late delivery of the ASR package necessitates it for muting the microphone
		public AudioMixer.Helper audioMixerHelper = null;

		//public PKDPlugin.MModalProxyHelper mModalProxyHelper = null;

		byte leftEyeAxis = 170;
		byte rightEyeAxis = 97;
		byte headTurnAxis = 104;
		byte upperNod = 118;
		byte lowerNod = 137;
		
		int lastX = 166;
		int lastY = 120;
	
		/// <summary>
		/// The main entry point for the application. Start a message loop to receive events from the SAPI 5 
		/// speech engine.  Set up the serial port so commands may be set to a Scott Edwards Electronics Mini 
		/// SSC Serial Servo Controller
		/// </summary>
		//[STAThread]
		//public TTSTest( StatusOutputDelegate statusOutput )
		public TTSTest()
		{
			//HACK -- so we can mute the microphone on a remote machine
			//The proxy is a helper b/c of the serialization issues with jess and the ikvm classpath
			/*
			System.IO.StreamReader reader = new System.IO.StreamReader( "MModalProxyServerConnectionString.txt" );
			string uri = reader.ReadLine();
			reader.Close();
			this.mModalProxyHelper = ( PKDPlugin.MModalProxyHelper )Activator.GetObject( typeof( PKDPlugin.MModalProxyHelper ), uri );	
			this.mModalProxyHelper.SetMute( false );
			
			*/
			//END HACK

			////this.statusOutputDelegate = statusOutput;

			//this.voice = new SpVoiceClass();
			this.SpFlags = SpeechVoiceSpeakFlags.SVSFlagsAsync;

			//Get servo minMaxDefaultList -- probably want a menu option to edit this
			this.servoMinMaxDefaultList = ( byte[,] )DeserializeObject( "servoMinMaxDefaultList.xml" );

			//Fill animation hash table with data from VSA files in local VSA folder
			LoadAnimations( "ExtremelyPositiveReaction", this.extremelyPositiveReactionAnimationList );
			LoadAnimations( "MildlyPositiveReaction", this.mildlyPositiveReactionAnimationList );
			LoadAnimations( "ExtremelyNegativeReaction", this.extremelyNegativeReactionAnimationList );
			LoadAnimations( "MildlyNegativeReaction", this.mildlyNegativeReactionAnimationList );
			LoadAnimations( "NeutralReaction", this.neutralReactionAnimationList );
			LoadAnimations( "Anticipatory", this.anticipatoryAnimationList );
			LoadAnimations( "General", this.generalAnimationList );

			//Start message loop for SAPI5 speech engine events
			new Thread(new ThreadStart(MessageLoop)).Start();

			//Start thread to blink from
			new Thread( new ThreadStart( BlinkThread ) ).Start();

			//Start gazer thread
			//new Thread( new ThreadStart( Gazer ) ).Start();
			
			#region Set up Animation Scheduler
			//Set up a timer for playing back animations. This is the clock used for the animation frame rate
			System.Timers.Timer timer = new System.Timers.Timer();
			timer.Interval = 33;
			timer.Elapsed += new System.Timers.ElapsedEventHandler( AnimationTimer_Tick );	
			timer.Start();
			#endregion

			//The next steps:
			//open com port
			//select voice
			//System.Windows.Forms.Application.Exit();
		}

		#endregion
		/// <summary>
		/// Blink at least a certain time span apart, plus a random amount
		/// </summary>
		public void BlinkThread()
		{
			while( true )
			{
				this.AnimateNow( "blink" );
				System.Threading.Thread.Sleep( 2000 + this.random.Next( 5000 ) );
			}
		}
		public void Dispose()
		{
			System.Windows.Forms.Application.Exit();
		}
		#region Com port basics
		public void OpenComPort( int portNumber )
		{
			//Configure the serial port, using the Mini SSC settings
			serialPort.BaudRate = 9600;
			serialPort.ByteSize = 8;
			serialPort.StopBits = 0;		//MiniSSC doc says this should be 1, but it doesn't work unless it's zero
			serialPort.Parity = 0;

			serialPort.PortNum = portNumber;

			//Open the serial port for I/O
			serialPort.Open();
			//Initialize servos immediately with default values
			InitializeServos();

			//this.statusOutputDelegate( "COM port " + portNumber + " is open\n" );
		}

		/// <summary>
		/// Values for silence as determined empirically by manipulating the robot servos.
		/// </summary>
		/// <summary>
		/// Values for silence as determined empirically by manipulating the robot servos.
		/// </summary>
		public  void InitializeServos()
		{
			int length = this.servoMinMaxDefaultList.Length / 4;
			for( int i = 0; i < length; i++ )
			{
				serialPort.Write( new byte[3] { 255, this.servoMinMaxDefaultList[ i, 0 ], this.servoMinMaxDefaultList[ i, 3 ] } );
			}
		}
		/// <summary>
		/// Do error checking here so we don't send a servo value out that will break the robot.
		/// These threshold values are experimentally determined using VSA. This should be migrated 
		/// to a config file
		/// </summary>
		/// <param name="servoId"></param>
		/// <param name="servoPosition"></param>
		public void WriteToSerialSafely( byte servoId, byte servoPosition )
		{			
			//If value is 255, that's VSA's way of saying don't move
			int dummy = 0;
			if( servoPosition == 255 || servoPosition == 0 )
				dummy = 0;
				//Check the servo value against a list of accepted min/max values, thresholding to those values if necessary
				//Too low: send out the servo minimum value instead
			else if( servoPosition < this.servoMinMaxDefaultList[ servoId, 1 ] )
			{
				//Console.WriteLine("LOWER SERVO LIMIT for servo " + servoId + " value " + servoPosition + " wrote " + this.servoMinMaxDefaultList[ servoId, 0 ]+"\n" );
				serialPort.Write( new byte[3] { 255, servoId, this.servoMinMaxDefaultList[ servoId, 1 ] } );
			}
				//Too high: send out the servo maximum value instead
			else if( servoPosition > this.servoMinMaxDefaultList[ servoId, 2 ] )
			{
				//Console.WriteLine("UPPER SERVO LIMIT for servo " + servoId + " value " + servoPosition + " wrote " + this.servoMinMaxDefaultList[ servoId, 1 ]+"\n" );
				serialPort.Write( new byte[3] { 255, servoId, this.servoMinMaxDefaultList[ servoId, 2 ] } );
			}
				//Just right: If it's in the accepted range, write as is
			else
				serialPort.Write( new byte[3] { 255, servoId, servoPosition } );
		}

		#endregion
		#region Animation / Speech Event Handlers
		/// <summary>
		/// When the animation timer "ticks" it throws an event which is caught here.  Every event 
		/// indicates that the animation clock has moved forward one timestep (i.e. one animation frame, 
		/// or slice, or whatever).  Accordingly we get the next arraylist of slices from the animation 
		/// queue (here an arraylist) and write out the appropriate values to the serial port. When done 
		/// we remove the just played elements from the beginning of the list.
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		#region backup timer tick
		/*
		 * public void AnimationTimer_Tick(object sender, System.Timers.ElapsedEventArgs e)		
		{
			//Normal playback section
			if( animationQueue.Count == 0 )
			{
				this.animationPlaying = false;
				//Do nothing -- we have no animations to play
			}
			else
			{
				this.animationPlaying = true;

				//get the first item in the queue/list to playback
				lock( animationQueue )
				{
					System.Collections.ArrayList animations = (System.Collections.ArrayList) animationQueue[0];
					//remove first item from the queue
					animationQueue.RemoveAt( 0 );

					//Get size first to avoid threading issues
					int size = animations.Count;

					//For each slice/frame in this list, send to servos
					for( int j = 0; j < size; j++ )
					{
						byte[] slice = ( byte [] )animations[ j ];
						//Write to port
						for( byte i = 0; i < slice.Length; i ++ )
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
					}
				}
			}
		}
	*/
		#endregion
		public void AnimationTimer_Tick(object sender, System.Timers.ElapsedEventArgs e)		
		{
			/*
			if( this.isSpeaking == false )
				this.audioMixerHelper.SetMute( false );
				*/

			//Normal playback section
			if( animationQueue.Count == 0 )
			{
				this.animationPlaying = false;
				//Do nothing -- we have no animations to play

				this.WriteToSerialSafely( 35, leftEyeAxis );
				this.WriteToSerialSafely( 36, rightEyeAxis );
				this.WriteToSerialSafely( 34, headTurnAxis );
				this.WriteToSerialSafely( 33, upperNod );
				this.WriteToSerialSafely( 32, lowerNod );

				//if( this.isSpeaking == false && this.isAnticipating == false )

				this.Animate( this.RandomNeutralReactionAnimation() );

				//if( this.isSpeaking == false && this.isAnticipating == true )
					//this.Animate( "2_PKDanimation_EyebrowQuizzical_Moderate_6-18-05" );
			}
			else
			{
				this.animationPlaying = true;

				//get the first item in the queue/list to playback
				lock( animationQueue )
				{
					System.Collections.ArrayList animations = (System.Collections.ArrayList) animationQueue[0];
					//remove first item from the queue
					animationQueue.RemoveAt( 0 );

					//Get size first to avoid threading issues
					int size = animations.Count;

					//For each slice/frame in this list, send to servos
					for( int j = 0; j < size; j++ )
					{
						byte[] slice = ( byte [] )animations[ j ];
						//Write to port
						/*
						for( byte i = 0; i < 32; i ++ ) //32
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
						*/
						
						for( byte i = 0; i < 6; i ++ ) //32
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
						for( byte i = 7; i < 9; i ++ ) //32
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
						for( byte i = 11; i < 19; i ++ ) //32
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
						for( byte i = 22; i < 32; i ++ ) //32
						{
							WriteToSerialSafely( i, slice[ i ] );
						}
			

						if( this.gazeAnimationTemplateCount == 0 )
						{
							//WORKS
							this.WriteToSerialSafely( 35, leftEyeAxis );
							this.WriteToSerialSafely( 36, rightEyeAxis );
							this.WriteToSerialSafely( 34, headTurnAxis );
							this.WriteToSerialSafely( 33, upperNod );
							this.WriteToSerialSafely( 32, lowerNod );
						}
						else
						{
							for( byte i = 32; i < 37; i ++ ) //32
							{
								WriteToSerialSafely( i, slice[ i ] );
							}
							this.gazeAnimationTemplateCount--;
						}

						for( byte i = 37; i < slice.Length; i++ )
						{
							WriteToSerialSafely( i, slice[ i ] );
						}					
					}
				}
			}
		}
		/// <summary>
		/// WARNING: Assumes no gaps in servo map.
		/// </summary>
		/// <param name="servo"></param>
		/// <param name="servoPosition"></param>
		/// <returns></returns>
		public int DifferenceFromDefault( int gazeValue, int servo, int servoPosition )
		{
			/*
			if( servoPosition == 255 )
				return 0;
			else
				return servoPosition - this.servoMinMaxDefaultList[ servo, 3 ];
				*/
			if( servoPosition != 255 )
				servoPosition = gazeValue + servoPosition - this.servoMinMaxDefaultList[ servo, 3 ];
			return servoPosition;
		}
		/// <summary>
		/// Here we catch the bookmark events thrown by the speech engine when it encounters a bookmark tag 
		/// in the speech stream.  We interpret the argument of the tag as the name of an animation stored 
		/// in our animation hash file, using that name as the key to retrieve the animation data (which is 
		/// an arraylist of byte arrays acting as animation time "slices")
		/// </summary>
		/// <param name="streamNumber"></param>
		/// <param name="streamPosition"></param>
		/// <param name="bookmark"></param>
		/// <param name="bookmarkID"></param>
		public  void voice_Bookmark(int streamNumber, object streamPosition, string bookmark, int bookmarkID )
		{
			//this.statusOutputDelegate( bookmark +"\n");
			//Look up the bookmark in the hash, add the hash value to the animationQueue
			System.Collections.ArrayList animation = ( System.Collections.ArrayList ) animationHash[ bookmark ];
			
			lock( animationQueue )
			{
				//Make sure the queue can accomodate the new animation
				if( animationQueue.Count < animation.Count )
				{
					int sizeDifference = animation.Count - animationQueue.Count;
					for( int i = 0; i < sizeDifference + 1; i++ )
						animationQueue.Add( new System.Collections.ArrayList() );
				}

				//Add each byte array slice in animation to the appropriate position in the queue
				for( int i = 0; i < animation.Count; i++ )
				{
					System.Collections.ArrayList currentList = ( System.Collections.ArrayList )animationQueue[ i ];
					currentList.Add( animation[ i ] );
				}
			}
		}
		/// <summary>
		/// Use visemes thrown by the speech engine as the basis for commands to the robot head. First create a map 
		/// between the visemes and cardinal, device independent mouth positions. Then map the robot min/max servo
		/// positions to the cardinal positions using linear regression (computed off line). Use this information 
		/// to scale the cardinal positions to servo commands. Send servo commands.
		/// </summary>
		/// <param name="streamNumber"></param>
		/// <param name="streamPosition"></param>
		/// <param name="duration"></param>
		/// <param name="nextViseme"></param>
		/// <param name="currentFeature"></param>
		/// <param name="currentViseme"></param>
		public  void voice_Viseme(int streamNumber, object streamPosition, int duration, SpeechVisemeType nextViseme, SpeechVisemeFeature currentFeature, SpeechVisemeType currentViseme )
		{
			//Our mouth variables of interest
			byte MouthHeight = 0, MouthWidth = 0, MouthUpturn = 0, JawOpen, TeethUpperVisible = 0, TeethLowerVisible = 0, TonguePosn, LipTension = 0;
			//double MouthHeightScale = .50, MouthWidthScaleLeft = .24, MouthWidthScaleRight = .33, MouthUpturnScale= .05, JawOpenScale=0, TeethUpperVisibleScale= .094, TeethLowerVisibleScale=.33, TonguePosnScale=0, LipTensionScale = 0;

			//Console.WriteLine(string.Format("Viseme event received: stream {0} position {1} duration {2} nextViseme {3} currentFeature {4} currentViseme {5}", streamNumber, streamPosition, duration, nextViseme, currentFeature, currentViseme ) );
			string viseme = currentViseme.ToString();
			#region Engine Independent Viseme to Mouth Position (SAPI5 to SAPI4)
			switch( viseme  )
			{
				case "SVP_0" : 
					//InitializeServos();
					MouthHeight = 0;
					MouthWidth = 153;
					MouthUpturn = 117;
					JawOpen = 0;
					TeethUpperVisible = 0;
					TeethLowerVisible = 0;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_1" :
					MouthHeight = 48;
					MouthWidth = 208;
					MouthUpturn = 160;
					JawOpen = 96;
					TeethUpperVisible = 48;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_2" :
					MouthHeight = 112;
					MouthWidth = 128;
					MouthUpturn = 160;
					JawOpen = 128;
					TeethUpperVisible = 112;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_3" :
					MouthHeight = 112;
					MouthWidth = 128;
					MouthUpturn = 160;
					JawOpen = 128;
					TeethUpperVisible = 112;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_4" :
					MouthHeight = 48;
					MouthWidth = 160;
					MouthUpturn = 160;
					JawOpen = 96;
					TeethUpperVisible = 96;
					TeethLowerVisible = 176;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_5" :
					MouthHeight = 64;
					MouthWidth = 128;
					MouthUpturn = 160;
					JawOpen = 64;
					TeethUpperVisible = 32;
					TeethLowerVisible = 32;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_6" :
					MouthHeight = 80;
					MouthWidth = 176;
					MouthUpturn = 160;
					JawOpen = 48;
					TeethUpperVisible = 80;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 96;
					break;
				case "SVP_7" :
					MouthHeight = 179;
					MouthWidth = 0;
					MouthUpturn = 140;
					JawOpen = 48;
					TeethUpperVisible = 0;
					TeethLowerVisible = 0;
					TonguePosn = 0;
					LipTension = 222;
					break;
				case "SVP_8" :
					MouthHeight = 179;
					MouthWidth = 0;
					MouthUpturn = 140;
					JawOpen = 48;
					TeethUpperVisible = 0;
					TeethLowerVisible = 0;
					TonguePosn = 0;
					LipTension = 222;
					break;
				case "SVP_9" :
					MouthHeight = 128;
					MouthWidth = 128;
					MouthUpturn = 160;
					JawOpen = 128;
					TeethUpperVisible = 112;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_10" :
					MouthHeight = 128;
					MouthWidth = 0;
					MouthUpturn = 38;
					JawOpen = 96;
					TeethUpperVisible = 102;
					TeethLowerVisible = 255;
					TonguePosn = 0;
					LipTension = 64;
					break;
				case "SVP_11" :
					MouthHeight = 128;
					MouthWidth = 128;
					MouthUpturn = 160;
					JawOpen = 128;
					TeethUpperVisible = 112;
					TeethLowerVisible = 112;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_12" :
					MouthHeight = 48;
					MouthWidth = 208;
					MouthUpturn = 160;
					JawOpen = 128;
					TeethUpperVisible = 48;
					TeethLowerVisible =112;
					TonguePosn = 0;
					LipTension = 32;
					break;
				case "SVP_13" :
					MouthHeight = 64;
					MouthWidth = 0;
					MouthUpturn = 160;
					JawOpen = 48;
					TeethUpperVisible = 32;
					TeethLowerVisible = 80;
					TonguePosn = 0;
					LipTension = 176;
					break;
				case "SVP_14" :
					MouthHeight = 53;
					MouthWidth = 117;
					MouthUpturn = 153;
					JawOpen = 48;
					TeethUpperVisible = 0;
					TeethLowerVisible = 0;
					TonguePosn = 179;
					LipTension = 0;
					break;
				case "SVP_15" :
					MouthHeight = 16;
					MouthWidth = 208;
					MouthUpturn = 160;
					JawOpen = 48;
					TeethUpperVisible =80;
					TeethLowerVisible = 208;
					TonguePosn = 149;
					LipTension = 96;
					break;
				case "SVP_16" :
					MouthHeight = 32;
					MouthWidth = 208;
					MouthUpturn = 160;
					JawOpen = 64;
					TeethUpperVisible = 80;
					TeethLowerVisible = 192;
					TonguePosn = 149;
					LipTension = 76;
					break;
				case "SVP_17" :
					MouthHeight = 37;
					MouthWidth = 46;
					MouthUpturn = 140;
					JawOpen = 48;
					TeethUpperVisible = 64;
					TeethLowerVisible = 179;
					TonguePosn = 204;
					LipTension = 122;
					break;
				case "SVP_18" :
					MouthHeight = 16;
					MouthWidth = 160;
					MouthUpturn = 160;
					JawOpen = 0;
					TeethUpperVisible = 128;
					TeethLowerVisible = 0;
					TonguePosn = 0;
					LipTension = 208;
					break;
				case "SVP_19" :
					MouthHeight = 32;
					MouthWidth = 208;
					MouthUpturn = 160;
					JawOpen = 64;
					TeethUpperVisible = 80;
					TeethLowerVisible = 192;
					TonguePosn = 149;
					LipTension = 0;
					break;
				case "SVP_20" :
					MouthHeight = 16;
					MouthWidth =176;
					MouthUpturn = 160;
					JawOpen = 48;
					TeethUpperVisible = 32;
					TeethLowerVisible = 80;
					TonguePosn = 0;
					LipTension = 0;
					break;
				case "SVP_21" :
					MouthHeight = 0;
					MouthWidth = 64;
					MouthUpturn = 128;
					JawOpen = 0;
					TeethUpperVisible = 0;
					TeethLowerVisible = 0;
					TonguePosn = 0;
					LipTension = 166;
					break;
			}
			#endregion

			//Separate width/upturn values for each side
			byte MouthWidthLeft = MouthWidth;
			byte MouthWidthRight = MouthWidth;
			byte MouthUpturnLeft = MouthUpturn;
			byte MouthUpturnRight = MouthUpturn;
			
			//For these I used the silence to max values of R and the silence to max values of E
			TeethLowerVisible	= (byte)( -.24 *	TeethLowerVisible		+ 87  );
			TeethUpperVisible	= (byte)(  .31 *	TeethUpperVisible		+ 120 );
			MouthHeight			= (byte)( -.49 *	MouthHeight				+ 187 );
			MouthUpturnRight	= (byte)(  .65 *	MouthUpturnRight		- 54 );
			MouthUpturnLeft		= (byte)( -.70 *	MouthUpturnLeft			+ 242 );
						
			//For these, the silence value for E is in the middle of the range for R. Linear regression
			//gave these results.  Alternates that map the whole range of each to each other would be:
			//MWL .29x + 150; MWR .33x + 66
			//It remains to be empirically determined if the current silence values for E are correct
			MouthWidthRight		= (byte)(  .11 * MouthWidthRight	+ 166 );
			MouthWidthLeft		= (byte)( -.15 * MouthWidthLeft		+ 152  );


			//Lower Lip center
			WriteToSerialSafely( 6, TeethLowerVisible );
			//Upper Lip center
			WriteToSerialSafely( 26, TeethUpperVisible );
			//Smile Bucci Right
			WriteToSerialSafely( 20, MouthWidthRight );
			//Smile Bucci Left
			WriteToSerialSafely( 10, MouthWidthLeft );
			//Mouth Height/Jaw
			WriteToSerialSafely( 21, MouthHeight );
			//smile zygo Left
			WriteToSerialSafely( 9, MouthUpturnLeft );
			//smile zygo Right
			WriteToSerialSafely( 19, MouthUpturnRight );
		}
		
		public void voice_EndStream( int streamNumber, object streamPosition )
		{
			this.currentSequence = null;

			//turn the microphone back on once we finish speaking
			//this.mModalProxyHelper.SetMute( false );
			this.audioMixerHelper.SetCurrentMixer( "AK5370" );
			this.audioMixerHelper.SetMute( false );
			this.isSpeaking = false;
			
		}
		private void voice_StartStream(int StreamNumber, object StreamPosition)
		{
			//turn the microphone back on once we finish speaking
			//this.mModalProxyHelper.SetMute( true );
			this.audioMixerHelper.SetCurrentMixer( "AK5370" );
			this.audioMixerHelper.SetMute( true );
			this.isSpeaking = true;
		}
		#endregion
		#region Speech and Animation
		/// <summary>
		/// A message loop so we can receive events from the speech engine. If this were a windowed app, this 
		/// loop would be automatic. As a console app, we make our own loop.
		/// </summary>
		public  void MessageLoop()
		{
			//For some reason, the voice _has_ to be created here
			this.voice = new SpVoiceClass();
			this.voice.Rate = -1;

			//Event handler that will be called when the speech engine throws a viseme event
			voice.Viseme += new
				_ISpeechVoiceEvents_VisemeEventHandler(voice_Viseme);

			//Event handler that will be called when the speech engine throws a custom bookmark event. 
			//Can be used to trigger an animation
			voice.Bookmark += new _ISpeechVoiceEvents_BookmarkEventHandler( voice_Bookmark );

			// a sentence boundary event
			//voice.Sentence += new _ISpeechVoiceEvents_SentenceEventHandler(voice_Sentence);

			// a word boundary event
			voice.Word += new _ISpeechVoiceEvents_WordEventHandler(voice_Word);

			voice.StartStream += new _ISpeechVoiceEvents_StartStreamEventHandler(voice_StartStream);
			voice.EndStream += new _ISpeechVoiceEvents_EndStreamEventHandler( voice_EndStream );
			//this.statusOutputDelegate("\nStarting message loop.\n");
			System.Windows.Forms.Application.Run();
		}

		public void Speak( string line )
		{
			this.currentSequence = new Sequence( line );
			voice.Speak( this.currentSequence.text, SpFlags);
			//voice.WaitUntilDone(System.Threading.Timeout.Infinite);
		}
		public void Stop()
		{
			this.voice.Speak( "", SpeechLib.SpeechVoiceSpeakFlags.SVSFPurgeBeforeSpeak );
		}
		/// <summary>
		/// Given the name of an animation, insert a bookmark. When the bookmark is raised, the animation will be 
		/// scheduled
		/// </summary>
		/// <param name="line"></param>
		public void Animate( string animationName )
		{
			if( !this.animationPlaying )
				voice_Bookmark( 0, null, animationName, 0 );
		}
		/// <summary>
		/// Caution -- only use this if you are SURE you want two animations to play at
		/// </summary>
		/// <param name="animationName"></param>
		public void AnimateNow( string animationName )
		{
			voice_Bookmark( 0, null, animationName, 0 );
		}
		/// <summary>
		/// We have an animation time slice that we want to be played on the scheduler's next turn
		/// </summary>
		/// <param name="slice"></param>
		public void ScheduleSliceNow( byte[] slice )
		{
			lock( animationQueue )
			{
				//Make sure the queue can accomodate the new slice
				if( animationQueue.Count == 0 )
				{
					animationQueue.Add( new System.Collections.ArrayList() );
				}

				//Schedule the slice NOW
				System.Collections.ArrayList currentList = ( System.Collections.ArrayList )animationQueue[ 0 ];
				currentList.Add( slice );
			}
		}

		/// <summary>
		/// The animations are all loaded in a folder called VSA in the executable's local directory
		/// Each file in that folder is assumed to be an animation file of the appropriate VSA comma+space
		/// delimited format. To play these animations on the robot, insert a bookmark into the speech stream,
		/// e.g. "Hi \!bmAnimationName there" where AnimationName is the name of the animation file without 
		/// the file extension, and \!bm is the tag the speech engine recognizes as signalling a bookmark (may 
		/// vary depending on your speech engine)
		/// </summary>
		public void LoadAnimations( string directoryName, System.Collections.ArrayList list )
		{			
			//this.statusOutputDelegate("\nLoading Animations in " + directoryName +"\n" );
			System.IO.DirectoryInfo directoryInfo = new DirectoryInfo( System.IO.Directory.GetCurrentDirectory()+"\\VSA\\" + directoryName );
			System.IO.FileInfo[] fileInfoArray = directoryInfo.GetFiles("*.csv");
					
			foreach( System.IO.FileInfo fileInfo in fileInfoArray )
			{
				//this.statusOutputDelegate( fileInfo.Name + " " );
				System.IO.StreamReader reader = new System.IO.StreamReader( fileInfo.FullName );
				System.Collections.ArrayList slices = new System.Collections.ArrayList();
						
				//Each line is a slice. Add it to the slices list.
				string line = null;
				while( ( line = reader.ReadLine() ) != null )
				{
					//column is servo id. Value is servo position.
					string[] theSplit = line.Replace(",","").Trim().Split( new char[1] {' '} );
		
					//Eva has a dead zone of 4 servos, starting at 28, so adjust for that. Total of 40 servos
					byte[] thisSlice = new byte[ 39 ];
					for( int i = 0; i < 39; i++ )
					{
						//add each servo position to the slice
						thisSlice[ i ] = byte.Parse( theSplit[ i ].Trim() );
					}
					slices.Add( thisSlice );
				}
				reader.Close();
				string name = System.IO.Path.GetFileNameWithoutExtension( fileInfo.FullName );
				if( !this.animationHash.ContainsKey( name ) )
				{
					this.animationHash.Add( name, slices );
					//this.animationToBookmarkHash.Add( name, this.animationToBookmarkIndex++ );
				}
						
				list.Add( name );
			}
		}
		#region eva double check
		/*
		
		public void LoadAnimations( string directoryName, System.Collections.ArrayList list )
		{			
			//this.statusOutputDelegate("\nLoading Animations in " + directoryName +"\n" );
			System.IO.DirectoryInfo directoryInfo = new DirectoryInfo( System.IO.Directory.GetCurrentDirectory()+"\\VSA\\" + directoryName );
			System.IO.FileInfo[] fileInfoArray = directoryInfo.GetFiles("*.csv");
			
			foreach( System.IO.FileInfo fileInfo in fileInfoArray )
			{
				//this.statusOutputDelegate( fileInfo.Name + " " );
				System.IO.StreamReader reader = new System.IO.StreamReader( fileInfo.FullName );
				System.Collections.ArrayList slices = new System.Collections.ArrayList();
				
				//Each line is a slice. Add it to the slices list.
				string line = null;
				while( ( line = reader.ReadLine() ) != null )
				{
					//column is servo id. Value is servo position.
					string[] theSplit = line.Replace(",","").Trim().Split( new char[1] {' '} );

					//Eva has a dead zone of 4 servos, starting at 28, so adjust for that. Total of 40 servos
					byte[] thisSlice = new byte[ 40 ];
					for( int i = 0; i < 28; i++ )
					{
						//add each servo position to the slice
						thisSlice[ i ] = byte.Parse( theSplit[ i ].Trim() );
					}
					for( int i = 28; i < 32; i++ )
					{
						//add each servo position to the slice
						thisSlice[ i ] = (byte) 255;
					}
					for( int i = 32; i < 40; i++ )
					{
						//add each servo position to the slice
						thisSlice[ i ] = byte.Parse( theSplit[ i - 4 ].Trim() );
					}
					slices.Add( thisSlice );
				}
				reader.Close();
				string name = System.IO.Path.GetFileNameWithoutExtension( fileInfo.FullName );
				if( !this.animationHash.ContainsKey( name ) )
				{
					this.animationHash.Add( name, slices );
					//this.animationToBookmarkHash.Add( name, this.animationToBookmarkIndex++ );
				}
				
				list.Add( name  );
			}
		}
		*/
		#endregion
		#region phil load animations
		/*
		public void LoadAnimations( string directoryName, System.Collections.ArrayList list )
		{			
			//this.statusOutputDelegate("\nLoading Animations in " + directoryName +"\n" );
			System.IO.DirectoryInfo directoryInfo = new DirectoryInfo( System.IO.Directory.GetCurrentDirectory()+"\\VSA\\" + directoryName );
			System.IO.FileInfo[] fileInfoArray = directoryInfo.GetFiles("*.csv");
			
			foreach( System.IO.FileInfo fileInfo in fileInfoArray )
			{
				//this.statusOutputDelegate( fileInfo.Name + " " );
				System.IO.StreamReader reader = new System.IO.StreamReader( fileInfo.FullName );
				System.Collections.ArrayList slices = new System.Collections.ArrayList();
				
				//Each line is a slice. Add it to the slices list.
				string line = null;
				while( ( line = reader.ReadLine() ) != null )
				{
					//column is servo id. Value is servo position.
					string[] theSplit = line.Replace(",","").Trim().Split( new char[1] {' '} );

					//Eva has a dead zone of 4 servos, starting at 28, so adjust for that. Total of 40 servos
					byte[] thisSlice = new byte[ 39 ];
					for( int i = 0; i < 39; i++ )
					{
						//add each servo position to the slice
						thisSlice[ i ] = byte.Parse( theSplit[ i ].Trim() );
					}
					slices.Add( thisSlice );
				}
				reader.Close();
				string name = System.IO.Path.GetFileNameWithoutExtension( fileInfo.FullName );
				if( !this.animationHash.ContainsKey( name ) )
				{
					this.animationHash.Add( name, slices );
					//this.animationToBookmarkHash.Add( name, this.animationToBookmarkIndex++ );
				}
				
				list.Add( name );
			}
		}
		*/
		#endregion
		public string CreateBookmark( string name )
		{
			int bookmarkId = ( int ) this.animationToBookmarkHash[ name ];
			return @"\Mrk=" + bookmarkId + @"\";
		}
		#region Random Animation Selection Methods
		public void RandomAnticipatoryAnimation()
		{
			int index = random.Next( this.anticipatoryAnimationList.Count );
			lock( animationQueue )
			{
				this.animationQueue.Clear();
			}
			Animate( (string) this.anticipatoryAnimationList[ index ] );
		}

		public void RandomExtremelyPositiveReactionAnimation()
		{
			int index = random.Next( this.extremelyPositiveReactionAnimationList.Count );
			lock( animationQueue )
			{
				this.animationQueue.Clear();
			}
			Animate( (string) this.extremelyPositiveReactionAnimationList[ index ] );
		}
		public void RandomMildlyPositiveReactionAnimation()
		{
			int index = random.Next( this.mildlyPositiveReactionAnimationList.Count );
			lock( animationQueue )
			{
				this.animationQueue.Clear();
			}
			Animate( (string) this.mildlyPositiveReactionAnimationList[ index ] );
		}
		public void RandomExtremelyNegativeReactionAnimation()
		{
			int index = random.Next( this.extremelyNegativeReactionAnimationList.Count );
			lock( animationQueue )
			{
				this.animationQueue.Clear();
			}
			Animate( (string) this.extremelyNegativeReactionAnimationList[ index ] );
		}
		public void RandomMildlyNegativeReactionAnimation()
		{
			int index = random.Next( this.mildlyNegativeReactionAnimationList.Count );
			lock( animationQueue )
			{
				this.animationQueue.Clear();
			}
			Animate( (string) this.mildlyNegativeReactionAnimationList[ index ] );
		}
		public string RandomNeutralReactionAnimation()
		{
			int index = random.Next( this.neutralReactionAnimationList.Count );
			return (string) this.neutralReactionAnimationList[ index ];
		}
		#endregion

		#endregion
		#region Voice basics
		public void SetVoice( int id )
		{
			SpeechLib.ISpeechObjectTokens tokens = voice.GetVoices("","");
			voice.Voice = tokens.Item( id );

			//For speechworks
			//voice.Rate = -2;
		}

		public System.Collections.ArrayList GetAvailableVoices()
		{
			System.Collections.ArrayList voiceList = new System.Collections.ArrayList();
			//Find our voice
			SpeechLib.ISpeechObjectTokens tokens = voice.GetVoices("","");
			SpeechLib.SpObjectToken token = null;
			for( int i = 0; i < tokens.Count; i++ )
			{
				token =	tokens.Item( i );
				string description = token.GetDescription( 0 );
				voiceList.Add( description );
			}
			return voiceList;
		}

		#endregion
		public object DeserializeObject( string filename )
		{
			System.IO.FileStream fileStream = new System.IO.FileStream( filename, System.IO.FileMode.Open );
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter soapFormatter = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			//soapFormatter.Serialize( fileStream, servoMinMaxDefaultList );
			object o = soapFormatter.Deserialize( fileStream );
			fileStream.Close();
			return o;
		}
		#region Threaded Gazer
		/*
		/// <summary>
		/// Get latest gaze values from gaze server and route to agent. The gaze server is currently a 
		/// modified version of the OpenCV HaarFaceDetect and must be started before this application 
		/// (and thus act as a server for this application). A future improvement would be to use platform 
		/// invoke to remove the socket connection and call into the dll directly.
		/// </summary>
		public void Gazer()
		{
			byte leftEyeAxis = 112;
			byte rightEyeAxis = 112;
			byte headTurnAxis = 148;
			byte upperNod = 127;
			byte lowerNod = 98;

			int lastX = 166;
			int lastY = 120;

			while( true )
			{
				//Send to servos
				//mid is 160 X, 120 Y, headsize 41 at two feet
				//X position of face
				//Servos 15 left eye y axis, 16 right eye y axis, (both eyes min 67, max 160) 27 head turn y axis (min 70, max 184)
				//Y position of face: upper nod and lower nod
				//Servos 25 upper nod (min 70, max 185), 26 lower nod (min 0, max 150)
				//double temp = Math.Pow( ((eyeX - 160)/2.8), 2)/4;
						
				double deltaX = (eyeX - 166)/10;
				//Stop moving if we loose the face
				if( lastX == eyeX )
				{
					deltaX = 0;
					leftEyeAxis = 112;
					rightEyeAxis = 112;
				}
				else
				{
					leftEyeAxis = (byte)( leftEyeAxis + deltaX );
					rightEyeAxis = (byte)( rightEyeAxis + deltaX );
				}
				lastX = eyeX;

				double deltaY = (eyeY - 120)/10; 
				//Stop moving if we loose the face
				if( lastY == eyeY )
					deltaY = 0;
				lastY = eyeY;

		#region Y axis rotations
			
				headTurnAxis = (byte)( headTurnAxis + deltaX );
				
		#endregion

		#region X axis rotations
				//Do nod
				upperNod = (byte)( upperNod - deltaY );
				lowerNod = (byte)( lowerNod - deltaY );
		#endregion
		

				byte[] gazeSlice = new byte[ 40 ];
				gazeSlice[ 15 ] = leftEyeAxis;
				gazeSlice[ 16 ] = rightEyeAxis;
				gazeSlice[ 27 ] = headTurnAxis;
				gazeSlice[ 25 ] = upperNod;
				gazeSlice[ 26 ] = lowerNod;
				
				ScheduleSliceNow( gazeSlice );

				System.Threading.Thread.Sleep( 50 );

				 
				//Play a random general animation every 5 seconds
				System.Random random = new Random();
				int index = random.Next( 100 );
				if( index == 50 )
				{
					index = random.Next( this.generalAnimationList.Count );
					Animate( (string) this.generalAnimationList[ index ]);
				}
			}	
		}
*/
		#endregion
		#region backup gazer
		/*
		 * public void Gazer( int eyeX, int eyeY, int headSize )
		{
			//Don't take a null value and jerk the head around
			if( eyeX == 0 || eyeY == 0 )
				return;
	
		#region Calculate Delta in the X Coordinate
			double deltaX = (eyeX - 166)/10;

			//threshold the delta so it's not too big.
			if( deltaX > 9 )
				deltaX = 9;
			else if( deltaX < -9 )
				deltaX = -9;

			//Stop moving if we loose the face
			if( lastX == eyeX )
			{
				deltaX = 0;
				leftEyeAxis = 170;
				rightEyeAxis = 97;
			}
			else
			{
				leftEyeAxis = (byte)( leftEyeAxis - deltaX );
				rightEyeAxis = (byte)( rightEyeAxis - deltaX );
			}
			lastX = eyeX;
		#endregion

		#region Calculate Delta in the Y Coordinate
			double deltaY = (eyeY - 120)/10; 

			//Threshold the delta
			if( deltaY > 9 )
				deltaY = 9;
			else if( deltaY < -9 )
				deltaY = -9;
	
			//Stop moving if we loose the face
			if( lastY == eyeY )
				deltaY = 0;
			lastY = eyeY;
		#endregion

			//Test the rotations before performing to reduce chance of overflow
			double testRotation = 0;
		#region Y axis rotations
			//headTurn
			testRotation = headTurnAxis + deltaX;
			if( testRotation > 0 && testRotation < 255 )
				headTurnAxis = (byte) testRotation;
				
		#endregion

		#region X axis rotations
			//upper nod
			testRotation = upperNod + deltaY;
			if( testRotation > 0 && testRotation < 135 ) 
				upperNod = (byte) testRotation;
			//lower nod
			testRotation = lowerNod + deltaY;
			if( testRotation > 116 && testRotation < 161 )  //instead of manipulating defaults, assert there are no midgets and no giants
				lowerNod = (byte) testRotation;
		#endregion
			
			this.WriteToSerialSafely( 35, leftEyeAxis );
			this.WriteToSerialSafely( 36, rightEyeAxis );
			this.WriteToSerialSafely( 34, headTurnAxis );
			this.WriteToSerialSafely( 33, upperNod );
			this.WriteToSerialSafely( 32, lowerNod );
		}
*/
		#endregion
		public void Gazer( int eyeX, int eyeY, int headSize )
		{
			//Don't take a null value and jerk the head around
			if( eyeX == 0 || eyeY == 0 )
				return;
	
			#region Calculate Delta in the X Coordinate
			double deltaX = (eyeX - 166)/10;

			//threshold the delta so it's not too big.
			if( deltaX > 7 )
				deltaX = 7;
			else if( deltaX < -7 )
				deltaX = -7;

			//Stop moving if we loose the face
			if( lastX == eyeX )
			{
				deltaX = 0;
				leftEyeAxis = 170;
				rightEyeAxis = 97;
			}
			else
			{
				leftEyeAxis = (byte)( leftEyeAxis - deltaX );
				rightEyeAxis = (byte)( rightEyeAxis - deltaX );
			}
			lastX = eyeX;
			#endregion

			#region Calculate Delta in the Y Coordinate
			double deltaY = (eyeY - 120)/10; 

			//Threshold the delta
			if( deltaY > 7 )
				deltaY = 7;
			else if( deltaY < -7 )
				deltaY = -7;
	
			//Stop moving if we loose the face
			if( lastY == eyeY )
				deltaY = 0;
			lastY = eyeY;
			#endregion

			//Test the rotations before performing to reduce chance of overflow
			double testRotation = 0;
			#region Y axis rotations
			//headTurn
			testRotation = headTurnAxis + deltaX;
			if( testRotation > 88 && testRotation < 175 )
				headTurnAxis = (byte) testRotation;
				
			#endregion

			#region X axis rotations
			//upper nod
			testRotation = upperNod + deltaY;
			if( testRotation > 0 && testRotation < 135 ) 
				upperNod = (byte) testRotation;
			//lower nod
			testRotation = lowerNod + deltaY;
			if( testRotation > 116 && testRotation < 161 )  //instead of manipulating defaults, assert there are no midgets and no giants
				lowerNod = (byte) testRotation;
			#endregion
			
			/*
			this.WriteToSerialSafely( 35, leftEyeAxis );
			this.WriteToSerialSafely( 36, rightEyeAxis );
			this.WriteToSerialSafely( 34, headTurnAxis );
			this.WriteToSerialSafely( 33, upperNod );
			this.WriteToSerialSafely( 32, lowerNod );
			*/
		}

		private void voice_Word(int StreamNumber, object StreamPosition, int CharacterPosition, int Length)
		{
			//we move one word further in the sequence
			//this.currentSequence.wordIndex++;

			SequenceElement sequenceElement = ( SequenceElement ) this.currentSequence.sequence[ this.currentSequence.animationIndex ];
			//its time to play an animation
			if( CharacterPosition > sequenceElement.index )
			{
				this.currentSequence.animationIndex++;
				this.Animate( sequenceElement.animationName );
			}
		}
	
		public void ScheduleGazeAnimationTemplate( byte finalHeadTurn, byte finalUpperNod, byte finalLowerNod, int milliseconds )
		{
            //Schedule a sequence on animations that take the head to this final position.
			int frames = milliseconds / 33; //30 fps
			double deltaHeadTurn = ( ( double )( finalHeadTurn - this.headTurnAxis ) ) / frames;
			double deltaUpperNod = ( ( double )( finalUpperNod - this.upperNod ) ) / frames;
			double deltaLowerNod = ( ( double )( finalLowerNod - this.lowerNod ) ) / frames;
			double currentHeadTurn = deltaHeadTurn;
			double currentUpperNod = deltaUpperNod;
			double currentLowerNod = deltaLowerNod;

			double testRotation = 0;
			lock( animationQueue )
			{

				//Make sure the queue can accomodate the new animation
				if( animationQueue.Count < frames )
				{
					int sizeDifference = frames - animationQueue.Count;
					for( int i = 0; i < sizeDifference + 1; i++ )
						animationQueue.Add( new System.Collections.ArrayList() );
				}

				for( int i = 0; i < frames; i++ )
				{
					byte[] thisSlice = new byte[ 39 ];
									
					testRotation = this.headTurnAxis + currentHeadTurn;
					if( testRotation > 0 && testRotation < 255 )
						thisSlice[ 34 ] = ( byte ) testRotation;
					testRotation = this.upperNod + currentUpperNod;
					if( testRotation > 0 && testRotation < 255 )
						thisSlice[ 33 ] = ( byte ) testRotation;
					testRotation = this.lowerNod + currentLowerNod;
					if( testRotation > 0 && testRotation < 255 )
						thisSlice[ 32 ] = ( byte ) testRotation;
					
					//Add each byte array slice in animation to the appropriate position in the queue
					System.Collections.ArrayList currentList = ( System.Collections.ArrayList )animationQueue[ i ];
					currentList.Add( thisSlice );

					currentHeadTurn += deltaHeadTurn;
					currentLowerNod += deltaLowerNod;
					currentUpperNod += deltaUpperNod;
				}
				
				this.headTurnAxis = finalHeadTurn;
				this.upperNod = finalUpperNod;
				this.lowerNod = finalLowerNod;
				
				this.gazeAnimationTemplateCount = frames;
			}
		}
	}
}
