/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace PKDPlugin
{
	/// <summary>
	/// A convenient class that plugins may inherit from. If they do, they must override the Export method
	/// as well as fill the coreEventHandlerPairList with CoreEventHandlerPairs in the constructor
	/// </summary>
	[Serializable]
	public abstract class AbstractJessPlugin : ShadowFact, IJessPlugin
	{
		#region Fields / Constructor
		public System.Collections.ArrayList coreEventHandlerPairList;
		
		/// <summary>
		/// A. The constructor is a good place to specify the event handlers you've created to handle 
		/// specific core events.  You should store these in the coreEventHandlerPairList as PKDPlugin.CoreEventHandlerPair(s)
		/// B. Normally, you will want to extend the constructor in the derived class to lauch a thread. This 
		/// thread should write incomming data to a custom field, and this data should be used by CreateExportData
		/// Suppose you have a method: public void Run()	then add to constructor:
		/// System.Threading.Thread thread = new System.Threading.Thread(new System.Threading.ThreadStart( Run ));
		/// thread.Start();
		/// </summary>
		public AbstractJessPlugin()
		{
			this.coreEventHandlerPairList = new System.Collections.ArrayList();
		}

		#endregion
		#region Event Handlers
		public void RegisterEventHandler( System.Collections.Hashtable PluginEventHandlers ) //CoreEventHandler handler, CoreEvents eventToHandle)
		{
			foreach( CoreEventHandlerPair coreEventHandlerPair in this.coreEventHandlerPairList )
			{
				if(PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] == null)
				{
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = coreEventHandlerPair.handler;
				}
				else
				{	
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = ( CoreEventHandler )( PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] ) + coreEventHandlerPair.handler;
				}
			}
		}
		public void UnregisterEventHandler( System.Collections.Hashtable PluginEventHandlers )
		{
			foreach( CoreEventHandlerPair coreEventHandlerPair in this.coreEventHandlerPairList )
			{
				if(PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] == null)
				{
					return;
				}
				else
				{
					PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] = ( CoreEventHandler )( PluginEventHandlers[ coreEventHandlerPair.eventToHandle ] ) - coreEventHandlerPair.handler;
				}
			}
		}
		#endregion
		#region Export
		/*
		/// <summary>
		/// Declare the deftemplates -- the structure of the facts this plugin will export. Must 
		/// be called before Export or an exception will be thrown
		/// </summary>
		/// <param name="engine"></param>
		abstract public void DeclareExports( jess.Rete engine );

		/// <summary>
		/// Instead of doing it nicely so that the plugin doesn't see the engine, just make it 
		/// efficient and pass the engine in
		/// </summary>
		/// <param name="engine"></param>
		/// <returns></returns>
		abstract public void Export( jess.Rete engine );
*/
		#endregion
	}

	//Defunct -- when I was trying to be cutsie and make it more general and reusable. Mostly just
	//made it slow and complicated
	#region Data Structures for Exporting Data
	/*
	/// <summary>
	/// The export data container's name is like the name of a database table. The list of export data 
	/// objects are like a row in a database table. Each export data object has a name and value
	/// </summary>
	[Serializable]
	public class ExportDataContainer
	{
		public string name;
		public System.Collections.ArrayList exportDataList;

		public ExportDataContainer( string name )
		{
			this.name = name;
			this.exportDataList = new System.Collections.ArrayList();
		}

		public void Add( ExportData exportData )
		{
			this.exportDataList.Add( exportData );
		}
	}

	/// <summary>
	/// Like a cell in a database table, with name and value
	/// </summary>
	[Serializable]
	public class ExportData
	{
		public string name;
		public object theValue;	//can't call it value b/c that is a keyword
		public int type;

		public ExportData( string name, object theValue, ExportDataType type )
		{
			this.name = name;
			this.theValue = theValue;
			this.type = (int) type;
		}
	}

	public enum ExportDataType { String = jess.RU.STRING, Float = jess.RU.FLOAT, Integer = jess.RU.INTEGER, Atom = jess.RU.ATOM, Fact = jess.RU.FACT };
	*/
	#endregion
}
