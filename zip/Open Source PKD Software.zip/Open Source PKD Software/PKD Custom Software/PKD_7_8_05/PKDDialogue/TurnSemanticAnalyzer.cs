/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using LSAModule;

namespace PKDDialogue
{
	/// <summary>
	/// Inherits from LSAModule.SemanticAnalyzer.  Adds methods specifically for dealing 
	/// with PKDDialogue Turns
	/// </summary>
	public class TurnSemanticAnalyzer : LSAModule.SemanticAnalyzer
	{
		#region Constructors
		public TurnSemanticAnalyzer( string lsaFileName, ILSACalculator lsaCalculator ) : base( lsaFileName, lsaCalculator ) {}
		#endregion
		#region Turn Information Retrieval
		/// <summary>
		/// Calculate cosine between this turn and all the turns in the collection. Return a list of 
		/// turns. We are probably interested in the cosine value in each turns sortingValue field to 
		/// test the correlation b/w the cosine and the judge's ratings
		/// </summary>
		/// <param name="queryDocument"></param>
		/// <param name="allTurns"></param>
		/// <param name="N"></param>
		/// <returns></returns>
		public System.Collections.ArrayList GetTopNMatchingTurns( AbstractDocument queryDocument, System.Collections.ArrayList orgTurns, int N )
		{
			//We could also just pass around a version that we never modify
			System.Collections.ArrayList allTurns = ( System.Collections.ArrayList ) orgTurns.Clone();

			int numDocuments = allTurns.Count;

			//Caculate cosine of every element in the collection with the document
			for( int i = 0; i < numDocuments; i++ )
			{
				Turn turn = ( Turn ) allTurns[ i ];
				turn.document.sortingValue = this.lsaCalculator.Cosine( queryDocument.vector, turn.document.vector );
			}
			
			//Use the framework's handy quicksorting ability
			allTurns.Sort();

			System.Collections.ArrayList topNTurns = new System.Collections.ArrayList( allTurns.GetRange( 0, N ) );
			
			#region Take out all non-pkd turns
			Turn thisTurn = null;
			for( int i = 0; i < N; i++ )
			{
				thisTurn = ( Turn ) topNTurns[ i ];
				if( thisTurn.isDickSpeaker )
				{
					//If this is a pkd turn, we are happy, do nothing
				}
					//Otherwise replace the non pkd turn with the next pkd turn following it
				else
				{
					int advance = thisTurn.document.index;
					while( !thisTurn.isDickSpeaker && advance < allTurns.Count )
					{
						thisTurn = ( PKDDialogue.Turn ) orgTurns[ advance ];
						advance++;
					}
					//Make sorting value (cosine) of the pkd turn the same as the original
					thisTurn.document.sortingValue = (( Turn ) topNTurns[ i ]).document.sortingValue;
					topNTurns[ i ] = thisTurn;
				}
			}
			#endregion

			return topNTurns; 
		}
		/// <summary>
		/// Calculate relevance between this turn and all the turns in the collection by decomposing each word 
		/// of the query into a span and projecting each document into the span. Return a list of 
		/// turns. We are probably interested in the cosine value in each turns sortingValue field to 
		/// test the correlation b/w the cosine and the judge's ratings
		/// </summary>
		/// <param name="queryDocument"></param>
		/// <param name="allTurns"></param>
		/// <param name="N"></param>
		/// <returns></returns>
		public System.Collections.ArrayList GetTopNMatchingTurnsByDecompositionRelevanceToQuery( AbstractDocument queryDocument, System.Collections.ArrayList orgTurns, int N )
		{
			//Create a basis, decomposing each word in the query into it
			System.Collections.ArrayList basis = new System.Collections.ArrayList();
			string[] theSplit = queryDocument.text.Split( ' ' );
			foreach( string word in theSplit )
			{
				this.DecomposeReturnInformativity( this.GetVector( word ), basis );
			}
			int basisSize = basis.Count;

			//We could also just pass around a version that we never modify
			System.Collections.ArrayList allTurns = ( System.Collections.ArrayList ) orgTurns.Clone();

			int numDocuments = allTurns.Count;
			float[] measures = new float[ 2 ];
		
			//Caculate relevance of every element in the collection with the document
			for( int i = 0; i < numDocuments; i++ )
			{
				Turn turn = ( Turn ) allTurns[ i ];
				measures = this.DecomposeReturnRelevanceAndInformativity( turn.document.vector, basis );
				basis.RemoveAt( basisSize );
				
				turn.document.sortingValue = measures[ 0 ];
			}
			
			//Use the framework's handy quicksorting ability
			allTurns.Sort();

			System.Collections.ArrayList topNTurns = new System.Collections.ArrayList( allTurns.GetRange( 0, N ) );
			
			#region Take out all non-pkd turns
			Turn thisTurn = null;
			for( int i = 0; i < N; i++ )
			{
				thisTurn = ( Turn ) topNTurns[ i ];
				if( thisTurn.isDickSpeaker )
				{
					//If this is a pkd turn, we are happy, do nothing
				}
					//Otherwise replace the non pkd turn with the next pkd turn following it
				else
				{
					int advance = thisTurn.document.index;
					while( !thisTurn.isDickSpeaker && advance < allTurns.Count )
					{
						thisTurn = ( PKDDialogue.Turn ) orgTurns[ advance ];
						advance++;
					}
					//Make sorting value (cosine) of the pkd turn the same as the original
					thisTurn.document.sortingValue = (( Turn ) topNTurns[ i ]).document.sortingValue;
					topNTurns[ i ] = thisTurn;
				}
			}
			#endregion

			return topNTurns; 
		}
		
		/// <summary>
		/// Instead of creating a basis by projecting words in the query, we create a basis by projecting words 
		/// in each document. Then we project the query into that basis. So this is more of a backwards looking 
		/// rhetorical relationship. We expect the question to be highly relevant to the answer, and not add any 
		/// information in particular to the answer.
		/// </summary>
		/// <param name="queryDocument"></param>
		/// <param name="orgTurns"></param>
		/// <param name="N"></param>
		/// <returns></returns>
		public System.Collections.ArrayList GetTopNMatchingTurnsByDecompositionRelevanceToDocument( AbstractDocument queryDocument, System.Collections.ArrayList orgTurns, int N )
		{
			//We could also just pass around a version that we never modify
			System.Collections.ArrayList allTurns = ( System.Collections.ArrayList ) orgTurns.Clone();

			int numDocuments = allTurns.Count;
			float[] measures = new float[ 2 ];
		
			//Caculate relevance of every element in the collection with the document
			for( int i = 0; i < numDocuments; i++ )
			{
				Turn turn = ( Turn ) allTurns[ i ];

				//Create a basis, decomposing each word in the turn into it
				System.Collections.ArrayList basis = new System.Collections.ArrayList();
				string[] theSplit = turn.document.text.Split( ' ' );
				foreach( string word in theSplit )
				{
					this.DecomposeReturnInformativity( this.GetVector( word ), basis );
				}
				measures = this.DecomposeReturnRelevanceAndInformativity( queryDocument.vector, basis );				
				turn.document.sortingValue = measures[ 0 ] - measures[ 1 ];
			}
			
			//Use the framework's handy quicksorting ability
			allTurns.Sort();

			System.Collections.ArrayList topNTurns = new System.Collections.ArrayList( allTurns.GetRange( 0, N ) );
			
			#region Take out all non-pkd turns
			Turn thisTurn = null;
			for( int i = 0; i < N; i++ )
			{
				thisTurn = ( Turn ) topNTurns[ i ];
				if( thisTurn.isDickSpeaker )
				{
					//If this is a pkd turn, we are happy, do nothing
				}
					//Otherwise replace the non pkd turn with the next pkd turn following it
				else
				{
					int advance = thisTurn.document.index;
					while( !thisTurn.isDickSpeaker && advance < allTurns.Count )
					{
						thisTurn = ( PKDDialogue.Turn ) orgTurns[ advance ];
						advance++;
					}
					//Make sorting value (cosine) of the pkd turn the same as the original
					thisTurn.document.sortingValue = (( Turn ) topNTurns[ i ]).document.sortingValue;
					topNTurns[ i ] = thisTurn;
				}
			}
			#endregion

			return topNTurns; 
		}
		
		
		public System.Collections.ArrayList GetTopNMatchingTurnsByDecompositionBidirectionalRelevance( AbstractDocument queryDocument, System.Collections.ArrayList orgTurns, int N )
		{
			//Create a basis, decomposing each word in the query into it
			System.Collections.ArrayList basis = new System.Collections.ArrayList();
			string[] theSplit = queryDocument.text.Split( ' ' );
			foreach( string word in theSplit )
			{
				this.DecomposeReturnInformativity( this.GetVector( word ), basis );
			}
			int basisSize = basis.Count;

			//We could also just pass around a version that we never modify
			System.Collections.ArrayList allTurns = ( System.Collections.ArrayList ) orgTurns.Clone();

			int numDocuments = allTurns.Count;
			float[] measures = new float[ 2 ];
			float[] measures2 = new float[ 2 ];
		

			//Caculate relevance of every element in the collection with the document
			for( int i = 0; i < numDocuments; i++ )
			{
				//DECOMPOSE ANSWER INTO QUERY DOCUMENT
				Turn turn = ( Turn ) allTurns[ i ];
				measures = this.DecomposeReturnRelevanceAndInformativity( turn.document.vector, basis );
				basis.RemoveAt( basisSize );

				//DECOMPOSE QUERY DOCUMENT INTO ANSWER
				//Create another basis, decomposing each word in the turn into it
				System.Collections.ArrayList basis2 = new System.Collections.ArrayList();
				string[] theSplit2 = turn.document.text.Split( ' ' );
				foreach( string word in theSplit2 )
				{
					this.DecomposeReturnInformativity( this.GetVector( word ), basis2 );
				}
				measures2 = this.DecomposeReturnRelevanceAndInformativity( queryDocument.vector, basis2 );		
				
				//THE SORTING VALUE IS THE SUM OF THE RELEVANCES FROM THE TWO DECOMPOSITIONS
				turn.document.sortingValue = measures[ 0 ] + measures2[ 0 ];
			}
			
			//Use the framework's handy quicksorting ability
			allTurns.Sort();

			System.Collections.ArrayList topNTurns = new System.Collections.ArrayList( allTurns.GetRange( 0, N ) );
			
			#region Take out all non-pkd turns
			Turn thisTurn = null;
			for( int i = 0; i < N; i++ )
			{
				thisTurn = ( Turn ) topNTurns[ i ];
				if( thisTurn.isDickSpeaker )
				{
					//If this is a pkd turn, we are happy, do nothing
				}
					//Otherwise replace the non pkd turn with the next pkd turn following it
				else
				{
					int advance = thisTurn.document.index;
					while( !thisTurn.isDickSpeaker && advance < allTurns.Count )
					{
						thisTurn = ( PKDDialogue.Turn ) orgTurns[ advance ];
						advance++;
					}
					//Make sorting value (cosine) of the pkd turn the same as the original
					thisTurn.document.sortingValue = (( Turn ) topNTurns[ i ]).document.sortingValue;
					topNTurns[ i ] = thisTurn;
				}
			}
			#endregion

			return topNTurns; 
		}
		
		
		#endregion
	}
}
