/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace NevenVisionTest
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		#region Custom Fields
		int counter = 0;
		ExploreRobotHead.TTSTest ttsTest;
		AIMLtalk.ChatBot chatBot;
		demo.sphinx.hellongram.Sphinx4NGram asr;
		public bool asrReady = true;
		public System.Collections.ArrayList script = null;

		public byte[,] servoMinMaxDefaultList = null;
		//Nevenvision data lists
		System.Collections.ArrayList propertyList;
		System.Collections.ArrayList imageCoordinateNodeList;
		System.Collections.ArrayList headCoordinateNodeList;

		//Callibration structures for Neven to servo mapping
		System.Collections.ArrayList nevenNeutralList;
		System.Collections.ArrayList nevenMaxList;
		System.Collections.Hashtable nevenRegressionMap = null;
		System.Collections.Hashtable nevenToEvaMap = new Hashtable();
		#endregion
		
		#region Standard Fields
		const int WM_COPYDATA = 0x004A;
		string receiverWindowIdentifier = "Alpha Client 012105";
		private System.Windows.Forms.TextBox inputTextBox;
		private System.Windows.Forms.Button inputTextButton;
		private System.Windows.Forms.TextBox statusTextBox;
		private System.Windows.Forms.ComboBox voicesComboBox;
		private System.Windows.Forms.NumericUpDown comPortNumericUpDown;
		private System.Windows.Forms.Button openComPortButton;
		private System.Windows.Forms.Button nevenNeutralButton;
		private System.Windows.Forms.Button nevenMaxButton;
		private System.Windows.Forms.Button nevenCallibrationFromFileButton;
		private System.Windows.Forms.Button calibrateButton;
		private System.Windows.Forms.CheckBox useNevenvisionCheckBox;
		private System.Windows.Forms.CheckBox runScriptCheckBox;
		private System.Windows.Forms.CheckBox useAsrCheckBox;
		private System.Windows.Forms.NumericUpDown scriptIndexNumericUpDown;
		private System.Windows.Forms.Button exitButton;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		#endregion

		#region Standard Methods
		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.Text = this.receiverWindowIdentifier;
			
			#region Create Neven to Eva Map
			//Having a little problem with the enumeration. Will save it for later.
			this.nevenToEvaMap.Add( 100, -1 );
			this.nevenToEvaMap.Add( 101, -1 );
			this.nevenToEvaMap.Add( 102, -1 );
			this.nevenToEvaMap.Add( 103, 32 );
			this.nevenToEvaMap.Add( 104, 8 );
			this.nevenToEvaMap.Add( 105, -1 );
			this.nevenToEvaMap.Add( 106, -1 );
			this.nevenToEvaMap.Add( 107, -1 );
			this.nevenToEvaMap.Add( 108, -1 );
			this.nevenToEvaMap.Add( 109, -1 );
			this.nevenToEvaMap.Add( 110, 23 );
			this.nevenToEvaMap.Add( 111, 1 );
			this.nevenToEvaMap.Add( 112, 33 );
			this.nevenToEvaMap.Add( 113, 5 );
			this.nevenToEvaMap.Add( 114, 14 );
			this.nevenToEvaMap.Add( 115, 10 );
			this.nevenToEvaMap.Add( 116, 10 );
			this.nevenToEvaMap.Add( 117, 21 );
			this.nevenToEvaMap.Add( 118, 20 );
			this.nevenToEvaMap.Add( 119, 0 );
			this.nevenToEvaMap.Add( 120, 39 );
			this.nevenToEvaMap.Add( 121, 7 );
			this.nevenToEvaMap.Add( 122, -1 );
			this.nevenToEvaMap.Add( 123, -1 );
			this.nevenToEvaMap.Add( 124, -1 );
			this.nevenToEvaMap.Add( 125, -1 );
			this.nevenToEvaMap.Add( 126, 32 );
			this.nevenToEvaMap.Add( 127, 8 );
			this.nevenToEvaMap.Add( 128, 38 );
			this.nevenToEvaMap.Add( 129, 12 );
			this.nevenToEvaMap.Add( 130, -1 );
			this.nevenToEvaMap.Add( 131, -1 );
			#endregion

			//Get servo minMaxDefaultList -- probably want a menu option to edit this
			this.servoMinMaxDefaultList = ( byte[,] )DeserializeObject( "servoMinMaxDefaultList.xml" );
			
			ttsTest = new ExploreRobotHead.TTSTest( new ExploreRobotHead.StatusOutputDelegate( StatusOutput ) );
			
			this.chatBot = new AIMLtalk.ChatBot();

			//Start NevenVision last
			System.Diagnostics.Process.Start(@"..\..\NevenDemo\ffTTest\Debug\ffTTest.exe");

			this.script = GetScript();
			System.Threading.Thread.Sleep( 100 );

			//Start NevenVision Echo Thread
			new System.Threading.Thread( new System.Threading.ThreadStart( NevenVisionEcho) ).Start();

			//Start message loop for SAPI5 speech engine events
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel(new OVERONE.DotNetJ.JavaClientChannel());
			this.asr = ( demo.sphinx.hellongram.Sphinx4NGram )Activator.GetObject(typeof( demo.sphinx.hellongram.Sphinx4NGram ), "java://localhost:1604/?sphinx4NGram:demo.sphinx.hellongram.Sphinx4NGram");
			new System.Threading.Thread(new System.Threading.ThreadStart( AsrLoop )).Start();

			this.voicesComboBox.DataSource = ttsTest.GetAvailableVoices();
		}

		protected override void WndProc(ref Message m)
		{
			switch ( m.Msg )
			{
				case WM_COPYDATA:

					//Top level message shape
					NevenVisionMessage.COPYDATASTRUCT copyDataStruct = 
						( NevenVisionMessage.COPYDATASTRUCT ) m.GetLParam( typeof( NevenVisionMessage.COPYDATASTRUCT ) );
						
					//Copy message to safe type
					byte[] unstructuredData = new byte[ copyDataStruct.cbData ];
					System.Runtime.InteropServices.Marshal.Copy( copyDataStruct.lpData, unstructuredData, 0, copyDataStruct.cbData );

					//---------------------------------------------------
					//Recover structured data from the unstructured data
					//---------------------------------------------------
					//For indexing the unstructured data
					int propertySize = System.Runtime.InteropServices.Marshal.SizeOf( new NevenVisionMessage.VS_Property() );
					int nodeSize = System.Runtime.InteropServices.Marshal.SizeOf( new NevenVisionMessage.VS_Node() );
			
					//Data header describing following data. This could probably be optimized a little
					NevenVisionMessage.VS_FeatureData featureData = new NevenVisionMessage.VS_FeatureData( unstructuredData );
					//Acquire properties
					this.propertyList = new System.Collections.ArrayList();
					for( int i = (int)featureData.propertyArrOffset, j = 0; j < featureData.numberOfProperties; i += propertySize, j++ )
						propertyList.Add( new NevenVisionMessage.VS_Property( unstructuredData, i ) );
					//Acquire image relative coordinate system nodes
					this.imageCoordinateNodeList = new System.Collections.ArrayList();
					for( int i = (int)featureData.icNodeArrOffset, j = 0; j < featureData.numberOfNodes; i += nodeSize, j++ )
						imageCoordinateNodeList.Add( new NevenVisionMessage.VS_Node( unstructuredData, i ) );
					//Acquire head relative coordinate system nodes
					this.headCoordinateNodeList = new System.Collections.ArrayList();
					for( int i = (int)featureData.hcNodeArrOffset, j = 0; j < featureData.numberOfNodes; i += nodeSize, j++ )
						headCoordinateNodeList.Add( new NevenVisionMessage.VS_Node( unstructuredData, i ) );
					
					NevenGaze();

					//StatusOutput( "Received Facial Features\n" );
					//counter++;
					break;
				default:
					base.WndProc(ref m);
					break;
			}
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.inputTextBox = new System.Windows.Forms.TextBox();
			this.inputTextButton = new System.Windows.Forms.Button();
			this.statusTextBox = new System.Windows.Forms.TextBox();
			this.voicesComboBox = new System.Windows.Forms.ComboBox();
			this.comPortNumericUpDown = new System.Windows.Forms.NumericUpDown();
			this.openComPortButton = new System.Windows.Forms.Button();
			this.nevenNeutralButton = new System.Windows.Forms.Button();
			this.nevenMaxButton = new System.Windows.Forms.Button();
			this.nevenCallibrationFromFileButton = new System.Windows.Forms.Button();
			this.calibrateButton = new System.Windows.Forms.Button();
			this.useNevenvisionCheckBox = new System.Windows.Forms.CheckBox();
			this.runScriptCheckBox = new System.Windows.Forms.CheckBox();
			this.useAsrCheckBox = new System.Windows.Forms.CheckBox();
			this.scriptIndexNumericUpDown = new System.Windows.Forms.NumericUpDown();
			this.exitButton = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.comPortNumericUpDown)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.scriptIndexNumericUpDown)).BeginInit();
			this.SuspendLayout();
			// 
			// inputTextBox
			// 
			this.inputTextBox.Location = new System.Drawing.Point(8, 240);
			this.inputTextBox.Name = "inputTextBox";
			this.inputTextBox.Size = new System.Drawing.Size(240, 20);
			this.inputTextBox.TabIndex = 1;
			this.inputTextBox.Text = "Input";
			// 
			// inputTextButton
			// 
			this.inputTextButton.Location = new System.Drawing.Point(256, 240);
			this.inputTextButton.Name = "inputTextButton";
			this.inputTextButton.Size = new System.Drawing.Size(40, 23);
			this.inputTextButton.TabIndex = 2;
			this.inputTextButton.Text = "Send";
			this.inputTextButton.Click += new System.EventHandler(this.inputTextButton_Click);
			// 
			// statusTextBox
			// 
			this.statusTextBox.AcceptsReturn = true;
			this.statusTextBox.AcceptsTab = true;
			this.statusTextBox.AutoSize = false;
			this.statusTextBox.Location = new System.Drawing.Point(8, 8);
			this.statusTextBox.Multiline = true;
			this.statusTextBox.Name = "statusTextBox";
			this.statusTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.statusTextBox.Size = new System.Drawing.Size(100, 216);
			this.statusTextBox.TabIndex = 3;
			this.statusTextBox.Text = "Status";
			// 
			// voicesComboBox
			// 
			this.voicesComboBox.Location = new System.Drawing.Point(120, 8);
			this.voicesComboBox.Name = "voicesComboBox";
			this.voicesComboBox.Size = new System.Drawing.Size(176, 21);
			this.voicesComboBox.TabIndex = 4;
			this.voicesComboBox.Text = "Voices";
			this.voicesComboBox.SelectedIndexChanged += new System.EventHandler(this.voicesComboBox_SelectedIndexChanged);
			// 
			// comPortNumericUpDown
			// 
			this.comPortNumericUpDown.Location = new System.Drawing.Point(120, 40);
			this.comPortNumericUpDown.Name = "comPortNumericUpDown";
			this.comPortNumericUpDown.Size = new System.Drawing.Size(40, 20);
			this.comPortNumericUpDown.TabIndex = 5;
			// 
			// openComPortButton
			// 
			this.openComPortButton.Location = new System.Drawing.Point(176, 40);
			this.openComPortButton.Name = "openComPortButton";
			this.openComPortButton.Size = new System.Drawing.Size(64, 23);
			this.openComPortButton.TabIndex = 6;
			this.openComPortButton.Text = "Open Port";
			this.openComPortButton.Click += new System.EventHandler(this.openComPortButton_Click);
			// 
			// nevenNeutralButton
			// 
			this.nevenNeutralButton.Location = new System.Drawing.Point(120, 72);
			this.nevenNeutralButton.Name = "nevenNeutralButton";
			this.nevenNeutralButton.Size = new System.Drawing.Size(56, 23);
			this.nevenNeutralButton.TabIndex = 7;
			this.nevenNeutralButton.Text = "Neutral";
			this.nevenNeutralButton.Click += new System.EventHandler(this.nevenNeutralButton_Click);
			// 
			// nevenMaxButton
			// 
			this.nevenMaxButton.Location = new System.Drawing.Point(184, 72);
			this.nevenMaxButton.Name = "nevenMaxButton";
			this.nevenMaxButton.Size = new System.Drawing.Size(40, 23);
			this.nevenMaxButton.TabIndex = 8;
			this.nevenMaxButton.Text = "Max";
			this.nevenMaxButton.Click += new System.EventHandler(this.nevenMaxButton_Click);
			// 
			// nevenCallibrationFromFileButton
			// 
			this.nevenCallibrationFromFileButton.Location = new System.Drawing.Point(144, 104);
			this.nevenCallibrationFromFileButton.Name = "nevenCallibrationFromFileButton";
			this.nevenCallibrationFromFileButton.Size = new System.Drawing.Size(120, 23);
			this.nevenCallibrationFromFileButton.TabIndex = 9;
			this.nevenCallibrationFromFileButton.Text = "Callibrate From File";
			this.nevenCallibrationFromFileButton.Click += new System.EventHandler(this.nevenCallibrateFromFileButton_Click);
			// 
			// calibrateButton
			// 
			this.calibrateButton.Location = new System.Drawing.Point(232, 72);
			this.calibrateButton.Name = "calibrateButton";
			this.calibrateButton.Size = new System.Drawing.Size(64, 23);
			this.calibrateButton.TabIndex = 10;
			this.calibrateButton.Text = "Callibrate";
			this.calibrateButton.Click += new System.EventHandler(this.calibrateButton_Click);
			// 
			// useNevenvisionCheckBox
			// 
			this.useNevenvisionCheckBox.Location = new System.Drawing.Point(120, 136);
			this.useNevenvisionCheckBox.Name = "useNevenvisionCheckBox";
			this.useNevenvisionCheckBox.Size = new System.Drawing.Size(80, 24);
			this.useNevenvisionCheckBox.TabIndex = 11;
			this.useNevenvisionCheckBox.Text = "Echo Face";
			this.useNevenvisionCheckBox.CheckedChanged += new System.EventHandler(this.useNevenvisionCheckBox_CheckedChanged);
			// 
			// runScriptCheckBox
			// 
			this.runScriptCheckBox.Location = new System.Drawing.Point(120, 168);
			this.runScriptCheckBox.Name = "runScriptCheckBox";
			this.runScriptCheckBox.Size = new System.Drawing.Size(80, 24);
			this.runScriptCheckBox.TabIndex = 12;
			this.runScriptCheckBox.Text = "Run Script";
			this.runScriptCheckBox.CheckedChanged += new System.EventHandler(this.runScriptCheckBox_CheckedChanged);
			// 
			// useAsrCheckBox
			// 
			this.useAsrCheckBox.Location = new System.Drawing.Point(120, 200);
			this.useAsrCheckBox.Name = "useAsrCheckBox";
			this.useAsrCheckBox.Size = new System.Drawing.Size(72, 24);
			this.useAsrCheckBox.TabIndex = 13;
			this.useAsrCheckBox.Text = "Use ASR";
			// 
			// scriptIndexNumericUpDown
			// 
			this.scriptIndexNumericUpDown.Location = new System.Drawing.Point(208, 168);
			this.scriptIndexNumericUpDown.Name = "scriptIndexNumericUpDown";
			this.scriptIndexNumericUpDown.Size = new System.Drawing.Size(40, 20);
			this.scriptIndexNumericUpDown.TabIndex = 14;
			this.scriptIndexNumericUpDown.ValueChanged += new System.EventHandler(this.scriptIndexNumericUpDown_ValueChanged);
			// 
			// exitButton
			// 
			this.exitButton.Location = new System.Drawing.Point(248, 40);
			this.exitButton.Name = "exitButton";
			this.exitButton.Size = new System.Drawing.Size(48, 23);
			this.exitButton.TabIndex = 15;
			this.exitButton.Text = "Exit";
			this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(304, 266);
			this.Controls.Add(this.exitButton);
			this.Controls.Add(this.scriptIndexNumericUpDown);
			this.Controls.Add(this.useAsrCheckBox);
			this.Controls.Add(this.runScriptCheckBox);
			this.Controls.Add(this.useNevenvisionCheckBox);
			this.Controls.Add(this.calibrateButton);
			this.Controls.Add(this.nevenCallibrationFromFileButton);
			this.Controls.Add(this.nevenMaxButton);
			this.Controls.Add(this.nevenNeutralButton);
			this.Controls.Add(this.openComPortButton);
			this.Controls.Add(this.comPortNumericUpDown);
			this.Controls.Add(this.voicesComboBox);
			this.Controls.Add(this.statusTextBox);
			this.Controls.Add(this.inputTextBox);
			this.Controls.Add(this.inputTextButton);
			this.Name = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.comPortNumericUpDown)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.scriptIndexNumericUpDown)).EndInit();
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		#endregion

		public void AsrLoop()
		{
			while( true )
			{	
				try 
				{
					if( this.useAsrCheckBox.Checked )
					{
						//Keep dogging for text until we get some
						do
						{
							this.ttsTest.RandomAnticipatoryAnimation();
							this.inputTextBox.Text = this.asr.asrResult();
						}
						while( this.inputTextBox.Text == "" );
						
						string reply = this.chatBot.Send( "me", this.inputTextBox.Text );
						this.ttsTest.Speak( this.ttsTest.RandomReactionAnimation() + " " + reply );
						this.asr.clear();

						//Give up our priority
						System.Threading.Thread.Sleep( 10 );
					}
					else
					{
						System.Threading.Thread.Sleep( 200 );
					}
				}
				catch( System.Exception e )
				{
					StatusOutput( e.Message );
				}
			}
		}

		#region Neven Methods
		public void NevenVisionEcho()
		{
			while( true )
			{
				if( this.useNevenvisionCheckBox.Checked )
				{
					//Map Neven features to servos
					//Create an expression slice
					byte[] echoSlice = new byte[ 40 ];
					CenterSpace.NMath.Stats.LinearRegression linearRegression = null;
					CenterSpace.NMath.Core.DoubleVector doubleVector = null;
					try
					{
						foreach( NevenVisionMessage.VS_Node node in this.imageCoordinateNodeList )
						{
							int index = (int)nevenToEvaMap[ node.id ];
							if( index != -1 )
							{
								linearRegression = ( CenterSpace.NMath.Stats.LinearRegression ) nevenRegressionMap[ node.id ];
								doubleVector = new CenterSpace.NMath.Core.DoubleVector( new double[] { node.x, node.y } );
								echoSlice[ index ] = ( byte ) linearRegression.PredictedObservation( doubleVector );
							}
						}
					}
					catch( System.Exception e )
					{
						System.Windows.Forms.MessageBox.Show("You need to callibrate NevenVision first." + e.Message );
						this.useNevenvisionCheckBox.Checked = false;
					}
					this.ttsTest.ScheduleSliceNow( echoSlice );

					//give up our priority
					System.Threading.Thread.Sleep( 30 );
				}
				else
				{
					System.Threading.Thread.Sleep( 200 );
				}
			}
		}

		public void NevenGaze()
		{
			//Map Neven eye to gaze code
			int eyeX = 0, eyeY = 0, headSize = 0;
			foreach( NevenVisionMessage.VS_Node node in this.imageCoordinateNodeList )
			{
				if( node.id == (uint) NevenVisionMessage.NodeIdentification.RightPupil )
				{
					eyeX = node.x;
					eyeY = node.y;
					break;
				}
			}
			foreach( NevenVisionMessage.VS_Property property in this.propertyList )
			{
				if( property.id == (uint) NevenVisionMessage.PropertyIdentification.Scale )
				{
					headSize = property.p;
					break;
				}
			}
			//Make this info available to Gazer thread
			lock ( this.ttsTest )
			{
				this.ttsTest.eyeX = eyeX;
				this.ttsTest.eyeY = eyeY;
				this.ttsTest.headSize = headSize;
			}
		}
		#endregion

		#region User Interface Methods
		private void openComPortButton_Click(object sender, System.EventArgs e)
		{
			this.ttsTest.OpenComPort( (int )this.comPortNumericUpDown.Value );
		}

		private void nevenNeutralButton_Click(object sender, System.EventArgs e)
		{
			this.nevenNeutralList = this.imageCoordinateNodeList;
			SerializeObject( "nevenNeutralList.xml", this.nevenNeutralList );
			this.statusTextBox.Text = "Neutral callibrated and written to file";
		}

		private void nevenMaxButton_Click(object sender, System.EventArgs e)
		{
			this.nevenMaxList = this.imageCoordinateNodeList;
			SerializeObject( "nevenMaxList.xml", this.nevenMaxList );
			this.statusTextBox.Text = "Max callibrated and written to file";
		}

		public void SerializeObject( string fileName, object o )
		{
			System.IO.FileStream fileStream = new System.IO.FileStream( fileName, System.IO.FileMode.Create );
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter soapFormatter = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			soapFormatter.Serialize( fileStream, o );
			fileStream.Close();
		}

		private void nevenCallibrateFromFileButton_Click(object sender, System.EventArgs e)
		{
			this.nevenRegressionMap =  ( System.Collections.Hashtable ) DeserializeObject( "nevenRegressionMap.xml" );
			this.statusTextBox.Text = "Callibration loaded";
		}

		private void inputTextButton_Click(object sender, System.EventArgs e)
		{
			//Get input from script
			if( this.runScriptCheckBox.Checked )
			{
				int index = ( int ) this.scriptIndexNumericUpDown.Value;
				//We already set inputTextBox.Text to the first line of the script when the checkbox is checked
				this.ttsTest.Speak( this.inputTextBox.Text );
				index++;
				if( index < this.script.Count )
					this.inputTextBox.Text = ( string ) this.script[ index ];
				else
					this.inputTextBox.Text = "SCRIPT DONE";
				this.scriptIndexNumericUpDown.Value = index;
			}
			//Otherwise this box is manual entry
			else
			{
				string reply = this.chatBot.Send( "me", this.inputTextBox.Text );
				this.ttsTest.Speak( reply );
				//this.ttsTest.Speak( this.inputTextBox.Text );
				this.inputTextBox.Text = "";
			}
		}

		private void voicesComboBox_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			this.ttsTest.SetVoice( this.voicesComboBox.SelectedIndex );
		}

		private void useNevenvisionCheckBox_CheckedChanged(object sender, System.EventArgs e)
		{

		}

		private void calibrateButton_Click(object sender, System.EventArgs e)
		{
			//Perform the multiple regression that maps from the neutral/max nevenvision lists
			//to the min/max lists of the head
			//For each feature, create a multiple regression object
			
			nevenRegressionMap = new Hashtable();
			for( int i = 0; i < this.nevenMaxList.Count; i++ )
			{
				NevenVisionMessage.VS_Node maxNode = ( NevenVisionMessage.VS_Node )this.nevenMaxList[ i ];
				NevenVisionMessage.VS_Node neutralNode = ( NevenVisionMessage.VS_Node )this.nevenNeutralList[ i ];

				double[,] nevenArray = new double[ 3, 2 ] { { maxNode.x, maxNode.y}, { ( maxNode.x + neutralNode.x ) / 2, ( maxNode.y + neutralNode.y ) / 2 }, { neutralNode.x, neutralNode.y } };
				//The actual selection of a servo here requires a mapping that has not yet been finalized.
				int index = ( int )this.nevenToEvaMap[ maxNode.id ];
				if( index != -1 )
				{
					double[] maxDefaultArray = new double[ 3 ] { this.servoMinMaxDefaultList[ index, 2 ], ( this.servoMinMaxDefaultList[ index, 2 ] + this.servoMinMaxDefaultList[ index, 3 ] ) / 2, this.servoMinMaxDefaultList[ index, 3 ] };

					//CenterSpace.NMath.Core.DoubleMatrix nevenValues = new CenterSpace.NMath.Core.DoubleMatrix( "2x2 ["+ maxNode.x + " " + neutralNode.x +"  " + maxNode.y + " " + neutralNode.y + "]");
					//CenterSpace.NMath.Core.DoubleVector servoValues = new CenterSpace.NMath.Core.DoubleVector( "[1 2]" );
				
					CenterSpace.NMath.Core.DoubleMatrix nevenValues = new CenterSpace.NMath.Core.DoubleMatrix( nevenArray );
					CenterSpace.NMath.Core.DoubleVector servoValues = new CenterSpace.NMath.Core.DoubleVector( maxDefaultArray );
					CenterSpace.NMath.Stats.LinearRegression linearRegression = new CenterSpace.NMath.Stats.LinearRegression( nevenValues, servoValues, true );
					nevenRegressionMap.Add( maxNode.id, linearRegression );
				}
			}

			SerializeObject( "nevenRegressionMap.xml" , nevenRegressionMap );
			this.statusTextBox.Text = "Nevenvision callibrated. Written to file";
		}

		private void reloadServoMapButton_Click(object sender, System.EventArgs e)
		{
			this.servoMinMaxDefaultList = ( byte[,] )DeserializeObject( "servoMinMaxDefaultList.xml" );
		}

		public object DeserializeObject( string filename )
		{
			System.IO.FileStream fileStream = new System.IO.FileStream( filename, System.IO.FileMode.Open );
			System.Runtime.Serialization.Formatters.Soap.SoapFormatter soapFormatter = new System.Runtime.Serialization.Formatters.Soap.SoapFormatter();
			//soapFormatter.Serialize( fileStream, servoMinMaxDefaultList );
			object o = soapFormatter.Deserialize( fileStream );
			fileStream.Close();
			return o;
		}
		public void StatusOutput( string status )
		{
			this.statusTextBox.Text = status + this.statusTextBox.Text;
		}
		#endregion

		public System.Collections.ArrayList GetScript()
		{
			System.Collections.ArrayList script = new System.Collections.ArrayList();
			System.IO.StreamReader reader = new System.IO.StreamReader("script.txt");
			string line;
			while( ( line = reader.ReadLine() ) != null )
			{
				script.Add( line );
			}
			reader.Close();
			return script;
		}

		private void runScriptCheckBox_CheckedChanged(object sender, System.EventArgs e)
		{
			
			if( this.runScriptCheckBox.Checked ) 
			{
				this.script = GetScript();
				this.inputTextBox.Text = ( string ) this.script[ 0 ];
			}
			else this.inputTextBox.Text = "";
		}

		private void scriptIndexNumericUpDown_ValueChanged(object sender, System.EventArgs e)
		{
			int index = ( int ) this.scriptIndexNumericUpDown.Value;
			if( index > -1 && index < this.script.Count && this.runScriptCheckBox.Checked )
				this.inputTextBox.Text = ( string ) this.script[ index ];		
		}

		private void exitButton_Click(object sender, System.EventArgs e)
		{
			/*
			this.useAsrCheckBox.Checked = false;
			//Kill ffTTest
			System.Diagnostics.Process[] processArray = System.Diagnostics.Process.GetProcessesByName("ffTTest"); //("EmbeddedffTTest");
			foreach( System.Diagnostics.Process process in processArray )
				process.Kill();
			//Kill java ASR
			processArray = System.Diagnostics.Process.GetProcessesByName("cmd"); //("EmbeddedffTTest");
			foreach( System.Diagnostics.Process process in processArray )
				process.Kill();
			processArray = System.Diagnostics.Process.GetProcessesByName("java"); //("EmbeddedffTTest");
			foreach( System.Diagnostics.Process process in processArray )
				process.Kill();
			*/
			//System.Runtime.Remoting.Channels.ChannelServices.UnregisterChannel(new OVERONE.DotNetJ.JavaClientChannel());
			//System.Runtime.Remoting.RemotingServices.Disconnect( (System.MarshalByRefObject)this.asr );
			Application.Exit();
		}
	}
}
