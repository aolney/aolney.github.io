<%@ Page language="c#" Codebehind="ChatBot.aspx.cs" AutoEventWireup="false" Inherits="AIMLtalk.ChatBot"%>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>Chat with a Bot</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body MS_POSITIONING="GridLayout" onload="javascript:document.all('txtInput').focus()">
		<form id="Form1" method="post" runat="server">
			<p>
				<asp:Label id="lblChat3" runat="server" ForeColor="Blue"></asp:Label>
				<br>
				<asp:Label id="lblTalk3" runat="server" ForeColor="#008040"></asp:Label>
			</p>
			<p>
				<asp:Label id="lblChat2" runat="server" ForeColor="Blue"></asp:Label>
				<br>
				<asp:Label id="lblTalk2" runat="server" ForeColor="#008040"></asp:Label>
			</p>
			<p>
				<asp:Label id="lblChat1" runat="server" ForeColor="Blue"></asp:Label>
				<br>
				<asp:Label id="lblTalk1" runat="server" ForeColor="#008040"></asp:Label>
			</p>
			<p>
				<asp:Label id="lblChat" runat="server" ForeColor="Blue"></asp:Label>
				<br>
				<asp:Label id="lblTalk" runat="server" ForeColor="Red"></asp:Label>
			</p>
			<p>
				<asp:TextBox id="txtInput" runat="server" Width="680px" Height="24px"></asp:TextBox>
				<asp:Button id="btnSay" runat="server" Width="34px" Height="24px" Text="Say"></asp:Button>
			</p>
			<p>
				<asp:Label id="lblThat" runat="server"></asp:Label>
				<br>
				<asp:Label id="lblStars" runat="server"></asp:Label>
				<asp:Label id="hdnThat" runat="server" Visible="False"></asp:Label>
			</p>
		</form>
	</body>
</HTML>
