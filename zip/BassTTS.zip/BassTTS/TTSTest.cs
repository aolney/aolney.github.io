/*
Copyright (c) <2004> <Andrew Olney>

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/

using System;
using SpeechLib;
using System.Threading;

namespace BassTTS
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class TTSTest
	{
		 static SpVoiceClass voice;

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main(string[] args)
		{
			new Thread(new ThreadStart(MessageLoop)).Start();
			Thread.Sleep(1000); // or wait until message loop is created in other ways.

			//Make sure all motors are off
			PortAccess.Output(888, 0);
			//Loop here
			Speak();
			System.Windows.Forms.Application.Exit();
		}

		public static void MessageLoop()
		{
			voice = new SpVoiceClass();
			voice.Viseme += new
				_ISpeechVoiceEvents_VisemeEventHandler(voice_Viseme);

			Console.WriteLine("Starting message loop.");
			System.Windows.Forms.Application.Run();
		}

		public static void Speak()
		{
			//A default voice
			SpeechVoiceSpeakFlags SpFlags = SpeechVoiceSpeakFlags.SVSFlagsAsync;
			//SpeechLib.SpVoice Voice = new SpVoice();

			//Find our voice
			SpeechLib.ISpeechObjectTokens tokens = voice.GetVoices("","");
			SpeechLib.SpObjectToken token = null;
			for( int i = 0; i < tokens.Count; i++ )
			{
				token =	tokens.Item( i );
				string description = token.GetDescription( 0 );
				string id = token.Id;
				//Speechify Solo Tom (quality 01709)
				//ATT DTNV 1.3 Crystal
				if( description.Equals("Speechify Solo Tom (quality 01709)") )
					break;
			}
			//Set default voice to our choice
			voice.Voice = token;
			//For speechworks
			voice.Rate = -1;

			//Set callbacks for phoneme information
			voice.Viseme += new
				_ISpeechVoiceEvents_VisemeEventHandler(voice_Viseme);		

			//Loop on console input: read and speak
			string line = Console.ReadLine();						
			while( !line.Equals("quit") )
			{
				//Speak and wait to finish
				voice.Speak( line , SpFlags);

				voice.WaitUntilDone(System.Threading.Timeout.Infinite);
				line = Console.ReadLine();				
			}		
		}
		public static void voice_Viseme(int i, object o, int i2,SpeechVisemeType t, SpeechVisemeFeature f, SpeechVisemeType t2)
		{
			Console.WriteLine(string.Format("Viseme event received: {0} {1} {2} {3} {4} {5}", i, o, i2, t, f, t2));
			if( t2 == SpeechVisemeType.SVP_0 ||
				t2 == SpeechVisemeType.SVP_7 ||
				t2 == SpeechVisemeType.SVP_12 ||
				t2 == SpeechVisemeType.SVP_15 ||
				t2 == SpeechVisemeType.SVP_16 ||
				t2 == SpeechVisemeType.SVP_17 ||
				t2 == SpeechVisemeType.SVP_18 ||
				t2 == SpeechVisemeType.SVP_19 ||
				t2 == SpeechVisemeType.SVP_21 
				)
			{
				Console.WriteLine( "---> " + t2.ToString() );
				PortAccess.Output(888, 0);
			}
			else
				PortAccess.Output(888, 36);

	}
}
}
