using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace PKDPlugin
{
	//Our message across the process boundary has this shape
	public struct COPYDATASTRUCT
	{
		public System.IntPtr dwData;
		public int cbData;
		public System.IntPtr lpData;
	}

	public class Form1 : System.Windows.Forms.Form
	{
		#region Fields / Constructor
		private System.Text.StringBuilder stringBuilder = null;
		private const int WM_COPYDATA = 0x004A;
		public string receiverWindowIdentifier = "MModalProxyServer";
		public PKDPlugin.MModalProxyHelper mModalProxyHelper = null;
		private System.Windows.Forms.Timer timer1;
		public int timerInterval = 300;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			this.Text = this.receiverWindowIdentifier;
			this.stringBuilder = new System.Text.StringBuilder();
		
			//Start a server to host remoted objects
			int port = 1977;
			string name = "PKDPlugin.MModalProxyHelper";
			Type type = Type.GetType( name );
			System.Runtime.Remoting.Channels.Tcp.TcpChannel tcpServerChannel = new System.Runtime.Remoting.Channels.Tcp.TcpChannel( port );
			System.Runtime.Remoting.Channels.ChannelServices.RegisterChannel( tcpServerChannel );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( type, name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );
	
			//The trick -- get an instance of the singleton back from the server to initialize the class member
			//Now we can modify the object and changes will be mirrored on the client
			string uri = "tcp://localhost:" + port + "/" + name;
			this.mModalProxyHelper = ( PKDPlugin.MModalProxyHelper ) Activator.GetObject( type, uri );
			
			//Start the MModal process, which will run in a loop
			System.Diagnostics.ProcessStartInfo psi = new System.Diagnostics.ProcessStartInfo();
			psi.WorkingDirectory = @"C:\Documents and Settings\Andrew Olney\My Documents\Visual Studio Supplements\MModal";
			psi.FileName = @"examples\Copy of basicDictation\basicDictation___Win32_Release_Dynamic\basicDictation.exe";
			System.Diagnostics.Process.Start( psi );

			//Set up the audio helper which can mute for us
			name = "AudioMixer.Helper";
			type = typeof( AudioMixer.Helper );
			System.Runtime.Remoting.RemotingConfiguration.RegisterWellKnownServiceType( type, name, System.Runtime.Remoting.WellKnownObjectMode.Singleton );
		}

		#endregion
		[STAThread]
		static void Main()
		{
			Application.Run( new Form1() );
		}

		protected override void WndProc(ref Message m)
		{
			switch ( m.Msg )
			{
				case WM_COPYDATA:

					//Whenever we get an input from the ASR, stop the timer -- the timer starts when we 
					//think the turn has finished. If the timer ticks, we take that to mean it has definitely finished
					this.timer1.Enabled = false;

					this.mModalProxyHelper.isWorking = true;
					this.mModalProxyHelper.utteranceReady = false;
					this.mModalProxyHelper.text = "";
					this.mModalProxyHelper.isNew = true;

					//Top level message shape
					COPYDATASTRUCT copyDataStruct = 
						( COPYDATASTRUCT ) m.GetLParam( typeof( COPYDATASTRUCT ) );
					
					//A message length != 0 indicates the asr has sent some text (of length cbData)
					if( copyDataStruct.cbData != 0 )
					{
						//Copy message to safe type
						byte[] unstructuredData = new byte[ copyDataStruct.cbData ];
						System.Runtime.InteropServices.Marshal.Copy( copyDataStruct.lpData, unstructuredData, 0, copyDataStruct.cbData );
				
						//decode byte array; store in text buffer -- we buffer all text in a turn
						//Chuck away 1 word utterances
						string utterance = System.Text.Encoding.ASCII.GetString( unstructuredData );
						if( utterance.Trim().Split(' ').Length > 1 )
							this.stringBuilder.Append( utterance );

						//this.stringBuilder.Append( System.Text.Encoding.ASCII.GetString( unstructuredData ) );

						//Start the timer to see if this was the last utterance in the turn
						this.timer1.Enabled = true;
					}
					break;
				default:
					base.WndProc(ref m);
					break;
			}
		}
		
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer1 = new System.Windows.Forms.Timer(this.components);
			// 
			// timer1
			// 
			this.timer1.Interval = this.timerInterval;
			this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(264, 0);
			this.Name = "Form1";

		}
		#endregion

		private void timer1_Tick(object sender, System.EventArgs e)
		{
			//We are no longer working on this utterance
			this.mModalProxyHelper.isNew = true;
			this.mModalProxyHelper.isWorking = false;
			this.mModalProxyHelper.utteranceReady = true;
			this.mModalProxyHelper.text = this.stringBuilder.ToString();
			this.stringBuilder = new System.Text.StringBuilder();

			//Debug
			bool isworking = this.mModalProxyHelper.isWorking;
			bool uttready = this.mModalProxyHelper.utteranceReady;
			string text = this.mModalProxyHelper.text;

			//Stop the timer
			this.timer1.Enabled = false;
		}
	}
}
