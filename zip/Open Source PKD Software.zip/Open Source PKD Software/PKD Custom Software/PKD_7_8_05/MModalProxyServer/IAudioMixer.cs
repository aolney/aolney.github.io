using System;

namespace PKDPlugin
{
	public interface IAudioMixer
	{
		void SetMute( bool isMute );
		bool SetCurrentMixer( string deviceName );
	}
}
