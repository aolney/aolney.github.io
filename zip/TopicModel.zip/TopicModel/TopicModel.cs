/*
Copyright (c) 2009, Andrew M Olney
All rights reserved.

Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

    * Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
    * Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.
    * Neither the name of the University of Memphis nor the names of its contributors may be used to endorse or promote products derived from this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
using System;
using System.Collections.Generic;
using System.Text;

namespace TopicModel
{
    /// <summary>
    /// Generalizing topic models, consider a data set where:
    /// 1. The data set is made up of samples
    /// 2. Each sample is a set of tokens
    /// 3. Some tokens appear in multiple samples
    /// 
    /// The goal is to find categories such that we can define
    /// 1. a probability distribution of tokens for each category
    /// 2. a probability distribution of categories for each sample
    /// 
    /// In the case of the netflix prize, each sample is a customer, and the 
    /// tokens are the movies seen by that customer.
    /// </summary>
    [Serializable]
    public class TopicModel
    {
        public DataSet.DataSet dataSet;
        public int numberCategories;

        public TopicModel(DataSet.DataSet dataSet)
        {
            this.dataSet = dataSet;
        }

        public void GibbsEstimation(int numberCategories, double alpha, double beta, int iterations, int burnIn, int sampleLag )
        {
            int numStats = 0;

            this.numberCategories = numberCategories;

            double[,] thetaStats = new double[this.dataSet.sampleHash.Count, numberCategories];
            double[,] phiStats = new double[this.dataSet.typeHash.Count, numberCategories];

            int[] categoryForToken; // 1 x number of tokens: each cell is a topic index assigned to this token
            int[,] countTypeCategory; //T x C: times type is assigned to category (not inc current instance)
            int[,] countSampleCategory; //S x C: times category is assigned to a token in sample (not inc current instance)
            int[] countTokenCategory; //1 x C: number of tokens assigned to this category

            categoryForToken = new int[ this.dataSet.sampleAtToken.Length ];
            countTypeCategory = new int[ this.dataSet.typeHash.Count, numberCategories];
            countSampleCategory = new int[ this.dataSet.sampleHash.Count, numberCategories];
            countTokenCategory = new int[ numberCategories];

            //to make things easier to read
            int countTypes = this.dataSet.typeHash.Count;

            //-------------------------------------
            //randomly assign a category to each token
            //-------------------------------------
            System.Console.WriteLine("Randomly assigning a category to each token");
            CenterSpace.Free.MersenneTwister twister = new CenterSpace.Free.MersenneTwister();
            System.Random random = new Random(); //perhaps faster than twister?
            int randomCategory;

            int typeIndex, sampleIndex;
            int i, nnz = dataSet.typeAtToken.Length;
            for ( i = 0; i < nnz; i++)
            {
                //our random assignment
                randomCategory = twister.Next(numberCategories-1);
                categoryForToken[i] = randomCategory;

                //adjust the counts
                typeIndex = dataSet.typeAtToken[i];
                sampleIndex = dataSet.sampleAtToken[i];

                countSampleCategory[sampleIndex, randomCategory]++;
                countTypeCategory[typeIndex, randomCategory]++;
                countTokenCategory[randomCategory]++;
            }

            //-------------------------------------
            // Gibbs sample with burnIn
            //-------------------------------------
            System.Console.WriteLine("Begin Gibbs sampling");

            int category, sample, type, k, j, oneLessThanNumberCategories = numberCategories - 1;
            double[] p;
            double u;

            for (i = 0; i < iterations; i++)
            {
                //if( i % 100 ==0 ) 
                    System.Console.WriteLine( i + ":\t" + System.DateTime.Now );
            
                for (j = 0; j < nnz; j++)
                {
                    //to make things easier to read
                    category = categoryForToken[j];
                    sample = this.dataSet.sampleAtToken[j];
                    type = this.dataSet.typeAtToken[j];
                    
                    //remove current instance from consideration
                    countSampleCategory[sample, category]--;
                    countTypeCategory[type, category]--;
                    countTokenCategory[category]--;
                    //this.dataSet.tokensInSample[sample]--;

                    //do sampling
                    p = new double[numberCategories];
                    for ( k = 0; k < numberCategories; k++)
                    {
                        p[k] = ((countTypeCategory[type, k] + beta) / (countTokenCategory[k] + countTypes * beta))
                            * ((countSampleCategory[sample, k] + alpha)); // McCallum says this is optional, since it is constant across categories: / (this.dataSet.tokensInSample[sample] + numberCategories * alpha));
                    }
                    //cumulate parameters
                    for ( k = 1; k < p.Length; k++)
                        p[k] += p[k - 1];

                    // scale sample (p[] unnormalized)
                    //u = twister.NextDouble() * p[numberCategories - 1];
                    u = random.NextDouble() * p[ oneLessThanNumberCategories ];
                   
                    for (category = 0; category < p.Length; category++)
                        if (u < p[category]) break;

                    countSampleCategory[sample, category]++;
                    countTypeCategory[type, category]++;
                    countTokenCategory[category]++;
                    //this.dataSet.tokensInSample[sample]++;

                    categoryForToken[j] = category;
                }

                //save samples after burnin at regular intervals
                if ( i > burnIn && (i % sampleLag == 0))
                {
                    
                    Console.WriteLine("Saving sample at iteration " + i);
                    for ( k = 0; k < numberCategories; k++)
                    {
                        for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                            thetaStats[m,k] += (countSampleCategory[m, k] + alpha) /
                                         (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                        for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                            phiStats[n,k] += (countTypeCategory[n, k] + beta) /
                                        (countTokenCategory[k] + countTypes * beta);
                    }
                    numStats++;

                    bool periodicWrites = true;
                    if (periodicWrites)
                    {
                        this.WriteStats(thetaStats, phiStats, numStats);
                    }
                }
            }

            //-------------------------------------------
            // Calculate theta and phi from Gibbs sample
            //-------------------------------------------
            //averages first
            double[,] theta = new double[thetaStats.GetLength(0), thetaStats.GetLength(1)];
            double[,] phi = new double[phiStats.GetLength(0), phiStats.GetLength(1)];

            for ( k = 0; k < numberCategories; k++)
            {
                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m,k] = thetaStats[m, k] / numStats;

                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n,k] = phiStats[n, k] / numStats;
            }
            VectorSpace.Utility.Serialize("average_theta.dat", theta);
            VectorSpace.Utility.Serialize("average_phi.dat", phi);

            //final values
            for ( k = 0; k < numberCategories; k++)
            {
                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m,k] = (countSampleCategory[m, k] + alpha) /
                                 (this.dataSet.tokensInSample[m] + numberCategories * alpha);
                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n,k] = (countTypeCategory[n, k] + beta) /
                                (countTokenCategory[k] + countTypes * beta);
            }
            VectorSpace.Utility.Serialize("final_theta.dat", theta);
            VectorSpace.Utility.Serialize("final_phi.dat", phi);

            //Save everything else
            VectorSpace.Utility.Serialize("categoryForToken.dat",categoryForToken);

            VectorSpace.Utility.Serialize("countTypeCategory.dat",countTypeCategory);
            VectorSpace.Utility.Serialize("countSampleCategory.dat",countSampleCategory);
            VectorSpace.Utility.Serialize("countTokenCategory.dat",countTokenCategory);
           
        }

        public void WriteStats( double[,] thetaStats, double[,] phiStats, int numStats )
        {
            //averages first
            double[,] theta = new double[thetaStats.GetLength(0), thetaStats.GetLength(1)];
            double[,] phi = new double[phiStats.GetLength(0), phiStats.GetLength(1)];

            for ( int k = 0; k < this.numberCategories; k++)
            {
                for (int m = 0; m < this.dataSet.sampleHash.Count; m++)
                    theta[m, k] = thetaStats[m, k] / numStats;

                for (int n = 0; n < this.dataSet.typeHash.Count; n++)
                    phi[n, k] = phiStats[n, k] / numStats;
            }
            VectorSpace.Utility.Serialize("average_theta.dat", theta);
            VectorSpace.Utility.Serialize("average_phi.dat", phi);
        }

    }
}
