using System;
using System.Runtime.Remoting.Channels;
using Ch.Elca.Iiop;
using Ch.Elca.Iiop.Services;
using omg.org.CosNaming;


namespace JessSharp
{
	class TestHarness
	{
		[STAThread]
		static void Main(string[] args)
		{
			jess.Rete engine = new jess.Rete();
			
			/*
			string nameServiceHost = "localhost";
			int nameServicePort = 1050;

			// register the channel
			IiopClientChannel channel = new IiopClientChannel();
			ChannelServices.RegisterChannel(channel);

			// access COS nameing service
			CorbaInit init = CorbaInit.GetInit();
			NamingContext nameService = init.GetNameService(nameServiceHost, nameServicePort);
			NameComponent[] name = new NameComponent[] { new NameComponent("jessTabShell", "") };
			// get the reference to the adder
			pkd.jess.JessTabShell engine2 = ( pkd.jess.JessTabShell )nameService.resolve(name);
		
			while( true )
			{
				try
				{
					Console.Write( ">" );
					string input = Console.ReadLine();
					
					string result = engine2.executeCommand( input );
					Console.WriteLine( result );
				}
				catch( System.Exception e )
				{
					Console.WriteLine( e.Message );
				}
			}
			*/

			engine.defclass("test", "ShadowFact.Test", null);
			ShadowFact.Test b = new ShadowFact.Test("hello",1);
			engine.definstance("test", b, true);

			while( true )
			{
				try
				{
					Console.Write( ">" );
					string input = Console.ReadLine();
					
					jess.Value v = engine.executeCommand( input );
					Console.WriteLine( v.toString() );
				}
				catch( System.Exception e )
				{
					Console.WriteLine( e.Message );
				}
			}
		}
	}
}
