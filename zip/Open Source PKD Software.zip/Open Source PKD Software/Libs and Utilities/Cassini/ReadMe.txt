Cassini Web Server Sample README.TXT

This sample illustrates using the ASP.NET hosting APIs (System.Web.Hosting) to create
a simple managed Web Server with System.Net APIs.

TO USE THIS SAMPLE THE ENVIRONMENT MUST HAVE PATH SET TO BE ABLE TO RUN
GACUTIL.EXE AND CSC.EXE

----------------
Package contents
----------------

Sources files for the Cassini.dll assembly that implements the web server functionality:
    AssemblyInfo.cs
    ByteParser.cs
    ByteString.cs
    Connection.cs
    Host.cs
    Messages.cs
    Request.cs
    Server.cs

File containing the key pair (can be regenerated using 'sn -k Cassini.snk':
    Cassini.snk

Source files for the Cassini Web Server application:
    CassiniWebServerMain.cs
    CassiniWebServer.ico

Batch file to build the Cassini assembly and the server application:
    build.bat

------------
Instructions
------------

Go to the directory containing the above files (setup to use c# compiler
and gacutil utility).  Run 'build.bat', it will:
* compile Cassini.dll assembly
* add Cassini.dll assembly into Global Assembly Cache
* compile CassiniWebServer.exe web server application

Run the web server using 'CassiniWebServer <physical-path> <port> <virtual-path>'.
For example:
    CassiniWebServer c:\ 80 /
