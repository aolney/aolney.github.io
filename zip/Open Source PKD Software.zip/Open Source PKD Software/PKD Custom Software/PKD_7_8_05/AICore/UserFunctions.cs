/*
Copyright (c) 2005 Andrew Olney

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and 
associated documentation files (the "Software"), to deal in the Software without restriction, 
including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, 
and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, 
subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial 
portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT 
LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN 
NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, 
WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE 
SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
*/
using System;

namespace AICore
{
	#region PKDUserFunction
	/// <summary>
	/// The base class. Let all subclasses have access to the AICore
	/// </summary>
	public abstract class PKDUserFunction : jess.Userfunction
	{
		public AICore aiCore;

		public PKDUserFunction( AICore aiCore )
		{
			this.aiCore = aiCore;
		}
		
		public abstract string getName();
		public abstract jess.Value call( jess.ValueVector vv, jess.Context context);
	}
	#endregion
	#region TrackWithHead
	/// <summary>
	/// Use face tracking info to update the servo positions, resulting in the head moving to gaze at a person
	/// </summary>
	public class TrackWithHead : PKDUserFunction
	{
		public TrackWithHead( AICore aiCore ) : base( aiCore ) {}

		public override string getName()
		{
			return "TrackWithHead";
		}

		/// <summary>
		/// The first element of valuevector is the name of the function, the remaining are the jess.Value arguments
		/// </summary>
		/// <param name="vv"></param>
		/// <param name="context"></param>
		/// <returns></returns>
		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//I initially planned an event system, b/c there was going to be a plugin that did the servos.
			//Since we are handling the servos internally, it seems like pointless extra work
			//this.aiCore.pluginManager.FireEvent( PKDPlugin.CoreEvents.Animation, new PKDPlugin.CoreEventArgs( PKDPlugin.CoreEvents.Animation, new short[] { 1, (short)vv.get( 2 ).intValue( context ), (short)vv.get( 3 ).intValue( context ) } ) );
			this.aiCore.nlg.tts.Gazer( vv.get( 1 ).intValue( context ), vv.get( 2 ).intValue( context ), vv.get( 3 ).intValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region GenerateResponse
	/// <summary>
	/// Generate a response to a user dialogue input
	/// </summary>
	public class GenerateResponse : PKDUserFunction
	{
		public System.Text.RegularExpressions.Regex percentRegex;
		public System.IO.StreamWriter writer = null;

		public GenerateResponse( AICore aiCore ) : base( aiCore )
		{
			this.percentRegex = new System.Text.RegularExpressions.Regex( "%[^%]+%", System.Text.RegularExpressions.RegexOptions.Compiled );
			this.writer = new System.IO.StreamWriter( "log.txt", true );
			this.writer.WriteLine( System.DateTime.Now.ToShortDateString() + " " + System.DateTime.Now.ToShortTimeString() );
		}
		
		public override string getName()
		{
			return "GenerateResponse";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{	
			Console.WriteLine( "__________________________" );
			string input = this.percentRegex.Replace( vv.get( 1 ).stringValue( context ), "" );
			string response = this.aiCore.nlg.GenerateResponse( input );

			Console.WriteLine( "INPUT>" + input );
			Console.WriteLine( "REPLY>" + response );

			//For logging
			this.writer.WriteLine( "INPUT>" + input );
			this.writer.WriteLine( "REPLY>" + response );
			this.writer.WriteLine( "__________________________" );
			this.writer.Flush();
			//end logging

			Console.WriteLine( "__________________________" );

			//Save this input in the current conversation profile
			this.aiCore.nlg.conversationProfileManager.currentConversationProfile.subject = input;
		
			return new jess.Value( response, jess.RU.STRING );
		}
	}
	#endregion
	#region TextToSpeech
	/// <summary>
	/// Send a string to Text To Speech, which generates audio speech and throws lip sync and emote events
	/// </summary>
	public class TextToSpeech : PKDUserFunction
	{
		public TextToSpeech( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "TextToSpeech";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//pluginManager.FireEvent( PKDPlugin.CoreEvents.Animation, new PKDPlugin.CoreEventArgs( PKDPlugin.CoreEvents.Animation, new short[] { 1, (short)vv.get( 2 ).intValue( context ), (short)vv.get( 3 ).intValue( context ) } ) );
			this.aiCore.nlg.tts.Speak( vv.get( 1 ).stringValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region ResetClock
	/// <summary>
	/// We have a clock to gauge the duration of events. Sometimes it's convenient to reset that clock.
	/// </summary>
	public class ResetClock : PKDUserFunction
	{
		public ResetClock( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "ResetClock";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.clock.elapsedMinutes = 0;
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region Shutdown
	/// <summary>
	/// Whatever state needs to be saved before a session ends, save it now.
	/// </summary>
	public class Shutdown : PKDUserFunction
	{
		public Shutdown( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "Shutdown";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//save any profiles that have changed during the session
			this.aiCore.nlg.conversationProfileManager.WriteProfilesToFile();
			this.aiCore.nlg.semanticAnalyzer.Serialize( this.aiCore.nlg.dialogueFile, this.aiCore.nlg.masterDialogueList );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region OpenComPort
	/// <summary>
	/// Open a com port for servo control
	/// </summary>
	public class OpenComPort : PKDUserFunction
	{
		public OpenComPort( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "OpenComPort";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.OpenComPort( vv.get( 1 ).intValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region SetCurrentProfile
	/// <summary>
	/// Loads a conversation profile
	/// </summary>
	public class SetCurrentProfile : PKDUserFunction
	{
		public SetCurrentProfile( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "SetCurrentProfile";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.conversationProfileManager.SetCurrentProfile( vv.get( 1 ).stringValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region InitiateConversation
	/// <summary>
	/// Initiates a conversation, using the profile's initiators
	/// </summary>
	public class InitiateConversation : PKDUserFunction
	{
		public InitiateConversation( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "InitiateConversation";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.InitiateConversation();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region AloneAnimation
	/// <summary>
	/// Plays an animation when the head is alone for a specified period of time
	/// </summary>
	public class AloneAnimation : PKDUserFunction
	{
		public AloneAnimation( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "AloneAnimation";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//Play an animation for being alone. Just some filler until we have something
			this.aiCore.nlg.tts.Animate( "2_PKDanimation_Yawn_6-16-05" );
			//Console.WriteLine( "ALONE ANIMATION" );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region ConditionalGreet
	/// <summary>
	/// Greet if the last time a person was seen is greater than 1 hour
	/// </summary>
	public class ConditionalGreet : PKDUserFunction
	{
		public ConditionalGreet( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "ConditionalGreet";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.Speak( this.aiCore.nlg.GreetCurrentProfile() );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region Thank
	/// <summary>
	/// Thank all the people whose conversation profiles have been altered in the last hour
	/// </summary>
	public class Thank : PKDUserFunction
	{
		public Thank( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "Thank";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.Speak( this.aiCore.nlg.ThankRecentProfiles() );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region SendServo
	/// <summary>
	/// Send servo id a new value
	/// </summary>
	public class SendServo : PKDUserFunction
	{
		public SendServo( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "SendServo";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.WriteToSerialSafely( ( byte )vv.get( 1 ).intValue( context ), ( byte ) vv.get( 2 ).intValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region MuteMicrophone
	/// <summary>
	/// Mutes the microphone of the current machine
	/// </summary>
	public class MuteMicrophone : PKDUserFunction
	{
		public MuteMicrophone( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "MuteMicrophone";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//Parse the argument
			string argument = vv.get( 1 ).stringValue( context );
			bool mute  = false;
			if( argument == "TRUE" )
				mute = true;

			//HACK: for some reason, the audio device is getting switched to another device
			this.aiCore.nlg.tts.audioMixerHelper.SetCurrentMixer( this.aiCore.microphoneDevice );
			this.aiCore.nlg.tts.audioMixerHelper.SetMute( mute );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region TestAsr
	/// <summary>
	/// Test ASR input. There must be more than one word for us to respond
	/// </summary>
	public class TestAsr : PKDUserFunction
	{
		public TestAsr( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "TestAsr";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			string input = vv.get( 1 ).stringValue( context ).Trim();
			string[] words = input.Split( ' ' );

			if( words.Length > 1 )
				return jess.Funcall.TRUE;
			else
			{
				Console.WriteLine("Blocking " + input + " too short " );
				return jess.Funcall.FALSE;
			}
		}
	}
	#endregion
	#region DeleteLastResponse
	/// <summary>
	/// If PKD came back with a bad turn, remove it from the dialoguelist so we never see it again.
	/// You must also call shutdown for the changes to be saved.
	/// </summary>
	public class DeleteLastResponse : PKDUserFunction
	{
		public DeleteLastResponse( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "DeleteLastResponse";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.DeleteLastResponse();
			
				return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region PlayAnimation
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class PlayAnimation : PKDUserFunction
	{
		public PlayAnimation( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PlayAnimation";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.Animate( vv.get( 1 ).stringValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region ResetServos
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class ResetServos : PKDUserFunction
	{
		public ResetServos( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "ResetServos";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.InitializeServos();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region PlayAnticipatoryAnimation
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class PlayAnticipatoryAnimation : PKDUserFunction
	{
		public PlayAnticipatoryAnimation( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PlayAnticipatoryAnimation";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.RandomAnticipatoryAnimation();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region PlayReactionAnimation
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class PlayReactionAnimation : PKDUserFunction
	{
		public PlayReactionAnimation( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PlayReactionAnimation";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//Let the animation played at the end have a stronger valence than those during speech so as to not 
			//disrupt speech
			this.aiCore.nlg.GetSingleENDSemanticAnimation( vv.get( 1 ).stringValue( context ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region ResetDialogue
	/// <summary>
	/// Reset dialogue to its original state
	/// </summary>
	public class ResetDialogue : PKDUserFunction
	{
		public ResetDialogue( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "ResetDialogue";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.ResetDialogue();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region GazeAnimationTemplate
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class GazeAnimationTemplate : PKDUserFunction
	{
		public GazeAnimationTemplate( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "GazeAnimationTemplate";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			byte headTurn = ( byte ) vv.get( 1 ).intValue( context );
			byte upperNod = ( byte ) vv.get( 2 ).intValue( context );
			byte lowerNod = ( byte ) vv.get( 3 ).intValue( context );
			int milliseconds =  vv.get( 4 ).intValue( context );

			this.aiCore.nlg.tts.ScheduleGazeAnimationTemplate( headTurn, upperNod, lowerNod, milliseconds );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region UseStories
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class UseStories : PKDUserFunction
	{
		public UseStories( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "UseStories";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			string argument = vv.get( 1 ).stringValue( context );
			bool theBool  = false;
			if( argument == "TRUE" )
				theBool = true;

			this.aiCore.nlg.useStories = theBool;
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region PlayStory
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class PlayStory : PKDUserFunction
	{
		public PlayStory( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PlayStory";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			return new jess.Value( this.aiCore.nlg.GetRandomStory(), jess.RU.STRING );
		}
	}
	#endregion
	#region PlayPontification
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class PlayPontification : PKDUserFunction
	{
		public PlayPontification( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PlayPontification";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			return new jess.Value( this.aiCore.nlg.GetRandomPontification(), jess.RU.STRING );
		}
	}
	#endregion
	#region StopSpeech
	/// <summary>
	/// Play the named animation
	/// </summary>
	public class StopSpeech : PKDUserFunction
	{
		public StopSpeech( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "StopSpeech";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.tts.Stop();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region Testing
	#region Test
	public class Test : PKDUserFunction
	{
		public Test( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "Test";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			//Not currently returning a value. Once it's been tweaked, it will return a response
			this.aiCore.nlg.Test();
			//pluginManager.FireEvent( PKDPlugin.CoreEvents.Animation, new PKDPlugin.CoreEventArgs( PKDPlugin.CoreEvents.Animation, new short[] { 1, (short)vv.get( 2 ).intValue( context ), (short)vv.get( 3 ).intValue( context ) } ) );
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region TurnToTurnMeasures
	public class TurnCohesion : PKDUserFunction
	{
		public TurnCohesion( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "TurnCohesion";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.TurnToTurnMeasures();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#region ParameterFinding
	public class PFind : PKDUserFunction
	{
		public PFind( AICore aiCore ) : base( aiCore ) {}
		public override string getName()
		{
			return "PFind";
		}

		public override jess.Value call( jess.ValueVector vv, jess.Context context) 
		{
			this.aiCore.nlg.ParameterFinding();
			return jess.Funcall.TRUE;
		}
	}
	#endregion
	#endregion
}
